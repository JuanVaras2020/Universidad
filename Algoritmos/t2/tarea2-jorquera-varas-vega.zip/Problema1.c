#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Tiempo de ejecución del algoritmo:
// O(n) * O(lg(x_max)) = O(nlg(x_max))
// Tiempo lineal para intentar formar el arreglo
// Tiempo logarítmico para usar búsqueda binaria 


int max(int a, int b){ return (a > b) ? a : b; }

// tiempo de ejecución: O(n), 
// itera sobre los n elementos del arreglo en el peor caso
int buscarSelementos(int mid, int arr[], int n, int s)
{
    int pos, usados, i;
    pos = arr[0];
 
    usados = 1; // número de elementos dentro del arreglo
 
    for (i=1; i<n; i++)
    {
        if (arr[i] - pos >= mid)
        {
            pos = arr[i];
            usados++;
            // si logra conseguir s elementos del arreglo, retorna true
            if (usados == s){
                return 1;
            }
        }
    }

    // si al terminar de recorrer el arreglo no encuentra s elementos,
    // retorna false
    return 0;
}

int largestMinDist(int arr[], int n, int s)
{
    int res, left, right, mid;
    res = -1;
 
    left = 1; // 1 = distancia mínima entre dos puntos
    right = arr[n-1]; 
    // al usar arr[n-1], el tiempo de ejecución de la
    // búsqueda binaria se vuelve O(lg(arr[n-1]))
    // equivalente a O(lg(x_max)), siendo mayor o igual
    // a O(lg(n))   



    // Búsqueda binaria para encontrar 
    // la mayor distancia mínima
    while (left < right)
    {
        mid = (left + right)/2;
 
        // Si caben s elementos con distancia mínima m, se aumenta 
        // la distancia usando la mitad derecha del arreglo
        if (buscarSelementos(mid, arr, n, s) == 1){
            res = max(res, mid);
            left = mid + 1;
        }
        else
            right = mid;
    }
 
    return res;
}



int main(){
    int n, s, i, max;
    scanf("%d %d", &n, &s);

    int arr[n];
    for (i = 0; i < n; i++)
        scanf("%d", &arr[i]);

    if (n > 1 && s > 1)
        max = largestMinDist(arr, n, s);
    else
        max = 0;
    printf("%d\n", max);
    return 0;
}