#include <stdio.h>

int maxs_mins[] = {0, 0};

int getPos(int *arr, int izq, int der, int flag)
{
    int i;
    int pos = izq;
    for (i = izq; i <= der; i++)
        if ((arr[i] < arr[pos] && flag == 0) || (arr[i] > arr[pos] && flag == 1))
            pos = i;
    return pos;
}

void CalcularDif(int *arr, int izq, int der, int flag)
{
    if (der == izq)
    {
        maxs_mins[flag] = maxs_mins[flag] + arr[der];
        return;
    }
    else
    {
        int valor;
        int pos = getPos(arr, izq, der, flag);

        valor = arr[pos] * (pos - izq + 1) * ((der - izq + 1) - (pos - izq)); //Super propiedad

        maxs_mins[flag] = maxs_mins[flag] + valor;

        if (pos == izq)
        {
            CalcularDif(arr, pos + 1, der, flag);
        }
        else if (pos == der)
        {
            CalcularDif(arr, izq, pos - 1, flag);
        }
        else
        {
            CalcularDif(arr, izq, pos - 1, flag);
            CalcularDif(arr, pos + 1, der, flag);
        }
        return;
    }
}
int main()
{
    int n, i, izq, der;

    scanf("%d", &n);

    int arr[n];

    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
    izq = 0;
    der = n - 1;
    CalcularDif(arr, izq, der, 0);
    CalcularDif(arr, izq, der, 1);

    printf("%d\n", maxs_mins[1] - maxs_mins[0]);
    return 0;
}