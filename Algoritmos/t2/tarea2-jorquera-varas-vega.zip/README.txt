Instrucciones del Makefile

- Para compilar el programa, debe usar el comando make Problemas
- Para limpiar los archivos temporales, puede usar el comando make clean
- Para ejecutar el problema 1, debe usar el comando ./Problema_1 (Una vez haya compilado el programa).
- Para ejecutar el problema 2, debe usar el comando ./Problema_2 (Una vez haya compilado el programa).

Instrucciones de uso

-Para ejecutar ambos programas, se deberán seguir primero las instrucciones del Makefile.
- Al ejecutar cualquiera de los dos problemas se deberán ingresar los inputs siguiendo el formato mostrado en el enunciado.
- Opcionalmente, se puede escribir la instruccion "< archivo_de_prueba.txt" (sin comillas) al comando usado para ejecutar el programa para ingresar el input directamente desde un txt que se encuentre en el mismo directorio donde se están ejecutando los programas (cambiando el nombre "archivo_de_prueba" por el nombre del archivo que contenga el input).

EL ENUNCIADO DEL SEGUNDO PROBLEMA TIENE UN ERROR, EL RESULTADO ES 85

