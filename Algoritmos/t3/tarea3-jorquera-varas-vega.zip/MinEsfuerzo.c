#include <stdio.h>
#include <stdlib.h>

//Funcion longest increasing subsequence con una pequeña variante
int MinEsfuerzo(int *arr, int n){  
    int lis[n]; 
    int max, i, j;
   
    lis[0] = 1;
    max = lis[0]; 
    for (i = 1; i < n; i++){ 
        lis[i] = 1; 
        for (j = 0; j < i; j++ ){
            if (arr[i] >= arr[j] && lis[i] <= lis[j] + 1){
                lis[i] = lis[j] + 1;
                if (lis[i] > max){
                    max = lis[i];
                }
            } 
        }           
    } 

    //Max ahora es igual a el largo de la sub secuencia ordenada mas larga
    //Ahora basta retornar la resta entre el largo del arreglo y max
    return n - max;
}  

//Funcion para guardar los elementos de una linea en un arreglo dado
void MakeArray(int *arreglo, int size){
    int i;
    for (i = 0; i < size; i++)
        scanf("%d", &arreglo[i]);
}

int main(){
    int *arreglo;
    int N;
    int effort;

    //Iterar por cada linea del archivo de texto
    do{
        scanf("%d", &N);
        if(N > 1){
            arreglo = (int *)malloc(sizeof(*arreglo)*(N));
            MakeArray(arreglo, N);
            effort = MinEsfuerzo(arreglo, N);
            free(arreglo);
        }
        else{
            effort = 0;
        }
        printf("%d\n", effort);

    }while(!feof(stdin));
    return 0;
}