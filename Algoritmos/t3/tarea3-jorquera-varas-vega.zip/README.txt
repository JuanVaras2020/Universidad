Instrucciones del Makefile

- Para compilar el programa, debe usar el comando make Problema
- Para limpiar los archivos temporales, puede usar el comando make clean
- Para ejecutar el problema, debe usar el comando ./Problema (Una vez haya compilado el programa).

Instrucciones de uso

- Para ejecutar el programa, se deberán seguir primero las instrucciones del Makefile.
- Al ejecutar el programa se deberán ingresar los inputs siguiendo el formato mostrado en el enunciado.
- Opcionalmente, se puede escribir la instruccion "< archivo_de_prueba.txt" (sin comillas) al comando usado para ejecutar el 
  programa para ingresar el input directamente desde un txt que se encuentre en el mismo directorio donde se están ejecutando los 
  programas (cambiando el nombre "archivo_de_prueba" por el nombre del archivo que contenga el input).

Se adjunta un archivo de prueba llamado arreglos.txt

