#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int getAreaLaguna(char matriz[1010][1010], int *area, int i, int j, int n_filas, int n_columnas, int visited[1010][1010]){
    visited[i][j] = 1;

    if(matriz[i][j] == 'L')
        return 0;
    
    // horizontales y verticales: abajo, arriba, derecha, izquierda
    if (i < n_filas - 1 && visited[i + 1][j] == 0)
        *area += getAreaLaguna(matriz, area, i + 1, j, n_filas, n_columnas, visited);
    
    if (i > 0 && visited[i - 1][j] == 0)
        *area += getAreaLaguna(matriz, area, i - 1, j, n_filas, n_columnas, visited);

    if (j < n_columnas - 1 && visited[i][j + 1] == 0)
        *area += getAreaLaguna(matriz, area, i, j + 1, n_filas, n_columnas, visited);

    if (j > 0 && visited[i][j - 1] == 0)
        *area += getAreaLaguna(matriz, area, i, j - 1, n_filas, n_columnas, visited);

    // diagonales: abajo-derecha, arriba-derecha, arriba-izquierda, abajo-izquierda 
    if (i < n_filas - 1 && j < n_columnas - 1 && visited[i + 1][j + 1] == 0)
        *area += getAreaLaguna(matriz, area, i + 1, j + 1, n_filas, n_columnas, visited);
    
    if (i > 0 && j < n_columnas - 1 && visited[i - 1][j + 1] == 0)
        *area += getAreaLaguna(matriz, area, i - 1, j + 1, n_filas, n_columnas, visited);

    if (i > 0 && j > 0 && visited[i - 1][j - 1] == 0)
        *area += getAreaLaguna(matriz, area, i - 1, j - 1, n_filas, n_columnas, visited);

    if (i < n_filas - 1 && j > 0 && visited[i + 1][j - 1] == 0)
        *area += getAreaLaguna(matriz, area, i + 1, j - 1, n_filas, n_columnas, visited);
    
    return 1;
}
int main (){ 
    int n_casos, k, n_filas, n_columnas, i, j, fin_caso;
    char linea[1010];
    char matriz[1010][1010];


    fgets(linea, 1010, stdin); // lee la cantidad de casos a ingresar
    sscanf(linea, "%d", &n_casos);
    fgets(linea, 1010, stdin); // lee el espacio que separa numeros de casos con los casos (línea en blanco)

    for(k = 0; k < n_casos; k++){
    	n_filas = 0;
    	fin_caso = 0;

        // si no es el caso 1, imprime un salto de linea para separar los resultados
        if(k > 0)
            printf("\n");
        
        while (fin_caso != 1 && fgets(linea, 1010, stdin) != NULL){
            // si el input es una linea en blanco
            if (linea[0] == '\n' || linea[0] == '\r')
                fin_caso = 1;

            // si el input empieza con L o W -> input = fila de la matriz   
    		else if (linea[0] == 'L'  || linea[0] == 'W'){
                strcpy(matriz[n_filas], strtok(strtok(linea, "\r"), "\n"));
        		n_filas += 1;
    		}

            // si el input comienza con un número
    		else {
                sscanf(linea, "%d %d", &i, &j);
                n_columnas = strlen(matriz[0]); // todas las filas tienen la misma cantidad de columnas
                
                int visited[1010][1010];
                memset(visited, 0, 1010 * 1010 * sizeof(int)); // matriz de 0

                int *area = (int*)malloc(sizeof(int));
                *area = 0;

                *area += getAreaLaguna(matriz, area, i - 1, j - 1, n_filas, n_columnas, visited);


                printf("%d\n", *area);
                free(area);
    		}
    	}
	}

    return 0;
} 