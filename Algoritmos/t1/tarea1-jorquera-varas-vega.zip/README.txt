Instrucciones de uso

Para cada problema, se necesitará tener en el mismo fichero un archivo de texto con el formato presentado en las instrucciones de la tarea.
Si se utilizó algún tipo de programa para generar el archivo de texto, puede que haya problemas en la ejecución por que en el habrá caracteres especiales.
Para solucionar eso se puede copiar el contenido de dicho archivo y pegarlo en un archivo de texto nuevo.
Para ejecutar ambos programas, se deberán seguir las instrucciones del Makefile.

Instrucciones del Makefile

Para compilar el programa, debe usar el comando make Problemas
Para limpiar los archivos temporales, puede usar el comando make clean
Para ejecutar el problema 1, debe usar el comando ./Problema_1 < archivo_de_prueba.txt (Una vez haya compilado el programa)
Para ejecutar el problema 2, debe usar el comando ./Problema_2 < archivo_de_prueba.txt (Una vez haya compilado el programa)

En el repositorio se adjuntan 2 archivos de prueba, uno para cada problema.