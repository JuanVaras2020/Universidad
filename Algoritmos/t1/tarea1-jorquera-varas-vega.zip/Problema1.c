#include <stdio.h> 
#include <stdlib.h>

//Funcion para ordenar. Cambia dos valores en posicion x e y de un arreglo dado
void Swap(int *arr, int x, int y){
    int temp = arr[x];
    arr[x] = arr[y];
    arr[y] = temp;
}

//Ordena descendentemente un arreglo dado de tamaño n
void Ordenar_desc(int *arr, int n){
    int Min, j, i = 1;

    while(i < n){
        Min = n - i;
        j = 0;
        while (j <= (n - i)){
            if (arr[j] < arr[Min]){
                Min = j;
            }
            j = j + 1;
        }
        if ((n-i) != Min){
            Swap(arr, (n - i), Min);
        }
        i = i + 1;
    }
}

//Copiar los elementos del conjunto a_copiar al conjunto copiado
void copy(int *Conj_a_copiar, int *Conj_copiado, int n){
    for (int i = 0; i < n ; i++){
        Conj_copiado[i] = Conj_a_copiar[i];
    }
}

//Una vez que se encuentra un conjunto solucion, esta funcion lo imprime por pantalla y lo copia al conjunto anterior
void PrintSol(int *Conj_posible, int *Conj_anterior, int n){
    int cont=0;
    for (int i = 0; i < n ; i++){
        if (Conj_posible[i] != 0){

            if(cont==0){
                
                printf("%d", Conj_posible[i]);
                cont++;
            }

            else{
            printf(" + %d", Conj_posible[i]);
            }
        }
    }
    printf("\n");
    copy(Conj_posible, Conj_anterior ,n);
}

//Funcion principal para crear las soluciones de cada linea. Utiliza Backtracking
void CrearSoluciones(int n, int obj, int suma, int *Conj_inicial, int *Conj_posible, int *Conj_anterior, int *Conj_aux,  int pos){
    if (pos > n){
        return;
    }
    Conj_posible[pos] = Conj_inicial[pos];

    if (suma == obj){
        Conj_posible[pos] = 0;
        copy(Conj_posible, Conj_aux ,n);
        Ordenar_desc(Conj_aux, n);

        for(int j = 0; j < n; j++){
            if (Conj_anterior[j] != Conj_aux[j]){
                PrintSol(Conj_aux, Conj_anterior, n);
            }
        }
        return;
    }
    if (suma < obj){
        CrearSoluciones(n, obj, suma + Conj_inicial[pos] , Conj_inicial, Conj_posible, Conj_anterior, Conj_aux, pos + 1);
    }  
    
    Conj_posible[pos] = 0;
    CrearSoluciones(n, obj, suma , Conj_inicial, Conj_posible, Conj_anterior, Conj_aux, pos + 1);
}

//Funcion para otorgar valores al arreglo dinamico
void MakeArray(int *arreglo, int size){
    int i;
    for (i = 0; i < size; i++)
        scanf("%d", &arreglo[i]);
}


//Funcion para comprobar si se encontró un conjunto solucion
void Comprobar(int *Conj_anterior, int size){
    int i;
    for (i = 0; i < size; i++ ){
        if (Conj_anterior[i] != 0){
            return;
        }
    }
    printf("NADA\n");
}

int main (){ 
    int TAM;
    int objetivo;
    int pos;
    int suma;

    int *arreglo;
    int *Conj_posible;
    int *Conj_anterior;
    int *Conj_aux;

    do{
        pos = 0;
        suma = 0;
        scanf("%d", &objetivo);
        scanf("%d", &TAM);

        if(TAM > 0){
            printf("Suma de %d:\n", objetivo);
            arreglo = (int *)malloc(sizeof(*arreglo)*(TAM + 1));
            Conj_posible = (int *)calloc((TAM + 1), sizeof(*Conj_posible));
            Conj_anterior = (int *)calloc(TAM, sizeof(*Conj_anterior));
            Conj_aux = (int *)calloc((TAM + 1), sizeof(*Conj_aux));

            MakeArray(arreglo, TAM);
            Ordenar_desc(arreglo, TAM);
            CrearSoluciones(TAM, objetivo, suma, arreglo, Conj_posible, Conj_anterior, Conj_aux, pos);
            Comprobar(Conj_anterior, TAM);

            free(arreglo);
            free(Conj_posible);
            free(Conj_anterior);
            free(Conj_aux);
        }
        
    } while(!feof(stdin));
    return 0;
} 