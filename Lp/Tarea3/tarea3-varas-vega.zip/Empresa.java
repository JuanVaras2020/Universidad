class Empresa{
    private int PrecioBalon;
    private int PrecioLitro;
    private int PrecioKilometro;

    Empresa (int b, int l, int k){
        this.PrecioBalon = b;
        this.PrecioLitro = l;
        this.PrecioKilometro = k;
    }


    //Setters
    void setPrecioBalon(int b){
        this.PrecioBalon = b;
    }

    void setPrecioLitro(int l){
        this.PrecioLitro = l;
    }

    void setPrecioKilometro(int k){
        this.PrecioKilometro = k;
    }


    //Getters
    int getPrecioBalon(){
        return this.PrecioBalon;
    }

    int getPrecioLitro(){
        return this.PrecioLitro;
    }

    int getPrecioKilometro(){
        return this.PrecioKilometro;
    }
}