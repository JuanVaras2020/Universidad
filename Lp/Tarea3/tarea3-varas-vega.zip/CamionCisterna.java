class CamionCisterna extends Vehiculo{

    CamionCisterna(int p){
        super(p);
    }

}