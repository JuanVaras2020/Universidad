Juan Pablo Varas	201873600-7
Patricio Vega		201873532-9

Para compilar el programa se debe usar el Makefile y su funcion make classes (Para limpiar usar clean)
