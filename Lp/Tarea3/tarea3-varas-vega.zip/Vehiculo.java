class Vehiculo{
    private int precio;

    Vehiculo(int p){
        this.precio = p;
    } 


    //Setter
    void setPrecio(int p){
        this.precio = p;
    }

    //Getter
    int getPrecio(){
        return this.precio;
    }
}