class Casa extends Edificacion{

    Casa(int consumo){
        super(consumo);
    }
}