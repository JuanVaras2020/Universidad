class Ciudad{

    //int i: Contador para ciclos
    int i;

    private int Id;
    private int nCasas;
    private int nEdificios;

    //int[] casas: Arreglo donde se almacenará el consumo de todas las casas de la ciudad
    private int[] casas;

    //int[] edificios: Arreglo donde se almacenará el consumo de todos los edificios de la ciudad
    private int[] edificios;

    Ciudad (int i, int c, int e){
        this.Id = i;
        this.nCasas = c;
        this.nEdificios = e;
    }


    //Setters
    void setId(int i){
        this.Id = i;
    }

    void setnCasas(int c){
        this.nCasas = c;
    }

    void setnEdificios(int e){
        this.nEdificios = e;
    }

    void setConsumoCasa(int tam, int[] c){
        this.casas = new int[tam];
        for(i = 0 ; i < tam ; i++){
            this.casas[i] = c[i];
        }
    }

    void setConsumoEdificio(int tam, int[] e){
        this.edificios = new int[tam];
        for(i = 0 ; i < tam ; i++){
            this.edificios[i] = e[i];
        }
    }


    //Getters
    int getId(){
        return this.Id;
    }

    int getnCasas(){
        return this.nCasas;
    }

    int getnEdificios(){
        return this.nEdificios;
    }

    int[] getConsumoCasa(){
        return this.casas;
    }

    int[] getConsumoEdificio(){
        return this.edificios;
    }


}