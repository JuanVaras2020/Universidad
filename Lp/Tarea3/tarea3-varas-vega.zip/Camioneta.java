class Camioneta extends Vehiculo{

    Camioneta (int p){
        super(p);
    }
}