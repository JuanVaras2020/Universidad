class Edificio extends Edificacion{

    Edificio(int consumo){
        super(consumo);
    }

}