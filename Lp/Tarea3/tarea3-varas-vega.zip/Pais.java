class Pais implements Grafo{

    //Variables que se usan en el metodo ShortestPath
    int i = 0;
    int Peso = 0;
    static final int NO_PARENT = -1;


    private int nNodes;
    private int nArcos;

    //Node nodos: Arreglo de nodos para usar los metodos de Pais
    private Node nodos[];

    //int[][] MatAdy_mapa: Matriz de adyacencia para asignar los pesos entre nodos
    private int[][] MatAdy_mapa;

    //Empresa empresa: Objeto que guarda los datos de la empresa
    private Empresa empresa;


    Pais (int c, int a){
        this.nNodes = c;
        this.nArcos = a;
    }

    public void addNode(int id, Ciudad ciudad){
        Node n = new Node(id, ciudad);
        nodos[id] = n;
        MatAdy_mapa[n.getId()][n.getId()] = 0;
    }

    public void addEdge(int u, int v, int w){
        this.MatAdy_mapa[u][v] = w;
    }

    public int edgeWeight(int u, int v){
        return this.MatAdy_mapa[u][v];

    }
    
    public int shortestPath(int[][] MatAdy_mapa, int inicial, int fin){

        int nVertices = MatAdy_mapa[0].length; 
  
        int[] shortestDistances = new int[nVertices]; 
  
        boolean[] added = new boolean[nVertices]; 

        for (int vertexIndex = 0; vertexIndex < nVertices;  vertexIndex++) { 
            shortestDistances[vertexIndex] = Integer.MAX_VALUE; 
            added[inicial] = false; 
        } 

        shortestDistances[inicial]= 0; 
  
        int[] parents = new int[nVertices]; 

        parents[inicial] = NO_PARENT; 
  
        for (i = 1; i < nVertices; i++){  
            int nearestVertex = 0; 
            int shortestDistance = Integer.MAX_VALUE; 
            for (int vertexIndex = 0; vertexIndex < nVertices;  vertexIndex++) { 
                if (!added[vertexIndex] && shortestDistances[vertexIndex] <  shortestDistance)  { 
                    nearestVertex = vertexIndex; 
                    shortestDistance = shortestDistances[vertexIndex]; 
                } 
            } 
            added[nearestVertex] = true; 
  
            for (int vertexIndex = 0;  vertexIndex < nVertices;   vertexIndex++){ 
                int edgeDistance = MatAdy_mapa[nearestVertex][vertexIndex]; 
                  
                if (edgeDistance > 0 && ((shortestDistance + edgeDistance) <  shortestDistances[vertexIndex])){ 
                    parents[vertexIndex] = nearestVertex; 
                    shortestDistances[vertexIndex] = shortestDistance +  edgeDistance; 
                } 
            } 
        }
        auxShortestPath(inicial, shortestDistances, parents, fin); 
        return Peso;
    }

    /* auxShortestPath

    int startVertex
    int[] distances
    int[] parents
    int fin

    Función auxiliar al metodo ShortestPath, que le asigna a la variable Peso el peso del camino mas corto entre 2 nodos dados
    */
    void auxShortestPath(int startVertex, int[] distances, int[] parents, int fin){ 
        int nVertices = distances.length; 
          
        for (int vertexIndex = 0;  vertexIndex < nVertices;  vertexIndex++){ 
            if (vertexIndex != startVertex & vertexIndex == fin){ 
                Peso = distances[vertexIndex];
            } 
        } 
    }
    


    //Setters

    void setMatriz(int[][] m){
        this.MatAdy_mapa = m;
    }

    void setnNodes(int c){
        this.nNodes = c;
    }

    void setnArcos(int a){
        this.nArcos = a;
    }

    void CrearNodos(int tam){
        this.nodos = new Node[tam];
    }

    void setEmpresa(Empresa e){
        this.empresa = e;
    }

    //Getters
    int getnNodes(){
        return this.nNodes;
    }

    int getnArcos(){
        return this.nArcos;
    }

    Node[] getNodos(){
        return this.nodos;
    }
 
    int[][] getMatAdy_mapa(){
        return this.MatAdy_mapa;
    }

    Empresa getEmpresa(){
        return this.empresa;
    }


}