import java.io.*;
import java.util.*;

class Main{
    public static void main(String args[]){

        //int Contadores: contadores para leer archivos y hacer ciclos
        int i,j, cont = 0;
        int aux = 0;
        int pos = 0;

        //File archivos: Varaibles para leer archivos
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;

        //List<Integer> Listas: Listas donde se almacenará información de los archivos
        List<Integer> Lista_Mapa = new ArrayList<Integer>();
        List<Integer> Lista_Empresa = new ArrayList<Integer>();


        //LEER ARCHIVO MAPA
        try {
            archivo = new File ("mapa.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);

            String linea;
            while((linea=br.readLine())!=null){
                if (cont == 0){
                    Lista_Mapa.add(0,Integer.parseInt(linea));
                }
                else if (cont == 1){ 
                    Lista_Mapa.add(1,Integer.parseInt(linea));
                }
                else{
                    String[] l = linea.split(" ");
                    Lista_Mapa.add(cont,Integer.parseInt(l[0]));
                    Lista_Mapa.add(cont+1,Integer.parseInt(l[1]));
                    Lista_Mapa.add(cont+2,Integer.parseInt(l[2]));
                    cont = cont + 2;
                }
                cont = cont + 1;
            }
            cont = 0;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            try{                    
                if( null != fr ){   
                fr.close();     
                }                  
            }
            catch (Exception e2){ 
                e2.printStackTrace();
            }
        }
        //CERRAR ARCHIVO MAPA


        //LEER ARCHIVO EMPRESA
        try {
            archivo = new File ("empresa.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
   
            String linea;
            while((linea=br.readLine())!=null){
               
               Lista_Empresa.add(cont,Integer.parseInt(linea));
               cont = cont + 1;
            }
            cont = 0;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            try{                    
               if( null != fr ){   
                  fr.close();     
               }                  
            }
            catch (Exception e2){ 
               e2.printStackTrace();
            }
        }
        //CERRAR ARCHIVO EMPRESA

        //Ciudad[] ciudades: Arreglo donde se almacenarán todas las ciudades del grafo
        Ciudad[] ciudades = new Ciudad[Lista_Mapa.get(0)];


        //LEER ARCHIVO EDIFICACION

        try {
            archivo = new File ("edificaciones.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
   
            String linea;
            while((linea=br.readLine())!=null){
                if (cont%3 == 0){
                    String[] l = linea.split(" ");
                    ciudades[pos] = new Ciudad(Integer.parseInt(l[0]), Integer.parseInt(l[1]), Integer.parseInt(l[2]));
                }
    
                else if(cont%3 == 1){
                    String[] l = linea.split(" ");
                    int[] c = new int[ciudades[pos].getnCasas()];
                    for (i = 0 ; i < ciudades[pos].getnCasas() ; i++){
                        c[i] = Integer.parseInt(l[i]);
                    }
                    ciudades[pos].setConsumoCasa(ciudades[pos].getnCasas(), c);
                }
    
                else if(cont%3 == 2){
                    String[] l = linea.split(" ");
                    int[] e = new int[ciudades[pos].getnEdificios()];
                    for(i = 0 ; i < ciudades[pos].getnEdificios() ; i++){
                        e[i] = Integer.parseInt(l[i]);
                    }
                    ciudades[pos].setConsumoEdificio(ciudades[pos].getnEdificios(), e);
                }
                aux = aux +1;
                if (aux%3 == 0){
                    pos = pos + 1;
                }
                cont = cont + 1;
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
            finally{
                try{                    
                if( null != fr ){   
                    fr.close();     
                }                  
                }
                catch (Exception e2){ 
                e2.printStackTrace();
                }
            }

        //CERRAR ARCHIVO EDIFICACION


        //int [][] MatAdy_mapa: Matriz de adyacencia del grafo inicializada en 0
        int [][] MatAdy_mapa = new int[Lista_Mapa.get(0)][Lista_Mapa.get(0)];

        for (i = 0 ; i < Lista_Mapa.get(0) ; i++){
            for (j = 0 ; j < Lista_Mapa.get(0) ; j++){
                MatAdy_mapa[i][j] = 0;
            }
        }

        //Asignar el peso entre nodos a la matriz
        for (i = 2 ; i < Lista_Mapa.get(1)*3 ; i = i + 3 ){
            MatAdy_mapa[Lista_Mapa.get(i)][Lista_Mapa.get(i+1)] = Lista_Mapa.get(i+2);
        }

        //Empresa empresa: Objeto donde se guarda la información de la empresa
        Empresa empresa = new Empresa(Lista_Empresa.get(0), Lista_Empresa.get(1), Lista_Empresa.get(2));


        //Pais pais: Objeto donde se guarda la información del pais. También usa objetos creados anteriormente como la empresa y la matriz
        Pais pais = new Pais(Lista_Mapa.get(0), Lista_Mapa.get(1));
        pais.setMatriz(MatAdy_mapa);
        pais.setEmpresa(empresa);
        pais.CrearNodos(pais.getnNodes());
        for(i = 0 ; i < pais.getnNodes() ; i++){
            pais.addNode(i, ciudades[i]);
        }
        for(i = 2 ; i < pais.getnArcos()*3 ; i = i + 3){
            pais.addEdge(Lista_Mapa.get(i), Lista_Mapa.get(i+1), Lista_Mapa.get(i+2));
        }


        //int suma y optimo: Variables que se usarán para determinar la ciudad optima
        int suma = 0;
        int optimo = 0;

        //int [] SumaDeCaminos: Arreglo donde se almacenará la suma de los pesos de todos los caminos optimos tomando una ciudad fija como centro
        int[] SumaDeCaminos = new int[pais.getnNodes()];

        for (i = 0 ; i < pais.getnNodes() ; i++){
            for(j = 0 ; j < pais.getnNodes() ; j++){
                suma = suma + pais.shortestPath(MatAdy_mapa, i, j);
            }
            SumaDeCaminos[i] = suma;
            suma = 0;
        }
        for(i = 0 ; i < pais.getnNodes() ; i++){
            if(SumaDeCaminos[i] < SumaDeCaminos[optimo]){
                optimo = i;
            }
        }


        //int[] ConsumoTotalCasas y ConsumoTotalEdificios: Arreglos donde se almacenará el consumo de las casas y edificios por separado 
        int[] ConsumoTotalCasas = new int[pais.getnNodes()];
        int[] ConsumoTotalEdificios = new int[pais.getnNodes()];

        //int[] CostoDeCadaCiudad: Arreglo donde se almacenará el costo de viajar a cada ciudad
        int[] CostoDeCadaCiudad = new int[pais.getnNodes()];

        //int[] Utilidad: Arreglo donde se almacenará la utilidad de cada ciudad
        int[] Utilidad = new int[pais.getnNodes()];

        for(i = 0 ; i < pais.getnNodes() ; i++){
            if(ciudades[i].getnCasas() > 0){
                CostoDeCadaCiudad[i] = empresa.getPrecioKilometro()*SumaDeCaminos[i]*(ciudades[i].getnEdificios()+1);
            }
            else{
                CostoDeCadaCiudad[i] = empresa.getPrecioKilometro()*SumaDeCaminos[i]*(ciudades[i].getnEdificios());
            }
        }

        for(i = 0 ; i < pais.getnNodes() ; i++){
            for(j = 0 ; j < ciudades[i].getnCasas() ; j++){
                ConsumoTotalCasas[i] = ConsumoTotalCasas[i] + empresa.getPrecioBalon()*ciudades[i].getConsumoCasa()[j];
            }
            for(j = 0 ; j < ciudades[i].getnEdificios() ; j++){
                ConsumoTotalEdificios[i] = ConsumoTotalEdificios[i] +empresa.getPrecioLitro()*ciudades[i].getConsumoEdificio()[j]; 
            }
        }
        for(i = 0 ; i < pais.getnNodes() ; i++){
            Utilidad[i] = ConsumoTotalCasas[i] + ConsumoTotalEdificios[i] - CostoDeCadaCiudad[i];
        }


        //Prints
        System.out.println("La ciudad "+optimo+" es la ubicacion optima");
        for(i = 0 ; i < pais.getnNodes() ; i++){
            System.out.println("Ciudad "+i);
            System.out.println("-Utilidad: "+Utilidad[i]);
            if(ciudades[i].getnCasas() > 0){
                System.out.println("Se utilizaron "+ciudades[i].getnEdificios()+" camiones cisterna y 1 camioneta");
            }
            else{
                System.out.println("Se utilizaron "+ciudades[i].getnEdificios()+" camiones cisterna y 0 camionetas");
            }
        }
    }
}