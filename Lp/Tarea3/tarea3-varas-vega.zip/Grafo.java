interface Grafo{
    public void addNode(int id, Ciudad ciudad);
    public void addEdge(int u, int v, int w);
    public int edgeWeight(int u, int v);
    public int shortestPath(int[][] m, int u, int v);
}

class Node{
    private int id;
    private Ciudad ciudad;

    public Node(int id, Ciudad ciudad){
        this.id = id;
        this.ciudad = ciudad;
    }


    //Setters
    void setId(int i){
        this.id = i;
    }

    void setCiudad(Ciudad c){
        this.ciudad = c;
    }

    //Getters
    public int getId(){
        return this.id;
    }
    public Ciudad getCiudad(){
        return this.ciudad;
    }
}