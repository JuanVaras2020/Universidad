class Edificacion{

    private int consumo;

    Edificacion (int c){
        this.consumo = c;
    }

    //Setter
    void setConsumo(int c){
        this.consumo = c;
    }

    //Getter
    int getConsumo(){
        return this.consumo;
    }
}