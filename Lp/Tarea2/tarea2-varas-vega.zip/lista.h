#include <stdio.h>

struct dato{
    void* contenido;
    char tipo;
}dato;

struct nodo {
    struct dato info;
    struct nodo* next;
}nodo;


struct lista {
    struct nodo* actual;
    struct nodo* head;
    struct nodo* tail;
    int length;
}lista;

void init(struct lista* a);
void clear(struct lista* a);
void insert(struct lista* a, int i, struct dato d); 
void append(struct lista* a, struct dato d);
void remover(struct lista* a, int i);
int length(struct lista* a);
struct dato* at(struct lista* a, int i);
