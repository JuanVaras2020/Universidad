#include "lista.h"
#include <stdlib.h>

void init(struct lista* a){
    a->actual=NULL;
    a->head=NULL;
    a->tail=NULL;
    a->length=0;
}
void clear(struct lista* a){
    int i;
    for (i = 0 ; i < length(a) ; i++){
        a->actual = a->head;
        if (a->actual->info.tipo =='l'){
            clear(a->actual->info.contenido);
        }
        a->head=a->actual->next;
        free(a->actual->info.contenido);
        free(a->actual);
    }
    a->length = 0;
}
void insert(struct lista* a, int i, struct dato d){
    struct nodo* dato;
    dato = (struct nodo*)malloc(sizeof(struct nodo));
    dato->info = d;
    int c;
    if (i == 0){
        if (length(a) == 0){
             dato->next=a->head;
             a->head = dato;
             a->tail = dato;
        }
        else{
            dato->next=a->head;
            a->head = dato;
        }
    }
    else if (i == length(a)){
            a->actual = a->tail;
            a->actual->next = dato;
            a->tail = dato;
    }
    else{
        a->actual=a->head;
        for(c = 0 ; c < i-1 ; c++){
            a->actual=a->actual->next;
        }
        dato->next = a->actual->next;
        a->actual->next = dato;
    }
    a->length++;
}
void append(struct lista* a, struct dato d){
    struct nodo* dato;
    dato = (struct nodo*)malloc(sizeof(struct nodo));
    dato->info = d;
    if (length(a) == 0){
        dato->next=a->head;
        a->head = dato;
        a->tail = dato;
    }
    else{
        a->actual = a->tail;
        a->actual->next = dato;
        a->tail = dato;
    }


    a->length++;

}
void remover(struct lista* a, int i){
    struct nodo* temp;
    int c;
    if (i == 0){
        if (length(a)==1){
            clear((struct lista*)a);
            a->length++;
        }
        else{
            a->actual = a->head->next;
            if (a->actual->info.tipo =='l'){
                clear((struct lista*)a->head->info.contenido);
            }
            free(a->head->info.contenido);
            free(a->head);
            a->head=a->actual;
        }
    }
    else{   
        a->actual=a->head;
        for(c = 0 ; c < i-1 ; c++){
            a->actual=a->actual->next;
        }
        if (i == length(a)-1){
            if(a->actual->info.tipo =='l'){
                clear((struct lista*)a->head->info.contenido);
            }
            free (a->actual->next->info.contenido);
            free (a->actual->next);
            a->tail = a->actual;
            
        }
        else{
            if (a->actual->info.tipo =='l'){
                clear((struct lista*)a->head->info.contenido);
            }
            temp = a->actual->next->next;
            free (a->actual->next->info.contenido);
            free (a->actual->next);
            a->actual->next=temp;
        }
    }   
    a->length--;

}
int length(struct lista* a){
    return a->length;
}

struct dato* at(struct lista* a, int i){
    int c;
    a->actual=a->head;
    for(c = 0 ; c < i ; c++){
        a->actual=a->actual->next;
    }
    return &a->actual->info;
}
