#include "funciones.h"

struct lista* map(struct lista* a, struct dato (*f)(struct dato)){
    struct lista* new=(struct lista*)malloc(sizeof(struct lista));
    int largo,i;
    largo = length(a);
    struct dato dato;
    init(new);
    for (i=0 ; i<largo ; i++){
        dato=*at(a,i);
        if (dato.tipo == 'l'){
            dato.contenido=map(dato.contenido,(*f));
        }
        dato = (*f)(dato); 
        append(new,dato);
    }
    return new;
}

float sum(struct lista* a){
    int largo,i;
    float suma = 0;
    struct dato* dato;
    largo=length(a);
    for (i=0 ; i<largo ; i++){
        dato = at(a,i);
        if (dato->tipo == 'l'){
            suma+=sum((struct lista*)dato->contenido);
        }
        else if (dato->tipo == 'i'){
            suma+=*(int*)dato->contenido;
        }
        else if (dato->tipo == 'f'){
            suma+=*(float*)dato->contenido;
        }
    }
    return suma;
}

void print(struct lista* a){
    int largo,i;
    struct dato* dato;
    largo=length(a);
    printf("[");
    for (i=0 ; i<largo ; i++){
        dato = at(a,i);
        if (dato->tipo == 'l'){
            print((struct lista*)dato->contenido);
        }
        else if (dato->tipo == 'i'){
            printf("%d",*(int*)dato->contenido);
        }
        else if (dato->tipo == 'f'){
            printf("%f",*(float*)dato->contenido);
        }
        if (i != length(a)-1){
            printf(",");
        }
    }
    printf("]");
}
float average(struct lista* a){
    int largo,i,largof;
    float suma=0,prom,ext;
    struct dato* dato;
    largo=length(a);
    largof=largo;
    for (i=0 ; i<largo ; i++){
        dato= at(a,i);
        if (dato->tipo == 'l'){
            ext=average((struct lista*)dato->contenido);
            if(ext==-1){
                largof--;
            }
            else{
                suma+=ext;
            }
        }
        else if (dato->tipo == 'i'){
            suma+=*(int*)dato->contenido;
        }
        else if (dato->tipo == 'f'){
            suma+=*(float*)dato->contenido;
        }
    }
    if(length(a)==0){
        return -1;
    }
    prom = (suma/largof);
    return prom;
}
