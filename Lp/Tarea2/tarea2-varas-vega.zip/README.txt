Juan Pablo Varas	201873600-7
Patricio Vega		201873532-9

Para compilar el programa se debe usar el Makefile y su funcion program. (Para limpiar los archivos .o se puede ejecutar su funcion clean)

Tubimos una complicacion con la funcion map. Por motivos que no pudimos descubrir, la funcion alterna entre direcciones de memoria y datos en si, cosa que puede dar resultados inesperados de vez en cuando (Colocamos este comentario para que sepan que entregamos sabiendo de este error) 
