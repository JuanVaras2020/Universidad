Proyecto: Pick Your Element

Juan Pablo Varas	201873600-7
Patricio Vega		201873532-9

El programa se corre por consola, con el comando python3 Main.py
