import random
from carta import Carta

class Mano:
    def __init__(self, mazo):
        self.man = []
        self.man.append(mazo.robarCarta())
        self.man.append(mazo.robarCarta())
        self.man.append(mazo.robarCarta())
        self.man.append(mazo.robarCarta())
        self.man.append(mazo.robarCarta())

    def JugarCarta(self, pos):
        carta = self.man[int(pos)]
        self.man.remove(carta)
        return carta

    def QuitarCarta(self, carta):
        self.man.remove(carta)

    def AnadirCarta(self, carta):
        self.man.append(carta)

    def getMano(self):
        return self.man

    def CantCartas(self):
        return len(self.man)

    def JugarCartaBot(self, flecha, historial):

        c_alta = Carta(0, "-", "-")
        c_baja = Carta(20, "-", "-")

        for carta in self.man:
            if carta.getEfecto() == "VOLTEAR" and carta.getNumero() <= 5 and flecha.getFlecha() == "ARRIBA":
                self.man.remove(carta)
                return carta

            if carta.getEfecto() == "VOLTEAR" and carta.getNumero() >= 10 and flecha.getFlecha() == "ABAJO":
                self.man.remove(carta)
                return carta

        for carta in self.man:
            if c_alta.getNumero() < carta.getNumero():
                c_alta = carta      #carta con numero mas alto

            if c_baja.getNumero() > carta.getNumero():
                c_baja = carta      #carta con numero mas bajo

        if flecha.getFlecha() == "ARRIBA" and c_alta.getNumero() >= 10:
            self.man.remove(c_alta)
            return c_alta

        if flecha.getFlecha() == "ABAJO" and c_baja.getNumero() <= 5:
            self.man.remove(c_baja)
            return c_baja

        nFuego = 0
        nAgua = 0
        nHierba = 0

        for carta,_ in historial:     #El historial es una lista de tuplas, y cada tupla tiene por elemento un par de cartas
            if carta.getElemento() == "FUEGO":
                nFuego = nFuego + 1

            if carta.getElemento() == "AGUA":
                nAgua = nAgua + 1

            if carta.getElemento() == "HIERBA":
                nHierba = nHierba + 1

        if nFuego > nAgua and nFuego > nHierba:
            for carta in self.man:
                if carta.getElemento() == "HIERBA":
                    self.man.remove(carta)
                    return carta

        if nAgua > nFuego and nAgua > nHierba:
            for carta in self.man:
                if carta.getElemento() == "FUEGO":
                    self.man.remove(carta)
                    return carta

        if nHierba > nAgua and nHierba > nFuego:
            for carta in self.man:
                if carta.getElemento() == "AGUA":
                    self.man.remove(carta)
                    return carta


        random.shuffle(self.man, random.random)
        carta = self.man[0]
        self.man.remove(carta)
        return carta

