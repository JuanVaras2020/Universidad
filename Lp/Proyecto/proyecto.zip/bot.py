class Bot:
    def __init__(self):
        self.nom = "Jugador 2"
        self.puntaje = 0

    def getNombre(self):
        return self.nom
    
    def getPuntaje(self):
        return self.puntaje
    
    def setNombre(self, nombre):
        self.nom = nombre
    
    def setPuntaje(self, p):
        self.puntaje = p

        
        


        


            
