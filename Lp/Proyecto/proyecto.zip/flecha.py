class Flecha:
    def __init__(self):
        self.direccion = "ARRIBA"
    
    def getFlecha(self):
        return self.direccion
    
    def setFlecha(self, dir):
        self.direccion = dir
