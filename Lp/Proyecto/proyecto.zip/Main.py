import random
from time import sleep
from carta import Carta
from jugador import Jugador
from mazo import Mazo
from mano import Mano
from bot import Bot
from flecha import Flecha

#Inicio Objetos-------------------------------------------------------------------------------------------------------------------------
Jugador = Jugador()
MazoJugador = Mazo()
MazoJugador.mezclar()
ManoJugador = Mano(MazoJugador)

Bot = Bot()
MazoBot = Mazo()
MazoBot.mezclar()
ManoBot = Mano(MazoBot)
flag = 0

Flecha = Flecha()

Historial = []

Turnos = []

Deck = Mazo()


#Fin Objetos---------------------------------------------------------------------------------------------------------------------------

#Inicio Funciones----------------------------------------------------------------------------------------------------------------------

#Agrega cartas al historial
def AgregarHistorial (cartaJ1,cartaJ2):
  Historial.append((cartaJ1,cartaJ2))


#Agrega datos a la lista Turnos
def AgregarTurno(ganador):
    Turnos.append(ganador)


#Quitar las 5 cartas del jugador al deck.
def InicioDeck():
    for i in ManoJugador.getMano():
        for d in Deck.getMazo():
            if str(i.getNumero())+" , "+i.getElemento()+" , "+i.getEfecto() == str(d.getNumero())+" , "+d.getElemento()+" , "+d.getEfecto():
                Deck.getMazo().remove(d)

#Actualizar el deck.
def ActulizarDeck(carta):
    for i in Deck.getMazo():
        if str(carta.getNumero())+" , "+carta.getElemento()+" , "+carta.getEfecto() == str(i.getNumero())+" , "+i.getElemento()+" , "+i.getEfecto():
            Deck.getMazo().remove(i)


#Voltea la direccion de la flecha
def VoltearFlecha():
    if Flecha.getFlecha() == "ARRIBA":
       Flecha.setFlecha("ABAJO")
    else:
        Flecha.setFlecha("ARRIBA")

#Imprime la flecha
def ImprimirFlecha():
    if Flecha.getFlecha() == "ARRIBA":
        print("                                                      |-----------|")
        print("                                                      |     *     |")
        print("                                                      |    * *    |")
        print("                                                      |   *   *   |")
        print("                                                      |  *** ***  |")
        print("                                                      |    * *    |")
        print("                                                      |    ***    |")
        print("                                                      |-----------|")
    else:
        print("                                                      |-----------|")
        print("                                                      |    ***    |")
        print("                                                      |    * *    |")
        print("                                                      |  *** ***  |")
        print("                                                      |   *   *   |")
        print("                                                      |    * *    |")
        print("                                                      |     *     |")
        print("                                                      |-----------|")


#Imprime el historial. El historial es una lista de a la que se le añaden tuplas de cartas, jugadas en cada turno
#Tambien usa la lista Turnos, que guarda Jugador, si el jugador gano el turno, Bot si el bot gano el turno y un 0 si hubo un empate
def ImprimirHistorial():
    cont = 1
    for carta1,carta2 in Historial:
        print("Turno "+str(cont))
        if Turnos[cont - 1] == "Jugador":
            print(Jugador.getNombre()+" uso la carta: ")
            ImprimirCarta(carta1)
            print("Para ganarle a "+Bot.getNombre()+" quien uso la carta: ")
            ImprimirCarta(carta2)
        elif Turnos[cont - 1] == "Bot":
            print(Bot.getNombre()+" uso la carta: ")
            ImprimirCarta(carta2)
            print("Para ganarle a "+Jugador.getNombre()+" quien uso la carta: ")
            ImprimirCarta(carta1)
        else:
            print("Hubo un empate entre "+Jugador.getNombre()+" y "+Bot.getNombre())
        cont = cont + 1

#Imprime los puntajes hasta el momento
def ImprimirPuntajes():
    print("\n"+Jugador.getNombre()+" tiene "+str(Jugador.getPuntaje())+ " puntos.")
    print(Bot.getNombre()+" tiene "+str(Bot.getPuntaje())+ " puntos.")

#Imprime la mano del jugador
def ImprimirMano():
    cont = 1
    print("\n")
    if VerTecnicaSecreta(ManoJugador)[0] and flag == 1:
        for carta in ManoJugador.getMano():
            print(str(cont)+"-> ("+str(carta.getNumero())+" , "+carta.getElemento()+" , "+carta.getEfecto()+")")
            cont = cont + 1
        print(str(cont)+"-> Usar la tecnica secreta.")

    else:
        for carta in ManoJugador.getMano():
            print(str(cont)+"-> ("+str(carta.getNumero())+" , "+carta.getElemento()+" , "+carta.getEfecto()+")")
            cont = cont + 1

#Imprime la carta dada
def ImprimirCarta(carta):
    print("("+str(carta.getNumero())+" , "+carta.getElemento()+" , "+carta.getEfecto()+")")

#Imprime el mazo restante del jugador (no en el orden que viene) sirve para ver que cartas quedan nada mas
def ImprimirDeckTracker():
    print("\n")
    for carta in Deck.getMazo():
        print("("+str(carta.getNumero())+" , "+carta.getElemento()+" , "+carta.getEfecto()+")")

#Activa el Efecto voltear
def VerEfecto_Voltear(carta1, carta2):
    if carta1.getEfecto() == "VOLTEAR":
        VoltearFlecha()

    if carta2.getEfecto() == "VOLTEAR":
        VoltearFlecha()

#Duplica el puntaje si el efecto esta
def VerEfecto_x2(carta, p):
    if carta.getEfecto() == "x2":
        return p*2

    else:
        return p

#Retorna Jugador si gano el jugador, Bot si gano el bot y Empate si hubo empate
def VerQuienGana(carta1, carta2, flecha):
    if carta1.getNumero() == carta2.getNumero() and carta1.getElemento() == carta2.getElemento():
        return "Empate"

    elif carta1.getElemento() == "FUEGO" and carta2.getElemento() == "AGUA":
        return "Bot"

    elif carta1.getElemento() == "AGUA" and carta2.getElemento() == "HIERBA":
        return "Bot"

    elif carta1.getElemento() == "HIERBA" and carta2.getElemento() == "FUEGO":
        return "Bot"

    elif carta1.getElemento() == "FUEGO" and carta2.getElemento() == "HIERBA":
        return "Jugador"

    elif carta1.getElemento() == "HIERBA" and carta2.getElemento() == "AGUA":
        return "Jugador"

    elif carta1.getElemento() == "AGUA" and carta2.getElemento() == "FUEGO":
        return "Jugador"

    elif carta1.getNumero() < carta2.getNumero() and flecha.getFlecha() == "ARRIBA":
        return "Bot"

    elif carta1.getNumero() > carta2.getNumero() and flecha.getFlecha() == "ABAJO":
        return "Bot"

    elif carta1.getNumero() < carta2.getNumero() and flecha.getFlecha() == "ABAJO":
        return "Jugador"

    elif carta1.getNumero() > carta2.getNumero() and flecha.getFlecha() == "ARRIBA":
        return "Jugador"

#Roba cartas del Mazo.
def RobandoCartas():
    c = MazoJugador.robarCarta()
    b = MazoBot.robarCarta()
    ManoJugador.getMano().append(c)
    ManoBot.getMano().append(b)

#Retorna una lista cuyo primer elemento es True, seguido de las 3 cartas que cumplen con la tecnica secreta si
#se puede, y una lista con solo el elemento False si no
def VerTecnicaSecreta(mano):
    lista = []
    aux = [True]

    for carta in mano.getMano():
        lista.append(carta.getNumero())

    seis = 0
    siete = 0
    ocho = 0
    nueve = 0
    diez = 0

    for i in lista:
        if i == 6:
            seis = seis + 1
        elif i == 7:
            siete = siete + 1
        elif i == 8:
            ocho = ocho + 1
        elif i == 9:
            nueve = nueve + 1
        elif i == 10:
            diez = diez + 1

    if seis == 3:
        for carta in mano.getMano():
            if carta.getNumero() == 6:
                aux.append(carta)

        return aux

    elif siete == 3:
        for carta in mano.getMano():
            if carta.getNumero() == 7:
                aux.append(carta)

        return aux

    elif ocho == 3:
        for carta in mano.getMano():
            if carta.getNumero() == 8:
                aux.append(carta)

        return aux

    elif nueve == 3:
        for carta in mano.getMano():
            if carta.getNumero() == 9:
                aux.append(carta)

        return aux

    elif diez == 3:
        for carta in mano.getMano():
            if carta.getNumero() == 10:
                aux.append(carta)

        return aux

    else:
        return [False]

#Fin funciones-------------------------------------------------------------------------------------------------------------------------


#Inicio Interfaz-----------------------------------------------------------------------------------------------------------------------

print("Hola, has entrado a 'Pick your element'\n")
nomJugador = input("Ingrese su nombre:\n")
Jugador.setNombre(nomJugador)
nomBot = input("Ingrese el nombre de su rival:\n")
Bot.setNombre(nomBot)

InicioDeck()
cont_empates = 0
rendirse=1

while (ManoJugador.CantCartas()!=0) or (MazoJugador.CantCartas()!=0):
    ImprimirPuntajes()
    ImprimirMano()
    ImprimirFlecha()
    num=input("¿Qué quieres hacer?\n"
    "1. Jugar una Carta\n"
    "2. Ver Puntajes\n"
    "3. Ver Historial\n"
    "4. Ver cartas que quedan en tu mazo\n"
    "5. Ver Reglas\n"
    "6. Rendirse\n")
    if num == "2":
        ImprimirPuntajes()
    elif num == "3":
        ImprimirHistorial()
    elif num == "4":
        ImprimirDeckTracker()
    elif num == "5":
        print("REGLAMENTO: \n")
        print("1. Gana la mayor cantidad de duelos con las cartas de tu mano\n")
        print("2. Una carta se ve así: (4, NORMAL, -) donde el primer elemento representa el numero, el segundo su tipo, y el tercero su efecto.\n")
        print("3. Existen 2 formas de ganar un duelo, por numero o por tipo:\n")
        print("         Si la flecha apunta hacia arriba, la carta con mayor numero ganará, y si apunta hacia abajo la carta con menor numero ganará. Peeero\n")
        print("         Si una carta le gana por tipo a otra, el numero no importará.\n")
        print("         El fuego le gana a la hierba, la hierba le gana al agua y el agua le gana al fuego.\n")
        print("4. Por ejemplo, la carta (7, FUEGO, -): le gana:\n")
        print("         En cualquier caso a cartas de HIERBA.\n")
        print("         Si la flecha apunta hacia arriba, a cartas NORMALES y de FUEGO cuyo numero sea menor a 7.\n")
        print("         Si la flecha apunta hacia abajo, a cartas NORMALES y de FUEGO cuyo numero sea mayor a 7.\n")
        print("         En ningun caso a cartas de AGUA.\n")
        print("5. En casos de empate entre cartas, la flecha se volteará, y jugarán una nueva carta cada uno. El puntaje asignado será equivalente a la cantidad de cartas que se jugaron.\n")
        print("6. Efectos:\n")
        print("         VOLTEAR: Voltea la flecha ANTES de comparar las cartas.\n")
        print("         x2: Si una carta con este efecto gana un duelo, se duplica el puntaje asignado.\n")
        print("7. Tecnica secreta:\n")
        print("         Si juntas en tu mano tres cartas de distinto tipo pero de mismo numero, puedes reemplazarlas por 3 cartas (15, NORMAL, -) o (1, NORMAL, -) de manera aleatoria.\n")
        print("         Esto no aplica si las 3 cartas están en la mano inicial.\n")
        print("8. Por ultimo, la regla mas importante es DIVERTIRSE.\n")
    elif num == "6":
        print("Has perdido")
        rendirse=0
        break
    elif num == "1":
        Puntaje_Jugador = 1
        Puntaje_Bot = 1
        ImprimirMano()

        flag = 1
        ncarta = input("¿Qué carta quiere jugar?")
        if int(ncarta) not in  range(ManoJugador.CantCartas() + 2) or ncarta == "0":
            print("La carta seleccionada no es valida")
            print("hola")

        elif VerTecnicaSecreta(ManoJugador)[0] and ncarta == str(ManoJugador.CantCartas() + 1):
            lista = VerTecnicaSecreta(ManoJugador)
            supercartas = [Carta(1, "NORMAL", "-"), Carta(15, "NORMAL", "-"), Carta(1, "NORMAL", "-"), Carta(15, "NORMAL", "-")]
            random.shuffle(supercartas, random.random)

            ManoJugador.QuitarCarta(lista[1])
            ManoJugador.QuitarCarta(lista[2])
            ManoJugador.QuitarCarta(lista[3])

            ManoJugador.AnadirCarta(supercartas[0])
            ManoJugador.AnadirCarta(supercartas[1])
            ManoJugador.AnadirCarta(supercartas[2])
        
        elif ncarta == ManoJugador.CantCartas() + 1:
            print("La carta seleccionada no es valida")
            

        else:
            cartaJ = ManoJugador.JugarCarta(int(ncarta) - 1)
            cartaB = ManoBot.JugarCartaBot(Flecha,Historial)
            print("\nLa carta que jugaste es: ")
            ImprimirCarta(cartaJ)
            sleep(2)

            print("\nLa carta jugada por "+Bot.getNombre()+" es: ")
            ImprimirCarta(cartaB)
            sleep(3)

            VerEfecto_Voltear(cartaJ, cartaB)

            ganador = VerQuienGana(cartaJ, cartaB, Flecha)

            if ganador == "Empate":
                print("\nHubo un empate!\n")
                cont_empates = cont_empates + 1
                VoltearFlecha()
                if ManoJugador.CantCartas()==0:
                    if MazoJugador.CantCartas != 0:
                        if MazoJugador.CantCartas() >= 5:
                            for i in range(5):
                                RobandoCartas()
                        else:
                            for i in range(MazoJugador.CantCartas()):
                                RobandoCartas()

            else:
                Puntaje_Jugador = VerEfecto_x2(cartaJ, Puntaje_Jugador + cont_empates)
                Puntaje_Bot = VerEfecto_x2(cartaB, Puntaje_Bot + cont_empates)

                if ganador == "Jugador":
                    print("\n"+Jugador.getNombre()+" ganó el duelo!")
                    Jugador.setPuntaje(Jugador.getPuntaje() + Puntaje_Jugador)

                elif ganador == "Bot":
                    print("\n"+Bot.getNombre()+" ganó el duelo!")
                    Bot.setPuntaje(Bot.getPuntaje() + Puntaje_Bot)

                if MazoJugador.CantCartas != 0:
                    if MazoJugador.CantCartas() >= cont_empates+1:
                        for i in range(cont_empates+1):
                            RobandoCartas()
                    else:
                        for i in range(MazoJugador.CantCartas()):
                            RobandoCartas()
                cont_empates = 0

            AgregarTurno(ganador)
            AgregarHistorial(cartaJ, cartaB)
            ActulizarDeck(cartaJ)

    else:
        print("\nLa opcion no es valida, intente nuevamente. \n")


print("\nEl juego ha acabado:")
if rendirse == 1:
    print("\nLos puntajes finales son:\n")
    ImprimirPuntajes()
    if Jugador.getPuntaje() > Bot.getPuntaje():
        print("\nFelicidades, has ganado\n")
    elif Jugador.getPuntaje() < Bot.getPuntaje():
        print("\nLastima has perdido. Mejor suerte a la proxima\n")
    else:
        print("\nHas empatado, casi lo logras.\n")
else:
    print("\nLastima has perdido. Mejor suerte a la proxima.\n")









