import random
from carta import Carta

class Mazo:

    #Constructor. Notar que los elementos de mazo son cartas, no listas
    def __init__(self):
        self.mazo = []
        self.mazo.append(Carta(1, "NORMAL", "-"))
        self.mazo.append(Carta(2, "NORMAL", "-"))
        self.mazo.append(Carta(3, "NORMAL", "VOLTEAR"))
        self.mazo.append(Carta(4, "NORMAL", "-"))
        self.mazo.append(Carta(5, "NORMAL", "x2"))
        self.mazo.append(Carta(6, "AGUA", "x2"))
        self.mazo.append(Carta(7, "AGUA", "-"))
        self.mazo.append(Carta(8, "AGUA", "VOLTEAR"))
        self.mazo.append(Carta(9, "AGUA", "-"))
        self.mazo.append(Carta(10, "AGUA", "-"))
        self.mazo.append(Carta(6, "HIERBA", "x2"))
        self.mazo.append(Carta(7, "HIERBA", "-"))
        self.mazo.append(Carta(8, "HIERBA", "VOLTEAR"))
        self.mazo.append(Carta(9, "HIERBA", "-"))
        self.mazo.append(Carta(10, "HIERBA", "-"))
        self.mazo.append(Carta(6, "FUEGO", "x2"))
        self.mazo.append(Carta(7, "FUEGO", "-"))
        self.mazo.append(Carta(8, "FUEGO", "VOLTEAR"))
        self.mazo.append(Carta(9, "FUEGO", "-"))
        self.mazo.append(Carta(10, "FUEGO", "-"))
        self.mazo.append(Carta(11, "NORMAL", "x2"))
        self.mazo.append(Carta(12, "NORMAL", "-"))
        self.mazo.append(Carta(13, "NORMAL", "VOLTEAR"))
        self.mazo.append(Carta(14, "NORMAL", "-"))
        self.mazo.append(Carta(15, "NORMAL", "-"))

    #Mezclador. Desordena la lista mazo
    def mezclar(self):
        random.shuffle(self.mazo, random.random)

    def getMazo(self):
        return self.mazo

    def CantCartas(self):
        return len(self.mazo)

    #Retorna la primera carta del mazo y la saca de este
    def robarCarta(self):
        carta = self.mazo[0]
        self.mazo.remove(carta)
        return carta
