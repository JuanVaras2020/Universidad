class Carta:
    def __init__(self, num, elem, efect):
        self.numero = num
        self.elemento = elem
        self.efecto = efect

    def getNumero(self):
        return self.numero
    
    def getElemento(self):
        return self.elemento

    def getEfecto(self):
        return self.efecto