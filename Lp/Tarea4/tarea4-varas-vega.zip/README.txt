Juan Pablo Varas	201873600-7
Patricio Vega		201873532-9
