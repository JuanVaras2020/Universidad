import re
import os.path

#FUNS UPDATE

'''
ConstructorUpdateYSelect

Entradas:
string arc

Salida:
diccionario dicc

Esta funcion pertenece al bloque de Update y Select. Recive el nombre de un archivo .csv. Esta funcion se
encarga de crear un diccionario cuyas llaves son el nombre de las columnas del archivo y sus valores son listas
cuyos elementos son los datos de las columnas correspondientes a las llaves de arriba a abajo. Tambien crea una
llave cuyo valor es una lista con el orden de las columnas de izquierda a derecha.
'''
def ConstructorUpdateYSelect(arc):

    dicc={}
    lis_aux=[]
    contador=0
    if os.path.isfile(arc):
        fi = open(arc,"r")
        lista=[]
        for linea in fi:
            a=linea.strip().split(",")
            if contador==0:
                for i in a:
                    lis_aux.append(i)
                    dicc[i]=[]
                    lista.append(i)
            else:
                for (llave, valor) in zip(lis_aux, a):
                    dicc[llave].append(valor)
            contador=1
        dicc["estonoesunacolumna"]=lista
        fi.close()
        return dicc
    else:
        print("El archivo no existe")
        exit()

'''
ActualizarArcUpdate

Entradas:
diccionario dic
string arc

Salida:
No retorna

Esta funcion pertenece al bloque de Update. Recive el nombre de un archivo .csv y un diccionario cuya estructura es la
explicada en ConstructorUpdateYSelect. Esta funcion se encarga de actualizar los datos en el archivo entregado.
'''
def ActualizarArcUpdate(dic, arc):
	fi = open(arc, "w")

	lista = dic["estonoesunacolumna"]
	dic.pop("estonoesunacolumna")
	cont = 1
	lista_grande = []
	for col in lista:
		if cont == len(lista):
			fi.write(col)
		else:
			fi.write(col+",")
			cont = cont + 1
		lista_grande.append(dic[col])
	fi.write("\n")

	lis_tam = range(len(dic[lista[0]]))
	lis_tam2 = range(len(lista_grande))
	cont = 1

	for i in lis_tam:
		for j in lis_tam2:
			if cont == len(lis_tam):
				fi.write(lista_grande[j][i]+"\n")
			else:
				fi.write(lista_grande[j][i]+",")
				cont = cont +1
		cont = 1

	fi.close()

'''
separador

Entradas:
string grupo (condiciones del where)

Salida:
lista listas (listas de listas de condiciones del where)

Esta funcion pertenece al bloque de Update y Select. Esta funcion se encarga hacer una separacion conveniente de las condiciones.
del where
'''

def separador(grupo):
		listas=[]
		lista=grupo.split("OR")
		for grupos in lista:
			listas.append(grupos.split("AND"))
		return listas

'''
SioNo

Entradas:
string igualdad (candicion del where)
string tabla (nombre del archivo)

Salida:
Bool True
Boll False

Esta funcion pertenece al bloque de Update. Verifica si la candicion entregada se cumple o no
'''
def SioNo(igualdad,tabla):
	cond=igualdad.split("=")
	dicc=ConstructorUpdateYSelect(tabla+".csv")
	cond=[cond[0].strip(),cond[1].strip()]
	if cond[0] in dicc.keys():
		for valores in dicc[cond[0]]:
			valor=cond[1].strip("'")
			if valor == valores:
				return True
	return False

'''
Reconstructor

Entradas:
string sett (remplazo)
lista where (lista de condiciones que cumplen)
string tabla (nombre del archivo)

Salida:
dicc dic (diccionario actualizado)


Esta funcion pertenece al bloque de Update. En base a las candiones y lugar recibida del where actualiza la
tabla con el remplazo requerido del set.
'''
def Reconstructor(sett,where,tabla):
	dicc=ConstructorUpdateYSelect(tabla+".csv")
	listalugares=[]
	for donde in where:
		cond=donde.split("=")
		cond=[cond[0].strip(),cond[1].strip()]
		if cond[0] in dicc.keys():
			for valores in dicc[cond[0]]:
				valor=cond[1].strip("'")
				if valor == valores:
					listalugares.append(dicc[cond[0]].index(valor))
	sett=sett.split(",")
	listaset=[]
	for i in sett:
		sett=i.split("=")
		sett=[sett[0].strip(),sett[1].strip()]
		listaset.append(sett)
		for columna,valor in listaset:
			for lugar in listalugares:
				dicc[columna][lugar]=valor
	return dicc

'''
Update

Entradas:
string entrada

Salida:
No retorna

Esta funcion pertenece al bloque de Update y es la funcion principal del bloque. Recive el nombre del archivo a trabajar.
Se encaarga de leer las columnas y los datos que se van a actualizar por medio de expresiones regulares, y con la
ayuda de funciones auxiliares genera un archivo con los datos actualizados.
'''
def Update(entrada):
    verUpdate= re.compile(r"\s*UPDATE\s+(.+?)\s+SET\s+((?:[^=\n]+\s+=(?:\s*[0-9]+|\s*\'.+?\'))\s*(?:(?:,[^=\n]+\s+=(?:\s*[0-9]+|\s*\'.+?\'))*))\s+WHERE\s+((?:[^=\n]+=(?:\s*[0-9]+|\s*\'.+?\'))(?:\s+AND\s+(?:[^=\n]+=(?:\s*[0-9]+|\s*\'.+?\'))|\s+OR\s+(?:[^=\n]+\s+=(?:\s*[0-9]+|\s*\'.+?\')))*)\s*;")
    match=verUpdate.match(entrada)
    if match:
        tabla= match.group(1)
        sett= match.group(2)
        donde= match.group(3)
        lista1=separador(donde)

        listadeverdad=[]
        for grupo in lista1:
            cont=0
            for igualdad in grupo:
                if SioNo(igualdad,tabla)!=True:
                    cont=1
            if cont==1:
                listadeverdad.append(False)
            else:
                listadeverdad.append(True)
        listadonde=[]
        if True not in listadeverdad:
            print("Condiciones invalidas o columna inexistente")
            return 0
        while True in listadeverdad:
            lugar=listadeverdad.index(True)
            for igualdad in lista1[lugar]:
                listadonde.append(igualdad)
                listadeverdad[lugar]="OK"
        dic_actualizado = Reconstructor(sett,listadonde,tabla)
        ActualizarArcUpdate(dic_actualizado, tabla+".csv")
        print("Actualizacion exitosa.")
    else:
        print("Error de sintaxis")
        return 0

#FUNS UPDATE FIN

#FUNS INSERT
'''
ConstructorInsert

Entradas:
string arc

Salida:
diccionario dicc

Esta funcion pertenece al bloque de Insert. Recive el nombre de un archivo .csv y crea un diccionario cuyas
llaves son numeros de 0 hasta i - 1, donde i representa el numero de la ultima linea del archivo, y sus valores
son listas cuyos elementos son los datos del archivo leidos de izquierda a derecha.
'''
def ConstructorInsert(arc):

	dicc={}
	contador=0
	if os.path.isfile(arc):
		fi = open(arc,"r")
		for linea in fi:
			dicc[contador] = linea.strip().split(",")
			contador = contador + 1

		dicc[contador] = []
		fi.close()
		return dicc
	else:
		print("Error al leer archivo")
		return 0

'''
ActualizarArcInsert

Entradas:
diccionario dic
string arc

Salida:
No retorna

Esta funcion pertenece al bloque de Insert. Recive el nombre de un archivo .csv y un diccionario cuya estructura es la
explicada en ConstructorInsert y que fue mutado durante el programa. Con el diccionario, se crea un nuevo archivo .csv
de nombre arc.
'''
def ActualizarArcInsert(dic, arc):
	fi = open(arc,"w")
	cont = 1

	lista = list(dic.keys())
	lista.sort()
	for llave in lista:
		for valor in dic[llave]:
			valor=valor.strip().strip("'")
			if cont == len(dic[llave]):
				fi.write(valor+"\n")
			else:
				fi.write(valor+",")
				cont = cont + 1
		cont = 1
	fi.close()

'''
ValoresInsert

Entradas:
lista Columnas
lista Valores
lista Coldic

Salida:
lista lista

Esta funcion pertenece al bloque de Insert. Recive una lista Columnas que representa las columnas a las que se van a
ingresar los valores, una lista Valores que tiene los valores a ingresar y una lista Coldic, que tiene el nombre de todas
las columnas. Esta funcion genera una lista con los datos que se van a ingresar en el orden especificado por las columnas.
'''
def ValoresInsert(Columnas, Valores, Coldic):
	lista = []
	lis_aux = []
	cont=0
	for i in Columnas:
		if i in Coldic:
			t = (i, Valores[cont])
			lis_aux.append(t)
			lis_aux.append(i)
			cont = cont + 1
	for i in Coldic:
		if i not in lis_aux:
			t = (i,"")
			lis_aux.append(t)
		else:
			lis_aux.remove(i)
	for i in Coldic:
		for c,v in lis_aux:
			if c == i:
				lista.append(v)
	return lista

'''
Insert

Entradas:
string entrada

Salida:
entero 0 solo si hubo un error

Esta funcion pertenece al bloque de Insert y es la funcion principal del bloque. Recive un string que es el nombre del
archivo a trabajar. Se encarga de leer lo que se va a ingresar y por medio de expresiones regulares y funciones auxiliares
inserta datos a el archivo ingresado.
'''
def Insert(entrada):

    Alf = re.compile(r'\s*INSERT\s+INTO\s+([a-zA-Z]+)* \(\s*(.+?)\s*\)\s+VALUES\s+\(\s*(.+?)\s*\)\s*;')
    S = Alf.search(entrada)
    AlfMa = Alf.match(entrada)

    if AlfMa:
        if len(S.group(2).strip().split(",")) != len(S.group(3).strip().split(",")):
            print ("Error de sintaxis.")
            return 0
        dic = ConstructorInsert(S.group(1)+".csv")
        llave = max(list(dic.keys()))
        Col = S.group(2).strip().split(",")
        cont = 0
        for valor in Col:
            Col[cont] = valor.strip()
            cont = cont + 1
        Val = S.group(3).strip().split(",")
        dic[llave] = ValoresInsert(Col,Val,dic[0])

        ActualizarArcInsert(dic, S.group(1)+".csv")

        print("Insercion exitosa")
    else:
        print("Error de sintaxis.")
        return 0

#FUNS INSERT FIN

#FUNS SELECT

'''
listaordenada

Entradas:
lista listas (listas de listas de columunas)

Salida:
lista listaorden (listas de listas de filas)

Esta funcion pertenece al bloque de Select. Recibe una listas de listas de columunas y la retorna a una lista de listas de filas.
'''
def listaordenada(listas):
    if listas!=[]:
    	listaorden=[]
    	listtam=range(len(listas))
    	listtam2=range(len(listas[0]))
    	for i in listtam:
    		for j in listtam2:
    			if len(listaorden)<j+1:
    				listaorden.append([])
    			listaorden[j].append(listas[i][j])
    	return listaorden
    else:
        print("Una columna no existe")
        exit()

'''
Ascendente

Entradas:
lista lista
entero ind

Salida:
lista lista_retornada

Esta funcion pertenece al bloque de Select. Recive una lista de listas donde cada lista representa una columna y un indice
Esta funcion se encarga de retornar una lista de listas pero ordenando las columnas de forma ascendente con respecto a una
columna especificada con el indice, siendo este el numero que indica que lista se debe ordenar.
'''
def Ascendente(lista, ind):
	lista_campo = []
	lista_retornada = []

	for lis in lista:
		lista_campo.append(lis[ind])

	lista_campo.sort()

	for valor in lista_campo:
		for lis in lista:
			if valor in lis and lis not in lista_retornada:
				lista_retornada.append(lis)

	return lista_retornada

'''
Descendente

Entradas:
lista lista
entero ind

Salida:
lista lista_retornada

Esta funcion pertenece al bloque de Select. Recive una lista de listas donde cada lista representa una columna y un indice
Esta funcion se encarga de retornar una lista de listas pero ordenando las columnas de forma descendente con respecto a una
columna especificada con el indice, siendo este el numero que indica que lista se debe ordenar.
'''
def Descendente(lista, ind):
	lista_campo = []
	lista_retornada = []

	for lis in lista:
		lista_campo.append(lis[ind])

	lista_campo.sort()
	lista_campo.reverse()

	for valor in lista_campo:
		for lis in lista:
			if valor in lis and lis not in lista_retornada:
				lista_retornada.append(lis)

	return lista_retornada


'''
SinINNERJOIN

Entradas:
diccionario dic
lista lista
lista titulo

Salida:
lista lista_retornada

Esta funcion pertenece al bloque de Select. Recive una lista de listas donde cada lista representa una columna y una
lista con las columnas pedidas. Esta funcion se encarga de retornar una lista de listas pero ordenando las columnas
de forma descendente con respecto a una columna especificada con el titulo. Esta funcion solo funciona cuando
no existe el INNER JOIN.
'''
def SinINNERJOIN(dic,lista,titulo):
    listafinal=[]
    cont = 0
    c = 0
    p = 0
    lista_return = []
    dicc=dic
    for pal in lista: #busca en la lista una condicion que sea tipo columna=columna
      aux = pal.strip().split("=")
      val,val2 = aux
      val=val.strip()
      val2=val2.strip()
      ultimo=len(val2)-1
      if ultimo>0:
        if val2[0]!="'" and val2[ultimo]!="'":
            try:
                int(valor)
            except:           #si la encuentra crea un nuevo diccionario con los datos requerido y finalmente elimina la condicion de la lista
                dicc={}
                if val and val2 in dic.keys():
                    lis_1 = dic[val]
                    lis_2 = dic[val2]
                    cont = 1
                if cont == 1:
                    for i in lis_1:
                        if i == lis_2[c]:
                             if i not in lista_return:
                                for cosas in titulo:
                                    if cosas not in dicc.keys():
                                        dicc[cosas]=[]
                                    cosas=cosas.strip()
                                    dicc[cosas].append(dic[cosas][c])
                        c = c + 1
                    c = 0
                    lista.remove(pal)
    for pal in lista:       #en base a todas las condiciones crea la lista de columnas que se mostraran
        aux = pal.strip().split("=")
        val,val2 = aux
        val=val.strip()
        val2=val2.strip()
        lis_1 = dicc[val]
        cont=0
        listafinal=[]
        for i in lis_1:
            if i == val2.strip("'"):
                for cosas in titulo:
                    lista_return.append(dicc[cosas][p])
            else:
                p = p + 1
        p=0
        listafinal.append(lista_return)
    return(listafinal)

'''
SioNoSelect

Entradas:
lista igualdad
entero innerjoin
string tabla

Salida:
Retorna segun condiciones

Esta funcion pertenece al bloque de Select.
'''
def SioNoSelect(igualdad,innerjoin,tabla):
	cond=igualdad.split("=")
	cond=[cond[0].strip(),cond[1].strip()]
	valor=cond[1]
	if innerjoin!=None:
		dicc=ConstructorUpdateYSelect(innerjoin+".csv")
		ultimo=len(valor)-1
		if ultimo>0:
			if valor[0]=="'" and valor[ultimo]=="'":
				valor=valor.strip("'")
				return auxSioNo(cond,valor,dicc)
		try:
			int(valor)
			return auxSioNo(cond,valor,dicc)
		except:
			try:
				columnas1=cond[0].split(".")
				columnas2=cond[1].split(".")
				columnas1=[columnas1[0].strip(),columnas1[1].strip()]
				columnas2=[columnas2[0].strip(),columnas2[1].strip()]
				dicc2=ConstructorUpdateYSelect(tabla+".csv")
				if columnas1[0]==tabla:
					if columnas2[0]==innerjoin:
						if columnas1[1] in dicc2.keys():
							if columnas2[1] in dicc.keys():
								return True
				return False
			except:
				   print("Error de Sintaxis")
	else:
		dicc=ConstructorUpdateYSelect(tabla+".csv")
		ultimo=len(valor)-1
		if ultimo>0:
			if valor[0]=="'" and valor[ultimo]=="'":
				valor=valor.strip("'")
				return auxSioNo(cond,valor,dicc)
		try:
			int(valor)
			return auxSioNo(cond,valor,dicc)
		except:
			if cond[0] in dicc.keys() and cond[1] in dicc.keys():
				return True
			return False

'''
printeo

Entradas:
lista listasdelistas
lista listaorden

Salida:
No Retorna

Esta funcion pertenece al bloque de Select. Recibe una lista de listas donde cada lista representa una columna y una
listaorden que cada lista representa una fila. Esa funcion se encarga de printear de forma ordenada los pedido por el
select
'''
def printeo(listasdelistas,listaorden):
    lens = []
    for col in listasdelistas:
        try:
            lens.append(max([len(v) for v in col]))
            fila= "  ".join(["{:<" + str(l) + "}" for l in lens])
        except:
            print(" ")
    for row in listaorden:
        print(fila.format(*row))
'''
auxSioNo

Entradas:
lista lista
entero ind
diccionario dicc

Salida:
lista lista_retornada

Esta funcion pertenece al bloque de Select. Recive una lista de listas donde cada lista representa una columna, un indice y
un diccionario con los datos del archivo. Esta funcion se encarga de retornar una lista de listas pero ordenando las
columnas de forma descendente con respecto a una columna especificada con el indice, siendo este el numero que
indica que lista se debe ordenar.
'''
def auxSioNo(cond,valor,dicc):
	if cond[0] in dicc.keys():
		for valores in dicc[cond[0]]:
			if valor == valores:
				return True
	return False

'''
cambios

Entradas:
lista listadelista
innerjoin str
tabla str
columnas lista

Salida:
listita list

Esta funcion pertenece al bloque de Select. Separa los casos de que exista innerjoin o no, despues en  base a las condiciones
crea una lista de lista con las columnas que finalmente se monstraran en pantalla.

'''
def cambios(lista,innerjoin,tabla,columnas):
    listita=[]
    if innerjoin!=None: #separacion de casos
        dicc3={}
        for condo in lista: #busca en la lista una condicion que sea tipo tabla.col1=tabla2.col2
            cond=condo.split("=")
            cond=[cond[0].strip(),cond[1].strip()]
            valor=cond[1]
            ultimo=len(valor)-1
            if ultimo>0:
                if valor[0]!="'" and valor[ultimo]!="'":
                    try:
                        int(valor)
                    except:
                        columnas1=cond[0].split(".")
                        columnas2=cond[1].split(".")
                        if len(columnas1)==1 or len(columnas2)==1:
                            print("Error de Sintaxis")
                            exit()
                        columnas1=[columnas1[0].strip(),columnas1[1].strip()]
                        columnas2=[columnas2[0].strip(),columnas2[1].strip()]
                        dicc=ConstructorUpdateYSelect(tabla+".csv")
                        dicc2=ConstructorUpdateYSelect(innerjoin+".csv")
                        for col in columnas:   #se crea una diccionario general para la condicion y finalmente se eliminar la condicion de la lista
                            if col in dicc.keys():
                                dicc3[col]=dicc[col]
                            if col in dicc2.keys():
                                dicc3[col]=dicc2[col]
                        lista.remove(condo)
        if dicc3!={}:
            if lista!=[]:
                for cond in lista: #restricciones de condiciones para finalmente crear una lista de columnas que se van a mostrar
                    cond=cond.split("=")
                    cond=[cond[0].strip(),cond[1].strip()]
                    valor=cond[1]
                    ultimo=len(valor)-1
                    lugar=dicc3[cond[0]].index(valor.strip("'"))
                    for orden in columnas:
                        cont=0
                        for valores in dicc3.keys():
                            if orden==valores:
                                try:
                                    listita[cont].append(dicc3[valores][lugar])
                                except:
                                    listita.append([])
                                    listita[cont].append(dicc3[valores][lugar])
                            cont+=1
                return(listita)
            else:   #si la lista esta vacia se mostrara todos las columnas del dicicionario
                for i in dicc3.values():
                    listita.append(i)
                return listita
        else: #si el dicc3 esta vacio significa que de tabla.col=tabla2.col col son distintos y retorna una lista vacia.
            return([[]])
    else:  #entra en el caso que no exista innerjoin
        dicc=ConstructorUpdateYSelect(tabla+".csv")
        listita = SinINNERJOIN(dicc,lista,columnas)
        return listita
'''
Select

Entradas:
codigo str

Salida:
No retorna

Esta funcion pertenece al bloque de Select y es la funcion principal del bloque. Recibe el nombre del archivo a trabajar.
Se encaarga de leer las columnas y los datos que se van a mostrar por medio de expresiones regulares, y con la
ayuda de funciones auxiliares muestra la tabla pedida.
'''

def Select(codigo):
    verSelect= re.compile(r"\s*SELECT\s+((?:.+?\s*(?:,\s*.+?)*)|\*)\s+FROM\s+([^=\n ]+)(?:(?:\s+INNER\s+JOIN\s+([^=\n ]+))?)(?:(?:\s+WHERE\s+((?:[^=\n ]+\s*=(?:\s*[0-9]+\s*|\s*\'.+?\')\s*|(?:\s*[^=\n]+\s*=\s*[^=\n ]+\s*))(?:(?:\s*AND\s*|\s*OR\s*)\s+(?:(?:[^=\n]+\s*=(?:\s*[0-9]+|\s*\'.+?\')|(?:\s*[^=\n]+\s*=\s*[^=\n ]+))))*))?)(?:(?:\s+ORDER\s+BY\s+([^=\n ]+)\s+(ASC|DESC))?)\s*;")
    match=verSelect.match(codigo)
    if match:
        columnas= match.group(1)
        tabla= match.group(2)
        innerjoin=match.group(3)
        where=match.group(4)
        columnaorden=match.group(5)
        upodown=match.group(6)

        dicc=ConstructorUpdateYSelect(tabla+".csv")
        listacolumna=[]
        listasdelistas=[]
        cont=0
        if columnas=='*':
                columnas=dicc["estonoesunacolumna"]
        else:
            columnas2=columnas.split(",")
            columnas=[]
            for i in columnas2:
                columnas.append(i.strip())


        if innerjoin==None:
            for columna in columnas:
                listacolumna.append(columna.strip())
            for columna in listacolumna:
                listasdelistas.append(dicc[columna])
                if columnaorden != False:
                    if columna==columnaorden:
                        indice=cont
                    cont+=1
            listaorden=listaordenada(listasdelistas)

        if innerjoin != None:
            dicc2 = ConstructorUpdateYSelect(innerjoin+".csv")
            if columnas == ["*"]:
                columnas = dicc["estonoesunacolumna"]
                columnas2 = dicc2["estonoesunacolumna"]
                for columna in columnas:
                    listacolumna.append(columna.strip())
                for columna in columnas2:
                    listacolumna.append(columna.strip())
                for columna in listacolumna:
                    if columna in dicc.keys():
                        listasdelistas.append(dicc[columna])
                    if columna in dicc2.keys():
                        listasdelistas.append(dicc2[columna])
                    if columnaorden != False:
                        if columna==columnaorden:
                            indice=cont
                        cont+=1
                listaorden=listaordenada(listasdelistas)
            else:
                for columna in columnas:
                    listacolumna.append(columna.strip())
                for columna in listacolumna:
                    try:
                        listasdelistas.append(dicc[columna])
                    except:
                        listasdelistas.append(dicc2[columna])
                if columnaorden != False:
                    if columna==columnaorden:
                        indice=cont
                    cont+=1
                listaorden=listaordenada(listasdelistas)

        if where != None:
            listaseparada=separador(where)
            listadeverdad=[]
            for grupo in listaseparada:
                cont=0
                for igualdad in grupo:
                    if SioNoSelect(igualdad,innerjoin,tabla)!=True:
                        cont=1
                if cont==1:
                    listadeverdad.append(False)
                else:
                    listadeverdad.append(True)
            listadonde=[]
            if True not in listadeverdad:
                print("Condiciones invalidas o columna inexistente")
            while True in listadeverdad:
                lugar=listadeverdad.index(True)
                for igualdad in listaseparada[lugar]:
                    listadonde.append(igualdad)
                    listadeverdad[lugar]="OK"
            listasdelistas=cambios(listadonde,innerjoin,tabla,columnas)
            listaorden=listaordenada(listasdelistas)
        if columnaorden != None:
            if upodown=="ASC":
                listaorden=Ascendente(listaorden,indice)
            else:
                listaorden=Descendente(listaorden,indice)
        printeo(listasdelistas,listaorden)
    else:
        print ("Error de sintaxis")
        return 0

print("Bienvenido al lugar donde podra modificar y buscar datos en archivos .csv tanto como quiera.")
print("Para salir del programa ingrese el numero cero.")
flag = 0
while(flag == 0):

    sentencia = input("Ingrese su comando usando las reglas propuestas: \n")
    sentencia= sentencia.strip()

    if sentencia[0] == "U":
        Update(sentencia)

    elif sentencia[0] == "S":
        Select(sentencia)

    elif sentencia[0] == "I":
        Insert(sentencia)

    elif sentencia == "0":
        flag = 1

    else:
        print("Error de sintaxis, intentelo denuevo. \n")