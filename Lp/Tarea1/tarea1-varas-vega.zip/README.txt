Juan Pablo Varas	201873600-7
Patricio Vega		201873532-9

El programa recibe las sentencias especificadas por la tarea via teclado, y para cerrarlo se debe ingresar un cero, tal como
dice en las indicaciones de la consola al ejecutarlo.


