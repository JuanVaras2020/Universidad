import java.util.regex.Matcher; 
import java.util.regex.Pattern;
import java.io.*;
import java.util.Hashtable;
import java.util.Scanner;
import javax.script.ScriptEngineManager;
import javax.script.ScriptEngine;
import javax.script.ScriptException;


class Funciones extends Thread{

    static String funcion;
	static String result ; 
    static String finish;

    static void evaluar(String f) throws ScriptException{
        ScriptEngineManager mgr = new ScriptEngineManager();
    	ScriptEngine engine = mgr.getEngineByName("JavaScript");

		Object evaluado = engine.eval(f);
		Object temp = 0.5;

		if (evaluado.getClass() == temp.getClass()){
			double num = (double)evaluado;
			result = num+"";
		}
		else{
			int resu = (int)evaluado;
			result = resu+"";
		}

    }

	public static String remplazo(String texto, String que, String porquien) {
        int largo = texto.length();
		if (texto.charAt(largo-1) == 'x') {
			
			texto = texto.substring(0, largo-1) + porquien; 
			
		}
		else {
		
			String[] particion = texto.split(que);
			int cont = 0;
			for (String i: particion) {
				if (cont==0) {
					texto = i;
					cont++;
				}
				else {
					texto =	texto + porquien + i;
				}
			}
		}
		
		return texto;
    }

    public static String calcular(String operacion, String valor, Hashtable<String, String> ecuaciones) {
        String formula = ecuaciones.get(operacion);
		String pattern = "([A-z][(][x][)])";
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(formula);
		int cont = 0;
		while(m.find()) {
			String resultado = calcular (m.group(), valor, ecuaciones);
			int inicio = m.start();
			int termino = m.end();
			int fin = formula.length();

            funcion = resultado;
            Funciones T_1 = new Funciones();
			T_1.start();
			while(T_1.isAlive()){}
			resultado = result;

            formula = formula.substring(0, inicio) + "(" + result + ")" + formula.substring(termino,fin);


			cont=1;
			m = p.matcher(formula);
		}
		if (cont==0) {
			formula = remplazo(formula,"x",valor);
		}
        return formula;
    }

	public static void main (String[] args) throws ScriptException{

		FileReader archi = null;
		BufferedReader archivo = null;
		Hashtable<String, String> ecuaciones = new Hashtable<String, String>();

        int n = 0;
		int i;

		String operacion = "";

		try {
			 
			archi = new FileReader("funciones.txt");
			archivo = new BufferedReader(archi);
			 
			n = Integer.parseInt(archivo.readLine());
			 
			String linea;
			while ((linea=archivo.readLine())!=null) {
				int largo = linea.length();
				ecuaciones.put(linea.substring(0,4),linea.substring(5,largo)); 
			}

		}
	    catch(Exception e){e.printStackTrace();
	    }finally{
	    try{                    
	    	if( null != archi ){archi.close();}                  
	    }catch (Exception e2){e2.printStackTrace();}
	    }
		 
		System.out.println("Funciones ingresadas!");

		while (!(operacion.equals("0"))){
			Scanner input = new Scanner(System.in);
			System.out.println("Si desea salir, ingrese un 0.");
			System.out.print("Ingrese operacion: ");
			operacion = input.next();

			if (operacion.equals("0")){
				break;
			}
			
			String[]valores = operacion.split("\\(");
			valores = valores[1].split("\\)");
			String valor = valores[0];

			operacion = remplazo(operacion, valor,"x");
			finish = calcular(operacion, valor, ecuaciones);

			funcion = finish;

			Funciones T_1 = new Funciones();
			T_1.start();
			while(T_1.isAlive()){}

			System.out.println(result);
		}
    }

    public void run(){
        try {
			evaluar(funcion);
		} catch (ScriptException e) {
			e.printStackTrace();
		}

    }
}