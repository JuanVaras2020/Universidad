//Clase que implemente MergeSort

public class MergeSort extends Ordenar{

    public static void Merge(int[] arr, int[] izq_arr, int med_i, int[] der_arr, int med_d)
    {
        int i = 0;
        int j = 0;
        int k = 0;

        while (j < med_i && k < med_d){
            if (izq_arr[j] < der_arr[k]){
                arr[i++] = izq_arr[j++];
            }
            else{
                arr[i++] = der_arr[k++];
            }
        }

        while (j < med_i){
            arr[i++] = izq_arr[j++];
        }

        while (k < med_d){
            arr[i++] = der_arr[k++];
        }
    }

    public static void MergeSort(int[] arr, int N)
    {
        if (N < 2){
            return;
        }

        int i, c = 0;
        int med = N/2;

        int[] izq_arr = new int[med];
        int[] der_arr = new int[N - med];

        for (i = 0 ; i < med ; i++){
            izq_arr[i] = arr[i];
        }

        for (i = med ; i < N ; i++){
            der_arr[c] = arr[i];
            c = c + 1;
        }

        MergeSort(izq_arr, med);
        MergeSort(der_arr, N - med);

        Merge(arr, izq_arr, med, der_arr, N - med);
    }
}