//Algoritmo que compara el rendimiento de usar MergeSort con y sin hebras

import java.util.Random;

class Ordenar extends Thread
{
    //VARIABLES PUBLICAS PARA USO COMPARTIDO ENTRE Ordenar_Con_Hebras() y run()
    public static int[] arr_ch = new int[5000000];
        
    public static int N = arr_ch.length;

    public static int[] DER_arr1 = new int[(N - N/2)/2];
    public static int[] DER_arr2 = new int[(N - N/2) - (N - N/2)/2];
    public static int[] IZQ_arr1 = new int[N/4];
    public static int[] IZQ_arr2 = new int[N/2 - N/4];

    public static int IZQ_Listo = 0;
    public static int DER_Listo = 0;

    static MergeSort mergesort = new MergeSort();
    //CIERRE VARIABLES PUBLICAS PARA USO COMPARTIDO ENTRE Ordenar_Con_Hebras() y run()


    static void Crear_Arreglo(int array[]){
        Random rd = new Random();
 
        for (int i = 0; i < array.length; i++) {
            array[i] = rd.nextInt(); 
        }
    }

    public static void Ordenar_Con_Hebras()
    {
        long start = System.nanoTime();
        
        int i;
        int c = 0;

        int[] FULL_IZQ = new int[N/2];
        int[] FULL_DER = new int[N - N/2];

        Ordenar T_1 = new Ordenar();
        Ordenar T_2 = new Ordenar();
        Ordenar T_3 = new Ordenar();
        Ordenar T_4 = new Ordenar();

        Crear_Arreglo(arr_ch);

        for (i = 0 ; i < N/4 ; i++){
            IZQ_arr1[i] = arr_ch[i];
        }
        for (i = N/4 ; i < (N/2) ; i++){
            IZQ_arr2[c] = arr_ch[i];
            c = c + 1;
        }
        c = 0;
        for (i = (N/2) ; i < (N - N/4) ; i++){
            DER_arr1[c] = arr_ch[i];
            c = c + 1;
        }
        c = 0;
        for (i = (N - N/4) ; i < N ; i++){
            DER_arr2[c] = arr_ch[i];
            c = c + 1;
        }
        c = 0;

        T_1.start();
        IZQ_Listo = 1;
        T_2.start();
        IZQ_Listo = 0;
        while( T_2.isAlive() ){}
        IZQ_Listo = 2;

        T_3.start();
        DER_Listo = 1;
        T_4.start();
        DER_Listo = 0;

        while(T_1.isAlive() || T_3.isAlive() || T_4.isAlive() ){}

        mergesort.Merge(FULL_IZQ, IZQ_arr1, N/4, IZQ_arr2, N/2 - N/4);
        mergesort.Merge(FULL_DER, DER_arr1, (N - N/2)/2 , DER_arr2, (N - N/2) - (N - N/2)/2);
        mergesort.Merge(arr_ch, FULL_IZQ, N/2 , FULL_DER, N - N/2);

        System.out.print("El tiempo de ejecucion del programa utilizando ");
        System.out.println("hebras es de: " + (System.nanoTime() - start) + " nanosegundos.");

    }

    public static void Ordenar_Sin_Hebras()
    {
        long start = System.nanoTime();
        int[] arr_sh = new int[5000000];
        int N1 = arr_sh.length;

        Crear_Arreglo(arr_sh);;
        mergesort.MergeSort(arr_sh, N1);

        System.out.print("El tiempo de ejecucion del programa sin utilizar ");
        System.out.println("hebras es de: " + (System.nanoTime() - start) + " nanosegundos.");

    }

    public static void main(String[] args)
    {
        System.out.println("Ordenando un arreglo con 5 millones de elementos aleatorios");
        Ordenar_Con_Hebras();
        Ordenar_Sin_Hebras();
    }

    public void run(){
        if (IZQ_Listo == 1){
            mergesort.MergeSort(IZQ_arr1, N/4);
        }
        else if (IZQ_Listo == 0){
            mergesort.MergeSort(IZQ_arr2, N/2 - N/4);
        }
        else if (DER_Listo == 1){
            mergesort.MergeSort(DER_arr1, (N - N/2)/2);
        }
        else if (DER_Listo == 0){
            mergesort.MergeSort(DER_arr2, (N - N/2) - (N - N/2)/2);
        }
    }
}