Juan Pablo Varas	201873600-7
Patricio Vega 		201873532-9

Instrucciones para el Primer problema
	Previamente tener en el mismo directorio que Funciones.java un archivo de texto que
	contenga las funciones tal como se indicaba en el enunciado.
	Utilizar la función make classes para compilar el programa.
	Ejecutar el comando java Funciones.
	Para limpiar las clases usar la función make clean.
	Al ejecutar el programa se presentan warnings, que solo indican que una de las librerias
	usadas será removida para futuros JDK. La cantidad de veces que se presenta el warning
	depende de cuantas veces se compute un resultado.

Instrucciones para el Segundo Problema
	Utilizar la función make classes para compilar el programa.
	Ejecutar el comando java Ordenar.
	Para limpiar las clases usar la función make clean.

	Para este problema se utilizó el algoritmo de ordenamiento MergeSort para un arreglo
	de 5 millones de elementos aleatorios. Al ejecutar el programa, notamos que utilizando
	hebras se reduce en aproximadamente un 10% el tiempo de ejecución. Para ello se utilizaron
	4 hebras, y cada una se encargó de ordenar un cuarto del arreglo usando MergeSort. 
	Para arreglos de menor tamaño se recomienda utilizar 2 hebras, puesto que se optimiza
	aún mas el tiempo de ejecución. 