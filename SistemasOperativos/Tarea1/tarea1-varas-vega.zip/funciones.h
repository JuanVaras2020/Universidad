



//Funcion que compara los caracteres de las palabras en un conjunto mediante el  uso de strcmp 
//y retorna un valor numerico en base al valor ASCII que tienen los caracteres comparados.

int comparacion(const void *a, const void *b){ 
    const char **ia = (const char **)a;             //Variable para guardar caractar al comparar
    const char **ib = (const char **)b;             //Variable para guardar caractar al comparar
    return strcmp(*ia, *ib);                        //Compara los caracteres
}

//Funcion para imprimir la informacion de todos los juegos en una categoria especifica ordenados por cantidad de categorias
void Imprimir(char *category){        

    FILE *file;                     //Variable para abrir los ficheros        
    DIR *folder;                    //Variable para abrir el directorio
    struct dirent *entry;           //Struct para obtener la informacion del directorio
    char linea[200];                //Variable para guardar la linea de un fichero
    char dir[100];                  //Variable para guardar la direccion del directorio

    int cant_cat = 1;               //Contador de categorias. Inicia en 1 ya que todos los juegos tienen al menos una categiora
    int i = 0;                      //Contador para bucles
    int lineas = 0;                 //Contador para contar las lineas de un fichero

    char Arreglo[50][100];          //Arreglo para guardar los nombres de los archivos
    int ar_i = 0;                   //Contador para moverse dentro del arreglo
    int ar_d = 0;                   //Contador para moverse dentro del arreglo

    strcpy(dir, "Juegos/");         //Inicializamos dir con "Juegos/"
    strcat(dir, category);          //Concatenamos dir con la categoria dada. Ej: "Juegos/categoria1"

    folder = opendir(dir);          //Abrimos el directorio creado

    while( (entry = readdir(folder)) ){     //Bucle para contar la cantidad de categorias de todos los juegos para su posterior ordenamiento
        if (!(strcmp(entry->d_name,".")==0 || strcmp(entry->d_name,"..")==0)){
            char arc[120];                  //Variable para almacenar el nombre del fichero
            strcpy(arc, dir);               //Inicializamos arc con el nombre del directorio
            strcat(arc, "/");               //Concatenamos arc con un /
            strcat(arc, entry->d_name);     //Concatenamos arc con el nombre del fichero
            file = fopen(arc, "r");         //Abrimos el fichero en modo lectura
  
            if (file == NULL){              //Si hubo un error al abrir el fichero, el programa lo notifica
                printf("Hubo un error al abrir el archivo");
                exit(1);
            }

            lineas = 0;                     //Esta variable debe ser reiniciada para que borre la cantidad de lineas anterior
            cant_cat = 1;                   //Esta variable debe ser reiniciada para que borre la cantidad de categorias anterior
            i = 0;                          //Esta variable debe ser reiniciada para que borre la cantidad de caracetres anterior

            while(!feof(file)){             //Bucle para contar la cantidad de categorias
                fgets(linea, 100, file);    //Guardamos en la variable linea la linea del fichero
                
                if (lineas == 1){           //Si la cantidad de lineas es igual a 1, encontramos la linea de categorias
                    while(linea[i] != '\n'){    //Iteramos en la linea hasta encontrar \n
                        if (linea[i] == ','){   //Si encontramos una coma, aumentamos la cantidad de categorias en 1
                            cant_cat++;
                        }
                        i++;                //Incrementamos la posicion del caracter
                    }

                    char cant[10];          //Variable para guardar la cantidad de categorias
                    sprintf(cant, "%d", cant_cat);  //Converitmos dicha cantidad en cant
                    char new_name[101] = "";        //Variable para guardar el nuevo nombre del fichero

                    strcat(new_name, dir);  //Inicializamos new name con el nombre del directorio
                    strcat(new_name, "/");  //Concatenamos new name con un /
                    strcat(new_name, cant); //Concatenamos new name con la cantidad de categorias
                    strcat(new_name, entry->d_name);    //Concatenamos new name con el nombre del fichero

                    rename(arc, new_name);  //Con esta llamada a sistema el fichero cambia de nombre. Ej: 2juego.txt, siendo 2 su cantidad de categorias
                    
                    char new_name2[100]= "";    //Variable para guardar el nuevo nombre del fichero en un arreglo
                    strcat(new_name2, cant);    //Inicializamos new name2 con la cantidad de categorias
                    strcat(new_name2, entry->d_name); //Concatenamos new name 2 con el nombre del fichero
                    strcpy(Arreglo[ar_i],new_name2); //Colocamos new ame 2 en el arreglo
                    ar_i++;  //Incrementamos la posicion del arreglo
                }

                lineas++; //Incrementamos la posicion de la linea
            }
            fclose(file); //Cerramos el archivo
        }
    }
    closedir(folder); //Cerramos la carpeta

    char *Arreglo2[ar_i];                   //Arreglo para guardar los nombres de los archivos sin espacio libres

    while (ar_d<ar_i){                      //Bucle para el traspaso de nombres

        Arreglo2[ar_d]=Arreglo[ar_d];       //Traspaso de los nombres
        ar_d++;                             //Incrementamos las posiciones de los arreglos
        
    }
    
    qsort(Arreglo2, sizeof(Arreglo2) / sizeof(char *), sizeof(char *), comparacion);  //Ordenamos el arreglo nuevo por orden alfabetico


    folder = opendir(dir);                             //Abrimos La Carpeta

    int cont = 0;                                      //Contador para moverse dentro del arreglo
    while(ar_i>cont){                                  //Bucle para moverse dentro del arreglo con los nombre de los ficheros
        
        char arc[120];                                 //Variable para almacenar el nombre del fichero
        char old_name[120];                            //Variable para almacenar el viejo nombre del fichero
        int size = strlen(Arreglo2[cont]);             //Variable que almacena la cantidad de caracteres del fichero viejo
        char old[100] = "";                            //Variable para almacenar el nombre del fichero

        strcpy(arc, dir);                              //Inicializamos arc con el nombre del directorio
        strcat(arc, "/");                              //Concatenamos arc con un /
        strcat(arc, Arreglo2[cont]);                   //Concatenamos arc con el nombre del fichero

        file = fopen(arc, "r");                        //Abrimos el fichero en modo lectura

        printf("\n");                                  //Salto de linea
        while(!feof(file)){                            //Bucle con la lectura del fichero
            fgets(linea, 100, file);                   //Guardamos la linea del fichero en la variable linea
            printf("%s", linea);                       //Se muestra en pantalla la linea
        }

        fclose(file);                                  //Cerramos el fichero

        for (i = 0; i < size ; i++){                   //Bucle que recorre los caracteres del nombre del fichero viejo sin el primer caracter que es el contador de categoria
            old[i] = Arreglo2[cont][i+1];              //Guardamos el caracter en la variable old
        }
        strcpy(arc, dir);                              //Inicializamos arc con el nombre del directorio
        strcat(arc, "/");                              //Concatenamos arc con un /
        strcat(arc, Arreglo2[cont]);                   //Concatenamos arc con el nombre del fichero

        strcpy(old_name, dir);                         //Inicializamos old_name con el nombre del directorio
        strcat(old_name, "/");                         //Concatenamos old_name con un /
        strcat(old_name, old);                         //Concatenamos old_name con el nombre original del fichero
            
        rename(arc, old_name);                         //Renombramos el nombre del archivo con el nombre original
        cont++;                                        //Incrementamos la posicion del arreglo
        printf("\n\n");                                //Saltos de lineas
        
        
    }
    closedir(folder);                                  //Cerramos la carpeta
    printf("\n\n\n");                                  //Saltos de lineas
}


//Funcion para organizar los juegos en distinos directorios
void organizo(char *archivo){

    FILE *file;                     //Variable para abrir los ficheros
    int lineas = -1;                //Variable para contar las lineas de los ficheros
    char palabra[200];              //Variable donde se almacenan las lineas del fichero
    char dir[1000];                 //String para guardar la direccion del directorio + el nombre del fichero
    char delim[] = ",";             //Delimitador para segregar la primera categoria
    char delim2[] = "\n";           //Delimitador para limpiar caracteres especiales
    char delim3[] = "\r";           //Delimitador para limpiar caracteres especiales
    char juegos[] = "Juegos/";      //Variable para guardar la nueva direccion del fichero leido

    strcpy(dir, "Juegos/");         //Se inicializa dir con "Juegos/"
    strcat(dir, archivo);           //Se concatena dir con el nombre del archivo entregado. Ej: "Juegos/juego1.txt"

    file = fopen(dir, "r");         //Abrimos el fichero en formato de lectura
 
    if (file == NULL){              //Si el archivo no existe, el programa lo notifica y termina
        printf("Hubo un error al abrir el archivo");
        exit(1);
    }

    while(!feof(file)){             //Bucle para extraer la primera categoria del juego
        ++lineas;                   //Sumamos 1 a lineas. En la primera iteracion queda -1 + 1 = 0
        fgets(palabra,100,file);    //Guardamos la linea en la variable palabra

        if (lineas == 1){           //Si lineas es igual a 1, encontramos la linea que tiene las categorias
            char *ptr = strtok(palabra, delim);     //Guardamos en ptr la primera categoria, ignorando todo de la coma hacia adelante
            ptr = strtok(palabra,delim2);           //Extraemos el caracter \n de ptr
            ptr = strtok(palabra,delim3);           //Extraemos el caracter \r de ptr
            strcat(juegos, ptr);                    //Concatenamos la variable juegos con ptr. Ej: "Juegos/categoria1"
            mkdir(juegos, 0777);                    //Creamos el directorio
            strcat(juegos, "/");                    //Concatenamos juegos con un /
            strcat(juegos, archivo);                //Concatenamos juegos con el nombre del fichero
            rename(dir,juegos);                     //Con la llamada a sistema rename, movemos el fichero al directorio que tiene por nombre su primera categoria
        }
    }
    fclose(file);                   //Cerramos el archivo
}