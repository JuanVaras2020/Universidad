#include <sys/stat.h>
#include <stdio.h> 
#include <stdlib.h> 
#include <dirent.h>
#include <string.h>
#include "funciones.h"


int main(){
    
    DIR *folder;                    //Variable directorio
    struct dirent *entry;           //Struct para guardar directorios
    int i;                          //Contador para bucles
    char category[5][100];          //Matriz para guardar categorias (5 categorias)

    char all_input[256];            //Input del usuario para la interfaz. 
    char input;                     //Variable para guardar el primer caracter del input
    

    folder = opendir("Juegos");     //Abrimos la carpeta Juegos

    if(folder == NULL){             //Si no existe la carpeta termina el programa
        perror("Carpeta de juegos no encontrada");
        return(1);
    }

    while( (entry=readdir(folder)) ){   //Le asignamos a la funcion organizo el nombre de todos los juegos
 
        if (!(strcmp(entry->d_name,".")==0 || strcmp(entry->d_name,"..")==0)){
             organizo(entry->d_name);
        }
    }                                   //Al finalizar este bucle, la carpeta Juegos queda con los juegos organizados.

    closedir(folder);               //Cerramos la carpeta

    //INTERFAZ
    printf("Juegos organizados correctamente. \n");

    folder = opendir("Juegos");     //Abrimos la carpeta Juegos, esta vez con los juegos ya organizados

    while( (entry=readdir(folder)) ){       //En este bucle guardamos el nombre de cada categoria distinta en la matriz
        if (!(strcmp(entry->d_name,".")==0 || strcmp(entry->d_name,"..")==0)){
            strcpy(category[i], entry->d_name);
            i++;     
        }
    }

    closedir(folder);               //Cerramos la carpeta
    
    while (input != '0'){           //Mostramos las distintas categorias, con un numero adjunto para mostrar su contenido
        printf("1- %s \n", category[0]);
        printf("2- %s \n", category[1]);
        printf("3- %s \n", category[2]);
        printf("4- %s \n", category[3]);
        printf("5- %s \n", category[4]);
        printf("0- Cerrar el programa. \n");

        printf("Ingrese la carpeta que desea abrir: ");
        
        if (fgets(all_input, sizeof all_input, stdin) == NULL) {
            printf("Error, sentencia no valida.\n");
            exit(1);
        }

        input = all_input[0];

        if (input == '1'){          //Por ejemplo, si el usuario ingresa un 1, se mostrará en pantalla la informacion de
            Imprimir(category[0]);  //todos los juegos de la primera categioria
        }
        else if (input == '2'){
            Imprimir(category[1]);
        }
        else if (input == '3'){
            Imprimir(category[2]);
        }
        else if (input == '4'){
            Imprimir(category[3]);
        }
        else if (input == '5'){
           Imprimir(category[4]);
        }

        else if (input == '0'){
            printf("Hasta luego. \n");
        }

        else{
            printf("La opcion ingresada no es valida. Intente nuevamente. \n");
        }
    }
    return(0);
}