Juan Pablo Varas	201873600-7
Patricio Vega 		201873532-9

Instrucciones de uso

Previamente, debe existir un directorio llamado Juegos, cuyo contenido sea
todos los juegos en el formato especificado en el enunciado. Este directorio
debe estar en la misma carpeta donde se ejecute el programa.

Instrucciones del Makefile

Para compilar el programa, debe usar el comando make program
Para limpiar los archivos temporales, puede usar el comando make clean
Para ejecutar el programa, debe usar el comando ./program (Una vez haya compilado el programa)