void inicializar_tablero(struct tablero casillas_tablero[]);        //Asigna la id y efecto a cada casilla del tablero

void inicializar_tablero(struct tablero casillas_tablero[]){
    int max = 29;
    int i;

    for (i = 0 ; i < max ; i++){
        casillas_tablero[i].id = i;

        if (i == 2 || i == 4 || i == 6 || i == 12 || i == 14 || i == 21 || i == 23 || i == 25 || i == 27){
            casillas_tablero[i].efecto = 1;
        }

        else if (i == 16 || i == 22 || i == 24 || i == 26){
            casillas_tablero[i].efecto = 2;
        }

        else{
            casillas_tablero[i].efecto = 0;
        }
    }
}
