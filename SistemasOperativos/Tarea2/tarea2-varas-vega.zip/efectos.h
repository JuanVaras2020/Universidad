// declaracion efectos ?
void retroceso(struct jugador act[], int j);                        //El jugador j retocede un espacio
void los_otros_retroceden(struct jugador act[], int j);             //Todos menos j retroceden un espacio
void avance(struct jugador act[],int j);                            //El jugador j avanza un espacio
void cambio_sentido (struct jugador t[], int j);                    //Se invierte el orden de turnos
int skip_next();                                                    //Se salta al siguiente jugador

// declaracion efectos ??
void los_otros_retroceden2(struct jugador act[],int j);             //Todos menos j retroceden 2 espacios
void al_blanco(struct jugador act[],struct tablero cas[], int j);   //Todos menos j avanzan hasta la siguiente casilla blanca
void cambio_ultimo(struct jugador act[],int j);                     //El jugador j intercambia con el ultimo lugar
void cambio_primero(struct jugador act[], int j);                   //El jugador j intercambia con el primer lugar
void cambio_sentido_tabla(struct jugador players[], struct tablero cas[]);                     //El tablero se invierte


// funciones efectos ?
void retroceso(struct jugador act[], int j){
    if (act[j].pos > 0){
        act[j].pos = act[j].pos - 1;
    }
}

void los_otros_retroceden(struct jugador act[],int j){
    int cont = 0;
    while (cont<4){
        if (cont!=j){
            retroceso(act,cont);
            }
        cont++;
    }
    
}

void avance(struct jugador act[],int j){
        act[j].pos = act[j].pos + 1;
  
}

void cambio_sentido(struct jugador t[], int j){

    struct jugador temp;

    if (j == 0){
        temp = t[3];
        t[3] = t[1];
        t[1] = temp;
        if (t[4].id == 1){t[4].id=3;}
        else if (t[4].id == 3){t[4].id=1;}

    }
    else if (j == 3){
        temp = t[0];
        t[0] = t[2];
        t[2] = temp;
        if (t[4].id == 0){t[4].id=2;}              
        else if (t[4].id == 2){t[4].id=0;}          
    }
    else{
        temp = t[j-1];
        t[j-1] = t[j+1];
        t[j+1] = temp;
        if (t[4].id == j-1){t[4].id=j+1;}          
        else if (t[4].id == j+1){t[4].id=j-1;}
    }
}

int skip(){
    return 1;
}

// funciones efectos ??

void los_otros_retroceden2(struct jugador act[],int j){
    int cont = 0;
    while (cont<4){
        if (cont!=j){
            if (act[cont].pos > 1){
                act[cont].pos = act[cont].pos - 2;
                }
            }
        cont++;
    }
    
}

void al_blanco(struct jugador act[],struct tablero cas[], int j){

    int cont_jugador=0, pos_inicial, pos_casilla;

    while (cont_jugador<4){

        if (cont_jugador != j){

            pos_inicial = act[cont_jugador].pos;
            pos_casilla = 0;

            while (pos_casilla < 29){
                
                if (cas[pos_casilla].efecto==0 && cas[pos_casilla].id>pos_inicial){
                    act[cont_jugador].pos = cas[pos_casilla].id;
                    break;
                }

                pos_casilla++;   
                
            }
                
        }
        cont_jugador++;
    }

}

void cambio_ultimo(struct jugador act[],int j){

    int cont = 0, ultimo = 30, id_ultimo, pos_back_up;

    while (cont<4){
        if (act[cont].pos<ultimo){
            ultimo = act[cont].pos;
            id_ultimo = cont;
        }
        cont++;
    }
    
    pos_back_up = act[j].pos;

    act[j].pos = act[id_ultimo].pos;
    act[id_ultimo].pos = pos_back_up; 

}

void cambio_primero(struct jugador act[],int j){

    int cont = 0, primero = 0, id_primero, pos_back_up;

    while (cont<4){
        if (act[cont].pos>primero){
            primero = act[cont].pos;
            id_primero = cont;
        }
        cont++;
    }
    
    pos_back_up = act[j].pos;

    act[j].pos = act[id_primero].pos;
    act[id_primero].pos = pos_back_up; 

}

void cambio_sentido_tabla(struct jugador players[], struct tablero cas[]){
    int i;
    if (cas[0].id == 0){
        for (i = 0 ; i < 29 ; i++){
            cas[i].id = 28 - i;
            if (cas[i].efecto == 1){
                cas[i].efecto = 2;
            }
            else if (cas[i].efecto == 2){
                cas[i].efecto = 1;
            }
        }
        for (i = 0 ; i < 4 ; i++){
            players[i].pos = 28 - players[i].pos;
        } 
    }
    else if(cas[0].id == 28){
        for (i = 0 ; i < 29 ; i++){
            cas[i].id = i;
            if (cas[i].efecto == 1){
                cas[i].efecto = 2;
            }
            else if (cas[i].efecto == 2){
                cas[i].efecto = 1;
            }
        }
        for (i = 0 ; i < 4 ; i++){
            players[i].pos = 28 - players[i].pos;
        } 
    }
}