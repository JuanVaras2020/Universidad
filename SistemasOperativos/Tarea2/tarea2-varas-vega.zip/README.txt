Juan Pablo Varas	201873600-7
Patricio Vega 		201873532-9

Instrucciones de uso

Al iniciar el juego, se debe indicar el numero del turno en el que se quiere iniciar (1, 2, 3, 4).
Luego, cada vez que sea su turno, deberá presionar la tecla t para lanzar el dado, y si cae en una 
casilla de efecto deberá presionar y para activarlo y n para no activarlo. Ganará si logra llegar a la 
casilla fin antes que el resto.

Instrucciones del Makefile

Para compilar el programa, debe usar el comando make program
Para limpiar los archivos temporales, puede usar el comando make clean
Para ejecutar el programa, debe usar el comando ./program (Una vez haya compilado el programa)