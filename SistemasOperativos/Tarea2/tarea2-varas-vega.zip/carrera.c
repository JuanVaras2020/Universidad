#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>

#include "imprimir.h"
#include "efectos.h"
#include "inicializar_tab.h"
#include "turnos.h"

key_t clave_j;	//Clave de acceso a la zona de memoria
long int id_j;	//Identificador de la zona de memoria
struct jugador *pmem_j =NULL;	//Puntero a la zona de memoria

key_t clave_t;	//Clave de acceso a la zona de memoria
long int id_tablero;	//Identificador de la zona de memoria
struct tablero *pmem_t = NULL;	//Puntero a la zona de memoria

//Funcion para crear la region de memoria compartida para los jugadores
void crear_mem_j(){
    clave_j=ftok("/bin/ls",33); //Cualquier fichero existente y cualquier int
	id_j=shmget(clave_j,sizeof(struct jugador)*100,0777|IPC_CREAT);
	pmem_j =(struct jugador *)shmat(id_j,(char *)0,0);
}

//Funcion para crear la region de memoria compartida para el tablero
void crear_mem_t(){
	id_tablero=shmget(IPC_PRIVATE,sizeof(struct tablero)*100,0777|IPC_CREAT);
	pmem_t =(struct tablero *)shmat(id_tablero,(char *)0,0);
}


int main() {
    char tur[256], in;
    int turno;
    int aux = 0;
	//Creamos un área de memoria compartida
    crear_mem_j();
    crear_mem_t();

    inicializar_tablero(pmem_t);
    printf("Bienvenidos al juego mas entretenido del mundo.\n");

    printf("Elije en que turno quieres empezar: ");      //Elección
    while (aux == 0){
        if (fgets(tur, sizeof tur, stdin) == NULL) {
            printf("Opción no valida. Intente nuevamente ");
        }
        in = tur[0];
        if (in == '1' || in == '2' || in == '3' || in == '4'){
            turno = in - '0';
            aux = 1;
        }
        else{
            printf("Opción no valida. Intente nuevamente ");
        }
    }
    Inicializar_Jugadores(pmem_j, turno);
    Imprimir_tablero(pmem_j, pmem_t);

    pmem_j[4].id = turno-1;
    pmem_j[4].pos = turno-1;

    int j1, j2, j3, j4;
    int J1, J2, J3, J4;
    int actual, father_id, flag = 0;
    int pase = 1;
    int ret = 0;
    time_t t;

    int pipevw[2];              //Pipe que conecta al primer hijo con el segundo
    int pipewx[2];              //Pipe que conecta al segundo hijo con el tercero
    int pipexy[2];              //Pipe que conecta al tercer hijo con el cuarto
    int pipeyz[2];              //Pipe que conecta al cuarto hijo con el primero
    int pipevPadre[2];          //Pipe que conecta al primer hijo con el Padre
    int pipewPadre[2];          //Pipe que conecta al segundo hijo con el Padre
    int pipexPadre[2];          //Pipe que conecta al tercer hijo con el Padre
    int pipeyPadre[2];          //Pipe que conecta al cuarto hijo con el Padre

    pipe(pipevw);
    pipe(pipewx);
    pipe(pipexy);
    pipe(pipeyz);
    pipe(pipevPadre);
    pipe(pipewPadre);
    pipe(pipexPadre);
    pipe(pipeyPadre);

    //Creacion de los 4 procesos (jugadores)
    j1 = fork();
    if(j1 > 0){
        j2 = fork();
        if (j2 > 0){
            j3 = fork();
            if (j3 > 0){
                j4 = fork();
                if (j4 == 0){

                    J4 = getpid();
                    srand((int)time(&t) % getpid());
                }
                else{father_id = getpid();}
            }
            else if (j3 == 0){

                J3 = getpid();
                srand((int)time(&t) % getpid());
            }
        }
        else if (j2 == 0){
            
            J2 = getpid();
            srand((int)time(&t) % getpid());
        }
    }
    else if (j1 == 0){
        
        J1 = getpid();
        srand((int)time(&t) % getpid());
    }


    actual = getpid();

    while (flag == 0){

        //Turno del primer jugador
        if (actual == J1){
            if (pase == -1){
                break;
            } 
            if (pmem_j[4].id == 0){               
                ret = TurnoJugador(pmem_j, pmem_t, 0);
            }
            else{
                ret = TurnoBot(pmem_j, pmem_t, 0);
            }

            if (pmem_j[0].pos == 28 || pmem_j[1].pos == 28 || pmem_j[2].pos == 28 || pmem_j[3].pos == 28){
                ganador(pmem_j);
                flag = 1;
                pase = -1;
                write(pipevw[1],&pase,sizeof(int));
                write(pipewx[1],&pase,sizeof(int));
                write(pipexy[1],&pase,sizeof(int));
                write(pipevPadre[1],&pase,sizeof(int));
                break;
            }
            else if (ret == 1){
                ret = 0;
                write(pipewx[1],&pase,sizeof(int));
            }
            else{
                pase = 1;
                write(pipevw[1],&pase,sizeof(int));
            }
            while((read(pipeyz[0],&pase,sizeof(int)))<0){};
        }

        //Turno del segundo jugador
        else if (actual == J2){
            while((read(pipevw[0],&pase,sizeof(int)))<0){};
            if (pase == -1){
                break;
            }
            if (pmem_j[4].id == 1){                                      
                ret = TurnoJugador(pmem_j, pmem_t, 1);
            }
            else{
                ret = TurnoBot(pmem_j, pmem_t, 1);
            }



            if (pmem_j[0].pos == 28 || pmem_j[1].pos == 28 || pmem_j[2].pos == 28 || pmem_j[3].pos == 28){
                ganador(pmem_j);
                flag = 1;
                pase = -1;
                write(pipewx[1],&pase,sizeof(int));
                write(pipeyz[1],&pase,sizeof(int));
                write(pipexy[1],&pase,sizeof(int));
                write(pipevPadre[1],&pase,sizeof(int));
                break;
            }
            else if (ret == 1){
                ret = 0;
                write(pipexy[1],&pase,sizeof(int));
            }
            else{
                pase = 1;
                write(pipewx[1],&pase,sizeof(int));
            }
        }

        //Turno del tercer jugador
        else if (actual == J3){
            while((read(pipewx[0],&pase,sizeof(int)))<0){};

            if (pase == -1){
                break;
            }

            if (pmem_j[4].id == 2){                                          
                ret = TurnoJugador(pmem_j, pmem_t, 2);
            }
            else{
                ret = TurnoBot(pmem_j, pmem_t, 2);
            }

            if (pmem_j[0].pos == 28 || pmem_j[1].pos == 28 || pmem_j[2].pos == 28 || pmem_j[3].pos == 28){
                ganador(pmem_j);
                flag = 1;
                pase = -1;
                write(pipexy[1],&pase,sizeof(int));
                write(pipeyz[1],&pase,sizeof(int));
                write(pipevw[1],&pase,sizeof(int));
                write(pipevPadre[1],&pase,sizeof(int));
                break;
            }
            else if (ret == 1){
                ret = 0;
                write(pipeyz[1],&pase,sizeof(int));
            }
            else{
                pase = 1;
                write(pipexy[1],&pase,sizeof(int));
            }
        }

        //Turno del cuarto jugador
        else if (actual == J4){                                           
            while((read(pipexy[0],&pase,sizeof(int)))<0){};
            if (pase == -1){
                break;
            }

            if (pmem_j[4].id == 3){
                ret = TurnoJugador(pmem_j, pmem_t, 3);
            }
            else{
                ret = TurnoBot(pmem_j, pmem_t, 3);
            }

            if (pmem_j[0].pos == 28 || pmem_j[1].pos == 28 || pmem_j[2].pos == 28 || pmem_j[3].pos == 28){
                ganador(pmem_j);
                flag = 1;
                pase = -1;
                write(pipeyz[1],&pase,sizeof(int));
                write(pipewx[1],&pase,sizeof(int));
                write(pipevw[1],&pase,sizeof(int));
                write(pipevPadre[1],&pase,sizeof(int));
                break;
            }
            else if (ret == 1){
                ret = 0;
                write(pipevw[1],&pase,sizeof(int));
            }
            else if (ret == 2){
                pase = 2;
                write(pipeyz[1],&pase,sizeof(int));
            }
            else{
                pase = 1;
                write(pipeyz[1],&pase,sizeof(int));
            }
        }

        if (actual == father_id){
            while((read(pipevPadre[0],&pase,sizeof(int)))<0){};
            sleep(1);
            break;
        }
    }

    shmdt((char *)id_j); //Desconecta el segmento de memoria compartida
	shmctl(id_j,IPC_RMID,0); //Elimina el segmento de memoria compartida

    shmdt((char *)id_tablero); //Desconecta el segmento de memoria compartida
	shmctl(id_tablero,IPC_RMID,0); //Elimina el segmento de memoria compartida
    return 0;
}