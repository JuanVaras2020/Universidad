struct jugador{
    int pos;
    int id;
};

struct tablero{
    int id;             //AKA pos
    int efecto;         //0 para nada, 1 para ? y 2 para ??
};

void Imprimir_tablero(struct jugador players[], struct tablero cas[]);                                      //Imprime el tablero
void print_linea();                                                                                         //Imprime borde del tablero
void Imprimir_tablero_aux1(struct jugador players[], struct tablero cas[], int n, int m, int a, int b);     //Imprime las primeras 2 fichas
void Imprimir_tablero_aux2(struct jugador players[], struct tablero cas[], int n, int a, int b);            //Imprime las ultimas 2 fichas
void Imprimir_tablero_aux3(struct jugador players[], struct tablero cas[],int n, int m, int a, int b);      //Casos especiales
void Imprimir_efectos(struct tablero cas[], int n, int m);                                                  //Imprime los ?
void Imprimir_efectos2(struct tablero cas[], int n, int m);                                                 //Imprime los ??
void Inicializar_Jugadores(struct jugador players[], int turno);                                            //Inicializar jugadores con pos = 0

void Imprimir_tablero(struct jugador players[], struct tablero cas[]){
    print_linea();
    Imprimir_tablero_aux1(players, cas, 20, 29, 0, 1);
    Imprimir_efectos(cas, 20, 29);
    Imprimir_tablero_aux1(players, cas, 20, 29, 2, 3);
    print_linea();
    Imprimir_tablero_aux2(players, cas, 19, 0, 1);
    printf("|     |\n");
    Imprimir_tablero_aux2(players, cas, 19, 2, 3);
    print_linea();
    Imprimir_tablero_aux3(players, cas, 9, 18, 0, 1);
    Imprimir_efectos2(cas, 18, 9);
    Imprimir_tablero_aux3(players, cas, 9, 18, 2, 3);
    print_linea();
    printf("                                                ");
    Imprimir_tablero_aux2(players, cas, 9, 0, 1);
    printf("                                                |     |\n");
    printf("                                                ");
    Imprimir_tablero_aux2(players, cas, 9, 2, 3);
    print_linea();
    Imprimir_tablero_aux1(players, cas, 0, 9, 0, 1);
    Imprimir_efectos(cas, 0, 9);
    Imprimir_tablero_aux1(players, cas, 0, 9, 2, 3);
    print_linea();
}


void print_linea(){
    printf("*******************************************************\n");
}

void Imprimir_tablero_aux1(struct jugador players[], struct tablero cas[], int n, int m, int a, int b){
    int i;
    printf("|");
    for (i = n ; i < m ; i++){
        if (i == cas[players[a].pos].id){
            if (a == 0){
                printf("\033[1;31m%d", players[a].id);
            }
            else {
                printf("\033[1;34m%d", players[a].id);
            }
            printf("\033[0m");
        }
        else {
            printf(" ");
        }

        printf("   ");
        if (i == cas[players[b].pos].id){
            if (b == 1){
                printf("\033[1;33m%d", players[b].id);
            }
            else{
                printf("\033[1;32m%d", players[b].id);
            }
            printf("\033[0m");
        }
        else{
            printf(" ");
        }

        printf("|");
    }
    printf("\n");
}

void Imprimir_tablero_aux2(struct jugador players[], struct tablero cas[], int n, int a, int b){
    printf("|");
    if (n == cas[players[a].pos].id){
        if (a == 0){
            printf("\033[1;31m%d", players[a].id);
        }
        else{
            printf("\033[1;34m%d", players[a].id);
        }
        printf("\033[0m");
    }
    else {
        printf(" ");
    }

    printf("   ");
    if (n == cas[players[b].pos].id){
        if (b == 1){
            printf("\033[1;33m%d", players[b].id);
        }
        else{
            printf("\033[1;32m%d", players[b].id);
        }
        printf("\033[0m");
    }
    else{
        printf(" ");
    }
    printf("|\n");
}


void Imprimir_tablero_aux3(struct jugador players[], struct tablero cas[], int n, int m, int a, int b){
    int i;
    printf("|");
    for (i = m ; i > n ; i--){
        if (i == cas[players[a].pos].id){
            if (a == 0){
                printf("\033[1;31m%d", players[a].id);
            }
            else {
                printf("\033[1;34m%d", players[a].id);
            }
            printf("\033[0m");
        }
        else {
            printf(" ");
        }

        printf("   ");
        if (i == cas[players[b].pos].id){
            if (b == 1){
                printf("\033[1;33m%d", players[b].id);
            }
            else{
                printf("\033[1;32m%d", players[b].id);
            }
            printf("\033[0m");
        }
        else{
            printf(" ");
        }

        printf("|");
    }
    printf("\n");
}

void Imprimir_efectos(struct tablero cas[], int n, int m){
    int i;
    printf("|");

    for (i = n ; i < m ; i++){
        if (cas[i].id == 28){
            printf(" fin |");
        }
        else if (cas[i].id == 0){
            printf(" ini |");
        }
        else if (cas[i].efecto == 0){
            printf("     |");
        }
        else if (cas[i].efecto == 1){
            printf("  ?  |");
        }
        else if (cas[i].efecto == 2){
            printf("  ?? |");
        }
    }
    printf("\n");
}

void Imprimir_efectos2(struct tablero cas[], int n, int m){
    int i;
    printf("|");

    for (i = n ; i > m ; i--){
        if (cas[i].id == 28){
            printf(" fin |");
        }
        else if (cas[i].id == 0){
            printf(" ini |");
        }
        else if (cas[i].efecto == 0){
            printf("     |");
        }
        else if (cas[i].efecto == 1){
            printf("  ?  |");
        }
        else if (cas[i].efecto == 2){
            printf("  ?? |");
        }
    }
    printf("\n");
}

void Inicializar_Jugadores(struct jugador players[], int turno){
    players[0].id = 1;
    players[0].pos = 0;

    players[1].id = 2;
    players[1].pos = 0;

    players[2].id = 3;
    players[2].pos = 0;

    players[3].id = 4;
    players[3].pos = 0;

    players[4].id = 0;              
    players[4].pos = 0;             
}