int tirar_dado();                                                                   //Retorna un numero aleatorio entre 1 y 6
int TurnoJugador(struct jugador act[], struct tablero cas[], int id);               //Manejador del turno del jugador
int TurnoBot(struct jugador act[], struct tablero cas[], int id);                   //Manejador del turno de los bots
void ganador(struct jugador act[]);


void ganador(struct jugador act[]){

    int A[4] = {0,0,0,0};
    int cont=0, ganadores = 0, idjugador;
 

    while (cont<4){

        if (act[cont].pos==28){

            A[act[cont].id-1]=1;
            ganadores++;
        }

        if (cont==act[4].pos){idjugador=cont;}

        cont++;
    }

    cont = 0;
    if (ganadores == 1){

        while (cont<4){

            if (A[cont]==1){
                
                if (cont==idjugador){printf("La carrera ha terminado. El ganador es usted. \n");}

                else {printf("La carrera ha terminado. El ganador es el Bot %i. \n",cont+1);}

            }
        cont++;
        }
    }

    else{printf("La carrera ha terminado. Ha habido un empate\n");}
}



int tirar_dado(){
    int num;
    num = (rand() % 6) + 1;
    return num;
}


int TurnoJugador(struct jugador act[], struct tablero cas[], int id){
    srand(time(NULL));
    int num, i, aux = 0;
    char tir[256];
    char in;
    char elec, elec2;
    int prob[5] = {1, 2, 3, 4, 5};
    int prob2[10] = {1, 1, 1, 2, 2, 3, 3, 4, 4, 5};
    int random, random2, index;
    int ret = 0;

    printf("Le toca a usted.\n");
    printf("Presione t para tirar el dado \n");
    while (aux == 0){
        if (fgets(tir, sizeof tir, stdin) == NULL) {
            printf("Opción no valida. Intente nuevamente ");
        }
        in = tir[0];
        if (in == 't'){
            elec = in;
            aux = 1;
        }
        else{
            printf("Opción no valida. Intente nuevamente ");
        }
    }
    for (i = 0 ; i < id+1 ; i++){
        num = tirar_dado();
    }

    if (elec == 't'){
        num = tirar_dado();
        printf("Ha sacado %d \n", num);
        sleep(2);
    
        act[id].pos = act[id].pos + num;

        if (act[id].pos > 27){
            act[id].pos = 28;
        }
    }

    if (cas[cas[act[id].pos].id].efecto == 0){
        printf("No pasan efectos\n");
    }

    else if (cas[cas[act[id].pos].id].efecto == 1){
        printf("Ha caido en una casilla ?. ¿Desea activar su efecto? (y/n) \n");
        aux = 0;
        while (aux == 0){
            if (fgets(tir, sizeof tir, stdin) == NULL) {
                printf("Opción no valida. Intente nuevamente ");
            }
            in = tir[0];
            if (in == 'y' || in == 'n'){
                elec2 = in;
                aux = 1;
            }
            else{
                printf("Opción no valida. Intente nuevamente ");
            }
        }
        if (elec2 == 'y'){
            index =  rand() % 5;
            random = prob[index];

            if (random == 1){
                retroceso(act, id);
                printf("Retrocedes un espacio\n");
            }
            else if (random == 2){
                los_otros_retroceden(act, id);
                printf("Todos los bots retroceden un espacio\n");
            }
            else if (random == 3){
                avance(act, id);
                printf("Usted avanza un espacio\n");
            }
            else if (random == 4){
                cambio_sentido(act, id);
                printf("Los turnos han sido invertidos\n");
            }
            else if (random == 5){
                ret = skip();
                printf("El siguiente jugador ha sido saltado\n");
                sleep(3);
                Imprimir_tablero(act, cas);
                return ret;
            }

        }
        else if (elec2 == 'n'){
            printf("no pasan efectos\n");
        }
    }

    else if (cas[cas[act[id].pos].id].efecto == 2){
        printf("Ha caido en una casilla ??. ¿Desea activar su efecto? (y/n) \n");
        aux = 0;
        while (aux == 0){
            if (fgets(tir, sizeof tir, stdin) == NULL) {
                printf("Opción no valida. Intente nuevamente ");
            }
            in = tir[0];
            if (in == 'y' || in == 'n'){
                elec2 = in;
                aux = 1;
            }
            else{
                printf("Opción no valida. Intente nuevamente ");
            }
        }
        if (elec2 == 'y'){
            index =  rand() % 10;
            random2 = prob2[index];

            if (random2 == 1){
                los_otros_retroceden2(act, id);
                printf("Todos los bots retroceden dos espacios\n");
            }
            else if (random2 == 2){
                al_blanco(act, cas, id);
                printf("Todos los bots avanzan hasta la siguiente casilla blanca\n");
            }
            else if (random2 == 3){
                cambio_primero(act, id);
                printf("Usted intercambia posiciones con el Bot que va en primer lugar\n");
            }
            else if (random2 == 4){
                cambio_ultimo(act, id);
                printf("Usted intercambia posiciones con el Bot que va en ultimo lugar\n");
            }
            else if (random2 == 5){
                cambio_sentido_tabla(act, cas);
                printf("El tablero ha sido invertido\n");
            }

        }

        else if (elec2 == 'n'){
            printf("no pasan efectos\n");
        }
    }
    sleep(3);
    Imprimir_tablero(act, cas);
    return ret;
}

int TurnoBot(struct jugador act[], struct tablero cas[], int id){
    srand(time(NULL));
    int num, i;
    int prob[5] = {1, 2, 3, 4, 5};
    int prob2[10] = {1, 1, 1, 2, 2, 3, 3, 4, 4, 5};
    int random, random2, index;
    int ret = 0;

    printf("Le toca al bot %d\n", act[id].id);
    sleep(2);
    printf("El bot %d lanza el dado.\n", act[id].id);
    sleep(1);
    printf("Lanzando dado...\n");

    for (i = 0 ; i < id+1 ; i++){
        num = tirar_dado();
    }

    sleep(1);
    printf("El bot %d ha sacado %d. \n", act[id].id, num);
    act[id].pos = act[id].pos + num;
    if (act[id].pos > 27){
        act[id].pos = 28;
    }

    if (cas[cas[act[id].pos].id].efecto == 0){
        printf("No pasan efectos\n");
    }

    else if (cas[cas[act[id].pos].id].efecto == 1){
        index =  rand() % 5;
        random = prob[index];

        if (random == 1){
            retroceso(act, id);
            printf("Bot %d retrocede un espacio\n", act[id].id);
        }
        else if (random == 2){
            los_otros_retroceden(act, id);
            printf("Todos menos el Bot %d retroceden un espacio\n", act[id].id);
        }
        else if (random == 3){
            avance(act, id);
            printf("El Bot %d avanza un espacio\n", act[id].id);
        }
        else if (random == 4){
            cambio_sentido(act, id);
            printf("Los turnos han sido invertidos\n");
        }
        else if (random == 5){
            ret = skip();
            printf("El siguiente jugador ha sido saltado\n");
            sleep(3);
            Imprimir_tablero(act, cas);
            return ret;
        }
    }

    else if (cas[cas[act[id].pos].id].efecto == 2){
        index =  rand() % 5;
        random2 = prob2[index];

        if (random2 == 1){
            los_otros_retroceden2(act, id);
            printf("Todos menos el Bot %d retroceden dos espacios\n", act[id].id);
        }
        else if (random2 == 2){
            al_blanco(act, cas, id);
            printf("Todos menos el Bot %d avanzan hasta la siguiente casilla blanca\n", act[id].id);
        }
        else if (random2 == 3){
            cambio_primero(act, id);
            printf("El Bot %d intercambia porsiciones con el jugador que va en primer lugar\n", act[id].id);
        }
        else if (random2 == 4){
            cambio_ultimo(act, id);
            printf("El Bot %d intercambia porsiciones con el jugador que va en ultimo lugar\n", act[id].id);
        }
        else if (random2 == 5){
            cambio_sentido_tabla(act, cas);
            printf("El tablero ha sido invertido\n");
        }
    }
    sleep(3);
    Imprimir_tablero(act, cas);
    return ret;
}