Instrucciones de uso

Antes de ejecutar el programa, deben existir los archivos Casino.py, Funciones.py y nombres.txt 
en el mismo directorio. El primero contiene el código fuente, el segundo Funciones de apoyo y el
tercero una serie de nombres para asignarle a los clientes. (Nombres de pokemones, sabemos que no
era necesario pero decidimos implementarlo para facilitar la lectura de los archivos)

Para ejecutar el programa, se debe ejecutar el archivo Casino.py

Una vez ejecutado, se deberá ingresar la cantidad de bandejas y clientes, tal como se solicita en el 
enunciado.

Una vez finalizado el programa, se generarán 2 archivos, cliente.txt y juan.txt . Ambos contendrán
la información solicitada en la tarea. 

*Como las acciones del casino toman entre 3 y 5 segundos, si desea acelerar la ejecución del programa
puede cambiar el argumento de las funciones sleep() que se encuentran en las lineas 39, 49, 57 y 66.