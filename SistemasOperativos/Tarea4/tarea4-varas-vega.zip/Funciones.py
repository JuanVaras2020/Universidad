from datetime import datetime
import random
import os.path
from os import path

#Llena la fila del casino
def LlenarFila(N_Clientes, arc):
    archivo = open(arc, "r")

    Fila = []
    lista = []
    for linea in archivo:
        linea = linea.strip()
        lista.append(linea)
    
    while (N_Clientes != 0):
        nombre = lista[random.randrange(1,len(lista),1)]
        Fila.append(nombre)
        N_Clientes = N_Clientes - 1
    
    return Fila

#Crea los archivos
def Crear_Archivos():
    if  (not path.exists('cliente.txt')) :
        archivo_cliente = open("cliente.txt", "w")
        archivo_cliente.write("ID Cliente | Nombre Cliente | Hora Llegada | Zonas Criticas\n")
        archivo_cliente.close()
    
    if  (not path.exists('juan.txt')) :
        archivo_juan = open("juan.txt","w")
        archivo_juan.write("ID Atendido | Cliente Atendido | Hora Llegada\n")
        archivo_juan.close()

#Consigue el siguiente ID del cliente
def getNextId(arc):
    archivo = open(arc, "r")
    lineList = archivo.readlines()
    archivo.close()

    LastLine = lineList[-1]
    id = ''
    cont = 0
    c = LastLine[cont]

    while (c != '|'):
        id = id + c
        cont = cont + 1
        c = LastLine[cont]
    
    id = id.strip()
    if (id == 'ID Cliente' or id == 'ID Atendido'):
        return '1'
    else:
        return str(int(id) + 1)

#Retorna la hora actual
def hora():
    ingreso = datetime.now()
    ingreso_formato = ingreso.strftime('%H:%M:%S.%f')[:-3]
    return ingreso_formato

#Retorna un string con las zonas criticas dadas
def getZonas(Zonas):
    zonas = ''
    for s in Zonas:
        zonas = zonas + s

    return zonas

#Escribe en los archivos
def escritura(cliente, Zonas):
    archivo = open("cliente.txt", "a")

    archivo.write("\n")
    archivo.write(getNextId("cliente.txt") + ' | ' + cliente + ' | ' + hora() + ' | ' + getZonas(Zonas))

    archivo.close()

    archivo = open("juan.txt", "a")

    archivo.write("\n")
    archivo.write(getNextId("juan.txt") + ' | ' + cliente + ' | ' + hora())

    archivo.close()