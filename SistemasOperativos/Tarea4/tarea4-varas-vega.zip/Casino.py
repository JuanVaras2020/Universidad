import threading
import time
import math

from Funciones import LlenarFila, escritura, Crear_Archivos

Semaforo_Sacar_Bandeja = threading.Semaphore()
Semaforo_Poner_Bandeja = threading.Semaphore()
Semaforo_Escritura = threading.Semaphore()
Semaforo_Almorzar = threading.Semaphore()
Semaforo_Sirviendo = threading.Semaphore()

N_Bandejas = int(input('Ingrese la cantidad de bandejas: '))
N_Clientes = int(input('Ingrese la cantidad de clientes: '))

Bandejas_Fila = N_Bandejas
Bandejas_Bandejero = 0
Capacidad_Bandejero = math.ceil(N_Bandejas/2)

Ayudante = True
Sirviendo = True

Crear_Archivos()

def cliente(nombre):
    global Bandejas_Bandejero
    global Bandejas_Fila
    global Capacidad_Bandejero
    global Ayudante
    global Sirviendo

    Zonas = []
    
    Semaforo_Sacar_Bandeja.acquire()
    if Bandejas_Fila == 0:
        #Juan Repone las bandejas de la Fila
        Bandejas_Fila = Bandejas_Bandejero
        Bandejas_Bandejero = 0
        time.sleep(3)                                   #Modificable para acelerar la ejecución
        Zonas.append("Hizo que Juan pida bandejas, ")
    
    Bandejas_Fila = Bandejas_Fila - 1
    Zonas.append("Sacó una bandeja, ")
    Semaforo_Sacar_Bandeja.release()

    #Servir almuerzo
    Semaforo_Sirviendo.acquire()
    Sirviendo = False
    time.sleep(3)                                       #Modificable para acelerar la ejecución
    Sirviendo = True
    Zonas.append("Fué servido, ")
    Semaforo_Sirviendo.release()

    Semaforo_Almorzar.acquire()
    #Almorzar
    Ayudante = False
    time.sleep(5)                                       #Modificable para acelerar la ejecución
    Zonas.append("Almorzó, ")
    Semaforo_Almorzar.release()

    Semaforo_Poner_Bandeja.acquire()
    if (Bandejas_Bandejero == Capacidad_Bandejero):
        #Juan hace espacio en el bandejero
        Bandejas_Fila = Bandejas_Bandejero
        Bandejas_Bandejero = 0
        time.sleep(3)                                   #Modificable para acelerar la ejecucións
        Zonas.append("Hizo que Juan vaciara el bandejero, ")
    
    Bandejas_Bandejero = Bandejas_Bandejero + 1
    Ayudante = True
    Zonas.append("Dejó su bandeja")
    Semaforo_Poner_Bandeja.release()

    Semaforo_Escritura.acquire()
    escritura(nombre, Zonas)
    Semaforo_Escritura.release()
    
    return

def AbrirCasino(N_Bandejas, N_Clientes):
    Fila = LlenarFila(N_Clientes, "nombres.txt")

    Clientes = []

    for cli in Fila:
        Cliente = list()
        c = threading.Thread(target = cliente, args= (cli,))
        Clientes.append(c)
        Cliente.append(c)
        c.start()

    for c in Clientes:
        c.join()
    return


def juan():
    global N_Bandejas
    global N_Clientes
    AbrirCasino(int(N_Bandejas), int(N_Clientes))
    return



Juan = list()
t = threading.Thread(target=juan)
Juan.append(t)
t.start()

t.join()