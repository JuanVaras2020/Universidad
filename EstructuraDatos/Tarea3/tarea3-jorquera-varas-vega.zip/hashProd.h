#include "hashOferta.h"
#include <stdlib.h>
#include <stdio.h>

using namespace std;

typedef struct {
	int cod_producto;
	char nbre_producto[31];
	int precio;
} producto;

typedef struct {
    int key;
    producto prod;
} prodDic;

/*****
*   int    prodInsert
*****
*   Resumen:    Inserta un elemento en el hashing de productos, que se compone por 
*               key (clave) y prod (elemento tipo producto (struct)).
*****
*   INPUT: 
*       compraDic   *HT     : Puntero de struct prodDic.
*       producto    Product : producto (struct) que corresponde al elemento que se busca insertar.
*       int         size    : int que corresponde al tamaño del hashing.
*****
*   RETURN:
*       int         0       : int que indica que el dato ya pertenece al hashing.
*       int         1       : int que indica que se insertó exitósamente el dato.
*****/
int prodInsert(prodDic *HT, producto Product, int size){
    int inicio, i;
    int VACIA = -1;
    int pos = inicio = H1(Product.cod_producto, size);
    for (i = 0; HT[pos].key != VACIA &&  HT[pos].key != Product.cod_producto; i++){
        pos = abs( pos + H2(pos, size)) % size;
    }

    if (HT[pos].key == Product.cod_producto){
        return 0;
    }
    else{
        HT[pos].key = Product.cod_producto;
        HT[pos].prod = Product;
    }
    return 1;    
}

/*****
*   int    prodSearch
*****
*   Resumen:    Busca un elemento en el hashing de productos a partir de una clave dada.
*****
*   INPUT: 
*       prodDic     *HT     : Puntero de struct prodDic.
*       int         clave   : int que corresponde a la clave del producto a buscar.
*       int         size    : int que corresponde al tamaño del hashing.
*****
*   RETURN:
*       int         pos     : int que indica la posición en donde se encontró el dato.
*       int         -1      : int que indica que el dato no pertenece al hashing.
*****/
int prodSearch(prodDic *HT, int clave, int size){
    int inicio, i;
    int VACIA = -1;
    int pos = inicio = H1(clave, size);
    for (i = 0; HT[pos].key != VACIA &&  HT[pos].key != clave; i++){
        pos = abs( pos + H2(pos, size)) % size;
    }
    if (HT[pos].key == clave){
        return pos;
    }
    else{
        return -1;
    }
}