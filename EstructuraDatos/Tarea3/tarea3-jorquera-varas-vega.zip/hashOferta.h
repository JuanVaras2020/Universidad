#include "global.h"
#include <stdlib.h>
#include <stdio.h>

using namespace std;

typedef struct {
	int cod_producto;
	int cantidad_descuento;
	int descuento;
} oferta;

typedef struct {
    int key;
    oferta prodsEnOferta;
} oferDic;

/*****
*   int    ofertaInsert
*****
*   Resumen:    Inserta un elemento en el hashing de ofertas, que se compone por 
*               key (clave) y prodsEnOferta (elemento tipo oferta (struct)).
*****
*   INPUT: 
*       ofertaDic   *HT     : Puntero de struct oferDic.
*       oferta      Product : oferta (struct) que corresponde al elemento que se busca insertar.
*       int         size    : int que corresponde al tamaño del hashing.
*****
*   RETURN:
*       int         0       : int que indica que el dato ya pertenece al hashing.
*       int         1       : int que indica que se insertó exitósamente el dato.
*****/
int ofertaInsert(oferDic *HT, oferta Product, int size){
    int inicio, i;
    int VACIA = -1;
    int pos = inicio = H1(Product.cod_producto, size);
    for (i = 0; HT[pos].key != VACIA &&  HT[pos].key != Product.cod_producto; i++){
        pos = abs( pos + H2(pos, size)) % size;
    }
    
    if (HT[pos].key == Product.cod_producto){
        return 0;
    }
    else{
        HT[pos].key = Product.cod_producto;
        HT[pos].prodsEnOferta = Product;
    }
    return 1;    
}

/*****
*   int    ofertaSearch
*****
*   Resumen:    Busca un elemento en el hashing de ofertas a partir de una clave dada.
*****
*   INPUT: 
*       ofertaDic   *HT     : Puntero de struct oferDic.
*       int         clave   : int que corresponde a la clave del producto a buscar.
*       int         size    : int que corresponde al tamaño del hashing.
*****
*   RETURN:
*       int         pos     : int que indica la posición en donde se encontró el dato.
*       int         -1      : int que indica que el dato no pertenece al hashing.
*****/
int ofertaSearch(oferDic *HT, int clave, int size){
    int inicio, i;
    int VACIA = -1;
    int pos = inicio = H1(clave, size);
    for (i = 0; HT[pos].key != VACIA &&  HT[pos].key != clave && i < size; i++){
        pos = abs( pos + H2(pos, size)) % size;
    }
    if (HT[pos].key == clave){
        return pos;
    }
    else{
        return -1;
    }
}