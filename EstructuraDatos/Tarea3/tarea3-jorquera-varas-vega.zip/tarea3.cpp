#include <iostream>
#include "hashCliente.h"
#include <stdlib.h>
#include <stdio.h>

using namespace std;

int main(){

    FILE *productosFile, *ofertasFile, *comprasFile, *boletasFile; // Archivos a utilizar en el programa.

    int cantProductos = 0, sizeProductos; // Cantidad de elementos en el archivo productos.dat.
    int cantOfertas = 0, sizeOfertas; // Cantidad de elementos en el archivo ofertas.dat.
    int clientes = 0, cantCompras = 0, sizeCompras; // Cantidad de clientes y productos en el archivo compras.txt.

    int posCompra, posProd, posOferta; // Indicie que ocupa un producto en su respectivo diccionario.

    int gastoTotal; // Gasto total por parte de cada cliente.
    int precio, descuento, cantidadDescuento, repeticiones; // Precio del producto, descuento que recibe, cantidad de elementos para que aplique el descuento, cantidad de productos comprados respectivamente.

    producto productoStruct; // Variable a usar para almacenar los structs en el archivo productos.dat.
    oferta ofertaStruct; // Variable a usar para almacenar los structs en el archivo ofertas.dat.
    
    prodDic *hashProductos; // Puntero hacia una llave y un productoStruct. Usado para almacenar los structs de productos.
    oferDic *hashOfertas; // Puntero hacia una llave y un ofertaStruct. Usado para almacenar los structs de ofertas.
    compraDic *hashCompras; // Puntero hacia una llave y un int repeticiones. Usado para almacenar los datos de archivo compras.

    int Codigo; // Codigo del producto, usado para vincular las estructuras y sus valores.

    int i, j, k; // Variables auxiliares (iteradores, comparadores, etc).

    // Apertura de ficheros.
    productosFile = fopen("productos.dat","r");
    ofertasFile = fopen("ofertas.dat", "r");
    comprasFile = fopen("compras.txt", "r");
    boletasFile = fopen("boletas.txt", "w");

    // Comprobación error de archivos de lectura 
    if (productosFile == NULL){
        cout << "Hubo un error al abrir el archivo productos.dat" << endl;
        fclose(productosFile);
        fclose(ofertasFile);
        fclose(comprasFile);
        fclose(boletasFile);
        exit(1);
    }
    if (ofertasFile == NULL){
        cout << "Hubo un error al abrir el archivo ofertas.dat" << endl;
        fclose(productosFile);
        fclose(ofertasFile);
        fclose(comprasFile);
        fclose(boletasFile);
        exit(1);
    }
    if (comprasFile == NULL){
        cout << "Hubo un error al abrir el archivo compras.txt" << endl;
        fclose(productosFile);
        fclose(ofertasFile);
        fclose(comprasFile);
        fclose(boletasFile);
        exit(1);
    }
    if (boletasFile == NULL){
        cout << "Hubo un error al crear el archivo boletas.txt" << endl;
        fclose(productosFile);
        fclose(ofertasFile);
        fclose(comprasFile);
        fclose(boletasFile);
        exit(1);
    }

    i = fscanf(comprasFile, "%d", &clientes);

    // Escribe la cantidad de clientes en el archivo boletas.txt
    fprintf(boletasFile, "%d\n", clientes);

    // Si no hay clientes, no hay para que seguir.
    if ((i != 1) || (clientes < 1)){
        fclose(productosFile);
        fclose(ofertasFile);
        fclose(comprasFile);
        fclose(boletasFile);
        return 0;  
    }

    // Procesa los datos del archivo productos.dat
    i = fread(&cantProductos, sizeof(int), 1, productosFile);

    // Asigna el tamaño para el hashing de productos con orden de carga = 0.7.
    sizeProductos = ((cantProductos *10) / 7);

    // Asigna el espacio de memoria para almacenar los structs de productos.
    hashProductos = (prodDic *)malloc(sizeof(prodDic)*sizeProductos);

    // Inicializa todas las llaves en el hashing con -1
    for(k = 0; k < sizeProductos ; ++k){
        hashProductos[k].key = -1;
    }

    // Si no hay productos, no hay para que seguir.
    if ((i != 1) || (cantProductos < 1)){
        fclose(productosFile);
        fclose(ofertasFile);
        fclose(comprasFile);
        fclose(boletasFile);
        return 0;  
    }

    // Inicia el algoritmo para insertar los structs en el hashing de productos.
    for(i = 0; i < cantProductos; ++i){
        fread(&productoStruct, sizeof(producto), 1, productosFile);
        prodInsert(hashProductos, productoStruct, sizeProductos);
    }   // Fin del algoritmo para insertar los structs en el hashing de productos.

    // Procesa los datos del archivo ofertas.dat.
    i = fread(&cantOfertas, sizeof(int), 1, ofertasFile);  

    // Asigna el tamaño para el hashing de ofertas con orden de carga = 0.7.
    sizeOfertas = ((cantOfertas *10) / 7);

    // Asigna el espacio de memoria para almacenar los structs de ofertas.
    hashOfertas = (oferDic*)malloc(sizeof(oferDic)*sizeOfertas);

    // Inicializa todas las llaves en el arreglo con -1.
    for(k = 0; k < sizeOfertas ; ++k){
        hashOfertas[k].key = -1;
    }

    // Inicia el algoritmo para insertar los structs en el hashing de ofertas.
    for(i = 0; i < cantOfertas; ++i){
        fread(&ofertaStruct, sizeof(oferta), 1, ofertasFile);
        ofertaInsert(hashOfertas, ofertaStruct, sizeOfertas);
    } // Fin del algoritmo para insertar los structs en el hashing de ofertas.

    // Inicia el algoritmo para procesar las compras.
    for (i = 0; i < clientes; ++i){ 
        fscanf(comprasFile, "%d", &cantCompras);

        // Asigna el tamaño para el hashing de clientes 
        // con orden de carga = 0.5 al no tener restricción como con los otros 2 hashings.
        sizeCompras = (cantCompras *2);

        // Re-inicializa el gastoTotal cada vez que cambie de cliente.
        gastoTotal = 0;

        // Asigna el espacio de memoria para almacenar las claves y repeticiones en el hashing de compras.
        hashCompras = (compraDic*)malloc(sizeCompras * sizeof(compraDic));

        // Inicializa todas las llaves en el arreglo con -1 y las repeticiones en 0
        for(k = 0; k < sizeCompras ; ++k){
            hashCompras[k].key = -1;
            hashCompras[k].repeticiones = 0;
        }

        // Inicia el algoritmo para procesar las compras de un cliente.    
        for (j = 0; j < cantCompras; ++j){
            fscanf(comprasFile, "%d", &Codigo);

            // Almacena la clave en el hashing de compras, obteniendo su respectiva posición (indice).
            posCompra = compraInsert(hashCompras, Codigo, sizeCompras);

            // Obtiene la posición del mismo producto en el hashing de productos.
            posProd = prodSearch(hashProductos, Codigo, sizeProductos);

            // Obtiene la posición del mismo producto en el hashing de ofertas.
            posOferta = ofertaSearch(hashOfertas, Codigo, sizeOfertas);

            // Obtiene el precio del producto
            precio = hashProductos[posProd].prod.precio;

            // Si la posición el producto en el hashing de ofertas es distinto a -1 significa que existe en dicho hashing.
            if(posOferta != -1){

                // Obtiene el descuento, la cantidad necesaria para aplicar el descuento y las repeticiones del producto.
                descuento = hashOfertas[posOferta].prodsEnOferta.descuento;
                cantidadDescuento = hashOfertas[posOferta].prodsEnOferta.cantidad_descuento;
                repeticiones = hashCompras[posCompra].repeticiones;

                // Si el modulo es igual a 0 significa que el cliente alcanzó
                // la cantidad de productos necesaria para aplicar un descuento.
                if(repeticiones % cantidadDescuento == 0){
                    gastoTotal = gastoTotal + precio - descuento;
                }
                else{
                    gastoTotal = gastoTotal + precio;
                }
            }
            else{ // Si la posición fue -1, no hay descuento.
                gastoTotal = gastoTotal + precio;
            }
        } // Finliza el algoritmo para procesar las compras de un cliente.    

        // Añade el gasto total del cliente al archivo boletas.txt.
        fprintf(boletasFile, "%d\n", gastoTotal);

        // Libera la memoria usada por el hashing de compras.
        free((void*)hashCompras);
        
    } // Finaliza el algoritmo para procesar las compras.

    // Cierra los ficheros utilizados
    fclose(productosFile);
    fclose(ofertasFile);
    fclose(comprasFile);
    fclose(boletasFile);

    // Libera la memoria utilizada
    free((void *) hashOfertas);
    free((void *) hashProductos);

    // Fin del programa.
    return 0;
}