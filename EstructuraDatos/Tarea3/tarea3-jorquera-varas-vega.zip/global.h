#include <stdlib.h>

using namespace std;

/*****
*   int    H1
*****
*   Resumen: Genera un indice int (para el hashing) a partir de la transformación de otros dos int.
*****
*   INPUT: 
*       int key : int que corresponde a la clave del hashing.
*       int size: int que corresponde al tamaño del hashing.
*****
*   RETURN:
*       int indice  : int que corresponde al módulo entre key y size o key y (size - 1) según corresponda
*****/
int H1(int key, int size){
    int indice;
    if(size > 1){
        indice = (key%(size - 1));
    }
    else{
        indice = (key%size);
    }
    return indice;
}

/*****
*   int    H2
*****
*   Resumen: Genera un indice int (para el hashing) a partir de la transformación de otros dos int.
*****
*   INPUT: 
*       int key : int que corresponde a la clave del hashing.
*       int size: int que corresponde al tamaño del hashing.
*****
*   RETURN:
*       int indice  : int que corresponde a la suma positiva entre (key*size) y (size + 1).
*****/
int H2(int key, int size){
    int indice;
    indice = abs((key*size) + size+1);
    return indice;
}