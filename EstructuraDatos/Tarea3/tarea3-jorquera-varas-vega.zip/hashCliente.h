#include "hashProd.h"
#include <stdlib.h>
#include <stdio.h>

using namespace std;

// Struct para los productos y las ofertas

typedef struct {
    int key;
    int repeticiones;
} compraDic;

/*****
*   int    compraInsert
*****
*   Resumen:    Inserta un elemento en el hashing de compra, que se compone por 
*               key (clave) y repeticiones (veces que se repite la clave).
*****
*   INPUT: 
*       compraDic   *HT : Puntero de struct compraDic.
*       int         k   : int que corresponde a la clave que se quiere insertar.
*       int         size: int que corresponde al tamaño del hashing.
*****
*   RETURN:
*       int         pos : int que corresponde a la posición en que se insertaron los datos.
*****/
int compraInsert(compraDic *HT, int k, int size){
    int inicio, i;
    int VACIA = -1;
    int pos = inicio = H1(k, size);
    for (i = 0; HT[pos].key != VACIA &&  HT[pos].key != k; i++){
        pos = abs( pos + H2(pos, size)) % size;
    }
    if (HT[pos].key == k){
        HT[pos].repeticiones = HT[pos].repeticiones + 1;
    }
    else{
        HT[pos].key = k;
        HT[pos].repeticiones = 1;
    }
    return pos;
}