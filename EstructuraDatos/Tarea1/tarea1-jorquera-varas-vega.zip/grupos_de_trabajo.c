#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*****
*Tipo int  *rande
*****
*Resumen: Esta funcion recibe un entero n y genera un arreglo con numeros enteros aleatorios de 0 a n.
*****
* INPUT: 
*       int n : Tamaño del arreglo
*****
* RETURN:
*       int range : Arreglo con numeros enteros aleatorios.
*****/
int *rande(int n){

    srand(time(NULL)); /* creación y cambio de semilla para que cada vez que se llame la función genere un arreglo distinto */

    /* Variables a utilizar */
    int c, c2, num_random;    
    int *range;
    int flag, set, aux = 0, aux2 = 0 ;

    /* Asignación de memoria para range */
    range = (int*)malloc(sizeof(int)*n);

    /* Verificación de asignación de memoria para range */
    if (range == NULL){
        printf("No hay espacio de memoria suficiente para generar un arreglo aleatorio");
        exit(1);
    }

    /* Algoritmo para llenar el arreglo con numeros sin repetir */
    for (c = 0; c < n-1; ++c){
        flag = 0;

        while (flag == 0){
            c2 = 0;
            set = 0;
            num_random = rand() % n ;

            while (c2 < n){
                if (range[c2] == num_random) {set = set + 1;};
                c2 = c2+1;
            }

            if (set == 0){
                range[c] = num_random;
                flag = 1;
            }
        }        
    }   

    /* Algoritmo necesario para evitar que el cero quede siempre en la última posición del arreglo */

    aux = rand()%2;
    if (aux == 1){
        while(aux2 == 0){
            aux2 = rand() % n;
        }

        range[n-1] = range[aux2];
        range[aux2] = 0;
            
    }

    return range;
}


/* datos entregados por el problema */
typedef struct {
    int id_curso;
    char sigla_curso[7];
    char nombre_curso[30];
    int integrantes_por_grupo;
} curso;

typedef struct {
    char rol_estudiante[12];
    char carrera [4];
    char nombre_completo [41];
    int numero_cursos ;
    int id_cursos_inscritos[50];
} alumno;

/* Inicio del programa */
int main(){

    /*archivos*/
    FILE *fp_alumno;
    FILE *fp_cursos;
    FILE *fp_grupos;

    /*variables*/
    int n,m,i,j,c2,c3,c4;
    curso *cursos;
    alumno *alumnos;
    char nombre_txt[20];
    int num_grupo;
    int *range;
    int contador;

    /*programa*/

    /* Abrir archivos de lectura */
    fp_alumno = fopen("alumnos.dat","r");
    fp_cursos = fopen("cursos.dat","r");

    /* Comprobación error de archivos de lectura */
    if (fp_alumno == NULL){
        printf("Hubo un error al abrir el archivo alumnos.dat");
        exit(1);
    }
    if (fp_cursos == NULL){
        printf("Hubo un error al abrir el archivo cursos.dat");
        exit(1);
    }
    
    /* Asignar el número de structs que posee el archivo alumnos.dat y cursos.dat */
    i = fread(&n,sizeof(int),1,fp_alumno);
    j = fread(&m,sizeof(int),1,fp_cursos);

    /* Comprobación de error al leer los archivos */
    if (i != 1){
        printf("Hubo un error al leer el archivo alumnos.dat");
        exit(1);
    }
    if (j != 1){
        printf("Hubo un error al leer el archivo cursos.dat");
        exit(1);
    }

    /*Asignacion de memoria de structs*/
    alumnos = (alumno*)malloc(sizeof(alumno)*n);
    cursos = (curso*)malloc(sizeof(curso)*m);

    /* Verificacion de memoria de structs*/
    if (alumnos == NULL){
        printf("No hay memoria suficiente para asignar a 'alumnos'.");
        exit(1);
    }
    if (cursos == NULL){
        printf("No hay memoria suficiente para asignar a 'cursos'.");
        exit(1);
    }

    /* Asignar los datos de los archivos a los structs */
    i = fread(alumnos, sizeof(alumno), n, fp_alumno);
    j = fread(cursos, sizeof(curso), m, fp_cursos);

    /* Comprobación de error al leer los archivos */
    if (i != n){
        printf("Hubo un error al leer el archivo alumnos.dat");
        exit(1);
    }
    if (j != m){
        printf("Hubo un error al leer el archivo cursos.dat");
        exit(1);
    }

    /* Clausura de archivos */
    fclose(fp_alumno);
    fclose(fp_cursos);
    

    /* Verificación de error y asignación de memoria para range */
    range = (int*)malloc(sizeof(int)*n);
    if (range == NULL){
        printf("No hay espacio de memoria suficiente para generar un arreglo aleatorio");
        exit(1);
    }

    /* Construir arreglo de numeros aleatorios sin repetición */
    range = rande(n);


    /* Iteración en el struct de cursos */
    for (c2 = 0; c2 < m; ++c2){

        if (cursos[c2].integrantes_por_grupo > 0){
            
            /* Definir nombre del archivo a crear */
            strcpy(nombre_txt, "grupos-");
            strcat(nombre_txt, cursos[c2].sigla_curso);
            strcat(nombre_txt,".txt");

            /* Apertura y verificación de error del archivo de texto para los grupos*/
            fp_grupos = fopen(nombre_txt, "w");
            
            if (fp_grupos == NULL){
                printf("Hubo un error al crear el archivo ");
                exit(1);
            }

            fprintf(fp_grupos, "%s - %s\n", cursos[c2].sigla_curso, cursos[c2].nombre_curso);
            
            num_grupo = 0;
            contador = 0;

            /* For para iterar el struct de alumnos*/
            for(c3 = 0; c3 < n; ++c3){

                /* For para iterar en los cursos de cada alumno */
                for(c4 = 0; c4 < alumnos[range[c3]].numero_cursos; ++c4){

                    if (cursos[c2].id_curso == alumnos[range[c3]].id_cursos_inscritos[c4]){

                        if ((num_grupo ==0)||(contador == cursos[c2].integrantes_por_grupo)){
                            num_grupo = num_grupo + 1;
                            fprintf(fp_grupos, "\nGrupo %d:\n%s\n",num_grupo,alumnos[range[c3]].nombre_completo);
                            contador = 1;
                        }
                        else{
                            contador = contador + 1;
                            fprintf(fp_grupos, "%s\n", alumnos[range[c3]].nombre_completo);
                        }
                    }

                }
                
            }


            fclose(fp_grupos);
        }

    }

    /* Liberar memoria*/
    free((void*)alumnos);
    free((void*)cursos);
    /* Fin del programa */
    return 0;
}