#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*****
*Tipo INT ( entero ) ContarLineas
*****
*Resumen: Esta funcion lee un archivo entregado y como finalidad retorna el numero de lineas
de dicho archivo.
*****
* INPUT: 
*       char *Archivo : Arreglo de caracteres con el nombre del archivo.
*****
* RETURN:
*       int Lineas: Numero de lineas.
*****/
int ContarLineas(char *archivo){

    /*Variables a utilizar */
    FILE *file;
    int lineas = -1;
    char palabra[200];
    file = fopen(archivo, "r");

    /* Comprobación error del archivo */    
    if (file == NULL){
        printf("Hubo un error al abrir el archivo");
        exit(1);
    }

    /*Algoritmo*/
    while(!feof(file)){
        ++lineas;
        fscanf(file,"%s",palabra);
    }
    fclose(file);
    return lineas;
}

/*****
*Tipo VOID Crear
*****
*Resumen: Esta funcion lee un archivo entregado y como finalidad crea un arreglo con todas las 
palabras del archivo como elementos. 
*****
* INPUT: 
*       char **Arreglo : Conjunto donde se guardaran las palabras, char *arch: Nombre del archivo
*****
* RETURN:
*       No retorna
*****/
void crear(char **Arr,char *arch){

    /* Variables a utilizar */
    FILE *fp_palabras;
    int c = 0;
    char *palabra;
    
    /* Abrir archivos de lectura */
    fp_palabras = fopen(arch,"r");

    /* Comprobación error del archivo */    
    if (fp_palabras == NULL){
        printf("Hubo un error al abrir el archivo %s",arch);
        exit(1);
    }

    /* Algoritmo para llenar el arreglo con las palabras */
    while (!feof(fp_palabras)){
        palabra = (char*)malloc(sizeof(char)*200);
        if (palabra == NULL){
            printf("No hay espacio de memoria suficiente para generar el arreglo de palabras.");
            exit(1);
        }
        fscanf(fp_palabras , "%s" , palabra);
        Arr[c] = palabra;
        c = c + 1;
    }

    fclose(fp_palabras);
}

/*****
*Tipo int comparacion
*****
*Resumen: Funcion que compara los caracteres de las palabras en un conjunto mediante el 
uso de strcmp y retorna un valor numerico en base al valor ASCII que tienen los caracteres comparados.
*****
* INPUT: 
*       const void *a : variable que se utiliza para asignar la letra a comparar de la palabra 1 
*       const void *b : variable que se utiliza para asignar la letra a comparar de la palabra 2
*****
* RETURN:
*       strcmp(*ia, *ib) : Funcion que retorna un entero en base al valor ASCII de los caracteres ingresados.
*****/
int comparacion(const void *a, const void *b){ 
    const char **ia = (const char **)a;
    const char **ib = (const char **)b;
    return strcmp(*ia, *ib);
} 
/*****
*Tipo int letras_iguales
*****
*Resumen: Funcion que recibe dos palabras y retorna el numero de letras iguales que tienen antes de encontrar
*         una letra distinta entre ambas.
*****
* INPUT: 
*       char *pal1 : Primera palabra a comparar.
*       int n : Largo de la primera palabra.
*       char *pal2 : Segunda palabra a comparar.
*       int m : Largo de la segunda palabra.
*****
* RETURN:
*       int num : Numero de letras iguales.
*****/
int letras_iguales(char *pal1, int n, char *pal2, int m){
    int num = 0;
    int c, L, flag = 0;
    if (n < m){
        L = n;
    }
    else{
        L = m;
    }
    
    for (c = 0 ; c < L ; ++c){
        if(flag == 0){
            if (pal1[c] == pal2[c]){
                num = num + 1;
            }
            else{
                flag = 1;
            }
        }
    }
    
    return num;
}

/*****
*Tipo Int pCML
*****
*Resumen: Esta funcion recibe el conjunto de palabras del arreglo junto a la cantidad de palabras y genera un archivo
*con el numero del prefijo mas largo.
*****
* INPUT: 
*       char **S : Conjunto de palabras.
*       int n : numero de palabras.
*****
* RETURN:
*       int x : Numero del prefijo mas largo.
*****/
int pCML (char **S, int n){
    int i,a,b,x=0,cant=0;
    FILE *Num_letras;
    for(i = 0; i < n - 1 ; ++i){
        a=strlen(S[i]);
        b=strlen(S[i+1]);
        cant=letras_iguales(S[i], a, S[i+1], b);
        if (cant>x){
            x=cant;
        }
        free((void*)S[i]);

    }
    free((void*)S[n-1]);
    
    Num_letras = fopen("salida-1.txt","w");
    fprintf(Num_letras, "%d", x);
    fclose(Num_letras);

    return x;
}


int main(){

    /*Variables a utilizar*/
    char Nombre[]="strings.txt";
    int lineas = ContarLineas(Nombre);
    char *Palabras[lineas];

    /*Programa*/
    crear(Palabras,Nombre);
    qsort(Palabras, sizeof(Palabras) / sizeof(char *), sizeof(char *), comparacion);
    pCML(Palabras, lineas);

    return 0;
}