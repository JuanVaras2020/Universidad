#include <iostream>
#include "NodoLista.h"
#include <stdlib.h> 

using namespace std;

class listaEnlazada{
    public:
        listaEnlazada(); // Constructor de lista, inicializa los punteros con un nodo fantasma  head.
        ~listaEnlazada(); // Destructor que automáticamente limpia todo. 
        void destHelp(); // Helper que limpia la memoria en todos los nodos de la lista.

        unsigned int length(); // Retorna la cantidad de elementos de la lista.
        unsigned int currPos(); // Retorna la posición actual.
        unsigned int *getValue(); // Retorna los valores almacenados en el nodo actual.
        
        int insert(unsigned int start, unsigned int finish); // Inserta un nodo con valor inicial y final en la posición actual.
        unsigned int *remove(); // Remueve el nodo en la posición actual y retorna sus valores.
        int append(unsigned int start, unsigned int finish); // Inserta un nodo al final de la lista con valor inicial y final.
        void clear(listaEnlazada *Lista); // Reinicializa la lista borrando todos los nodos.

        void moveToStart(); // Mueve la posición hacia el primer nodo.
        void moveToEnd(); // Mueve la posición hacia el último nodo.
        void prev(); // Mueve la posición hacia el nodo anterior.
        void next(); // Mueve la posición hacia el siguiente nodo.
        void moveToPos(unsigned int newPos); // Mueve la posición hacia la indicada por el parámetro.

    private:
        nodoLista *head; // Puntero hacia la cabeza (primer nodo) en la lista.
        nodoLista *tail; // Puntero hacia la cola (último nodo) en la lista
        nodoLista *curr; // Puntero hacia el nodo en la posición actual en la lista.

        unsigned int listSize; // Tamaño de la lista.
        unsigned int pos; // Posición actual en la lista.


};

/*****
*   listaEnlazada   listaEnlazada
*****
*   Resumen: Constructor de la lista. Utiliza el constructor de nodo para asignar
*            memoria al nodo "head" y a su vez inicializarlo. Los nodos "tail" y "curr"
*            apuntaran a "head" al tratarse de una lista "vacía".
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       No retorna.
*****/
listaEnlazada::listaEnlazada(){
    listSize = 0;
    pos = 0;
    head = new nodoLista;
    tail = head;
    curr = head;
}

/*****
*   listaEnlazada   ~listaEnlazada
*****
*   Resumen: Destructor de la lista enlazada. Destruye todos los nodos empezando
*            por la cabeza "head".
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       No retorna.
*****/
listaEnlazada::~listaEnlazada(){
    // listaEnlazada::destHelp();
    while(head != tail){
        curr = head;
        head = curr -> getNext();
        delete curr;
    }
    delete tail; 
}

/*****
*   unsigned int    length
*****
*   Resumen: Entrega el largo de la lista enlazada.
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       unsigned int listSize : Largo o cantidad de elementos de la lista.
*****/
unsigned int listaEnlazada::length(){
    return listSize;
}

/*****
*   unsigned int    currPos
*****
*   Resumen: Entrega la posición actual de la lista.
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       unsigned int pos : posición actual o distancia referencial (en nodos) desde
*                          la cabeza "head" hasta el nodo actual.
*****/
unsigned int listaEnlazada::currPos(){
    return pos;
}

/*****
*   unsigned int    *getValue
*****
*   Resumen: Función que entrega el puntero hacia los dos valores almacenados por el
*            nodo.
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       unsigned int *values : puntero que apunta hacia dos unsigned int, el primero
*                              almacena el valor de "inicio" del nodo y el segundo
*                              el valor de "fin" del nodo.
*****/
unsigned int *listaEnlazada::getValue(){
    unsigned int *values;
    values = (unsigned int *)malloc(sizeof(unsigned int)*2);
    values[0] = curr -> getNext() -> getStart();
    values[1] = curr -> getNext() -> getFinish();
    return values;
}

/*****
*   int    *insert
*****
*   Resumen: Función que inserta un nuevo nodo a la lista en la posición actual.
*            Los valores que tomará el nodo son los valores ingresados en los parámetros.
*            Al ingresar el nodo, aumentará el tamaño de la lista y todos los nodos
*            que estaban a partir de la pos actual antes de ingresar el nodo serán
*            "trasladados" en una posición hacia la derecha.
*****
*   INPUT: 
*       unsigned int start : valor que almacenará la variable inicio del nodo.
*       unsigned int finish : valor que almacenará la variable fin del nodo.
*****
*   RETURN:
*       int pos : valor de la posición en la que se inserto el elemento
*****/
int listaEnlazada::insert(unsigned int start, unsigned int finish){
    nodoLista *aux = curr -> getNext();
    curr -> changeNext(new nodoLista(start, finish));
    curr -> getNext() -> changeNext(aux);
    
    if(curr == tail){
        tail = curr -> getNext();
    }
    if(pos == 0){
        pos = 1;
    }
    ++listSize;
    return pos;
}

/*****
*   unsigned int    *remove
*****
*   Resumen: Función que remueve el nodo en la posición actual de la lista.
*            Al removerlo, el tamaño de la lista disminuye en una unidad y todos
*            los nodos que estaban a la derecha del nodo removido disminuirán su
*            posición en una unidad.
*            Tras remover el nodo y realizar los cambios mencionados, la función retorna
*            los un puntero hacia los valores de "inicio" y "fin" del nodo removido.
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       unsigned int *values : puntero hacia 2 elementos de tipo unsigned int.
*                              El primero almacena el valor "inicio" del nodo removido.
*                              El segundo almacena el valor "fin" del nodo removido.
*****/
unsigned int *listaEnlazada::remove(){
    if(listSize == 0){
        return NULL;
    }
    unsigned int *values = listaEnlazada::getValue();
    
    nodoLista *aux = curr -> getNext() -> getNext();

    if(curr -> getNext() == tail){
        tail = curr;
        --pos;
    }

    delete curr -> getNext();
    curr -> changeNext(aux);

    --listSize;
    return values;
}

/*****
*   int    append
*****
*   Resumen: Función que agrega un nuevo nodo al final de la lista, aumentando el 
*            tamaño de la lista en una unidad, trazlada la cola "tail" de la lista
*            hacia el nuevo nodo agregado y retorna el nuevo tamaño de la lista.
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       int listSize : variable que almacena el tamaño de la lista.
*****/
int listaEnlazada::append(unsigned int start, unsigned int finish){
    tail -> changeNext(new nodoLista(start, finish));
    tail = tail -> getNext();
    ++listSize;
    return listSize;
}

/*****
*   void    clear
*****
*   Resumen: Función que llama al destructor de la lista para liberar toda la memoria
*            almacenada y luego llama al constructor para re inicializarla como una
*            lista vacía y así poder seguir trabajando con esta.
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       No retorna.
*****/
void listaEnlazada::clear(listaEnlazada *Lista){
    delete Lista;
    Lista = new listaEnlazada;
}

/*****
*   void    moveToStart
*****
*   Resumen: Función que cambia la posición actual de la lista con el fin de moverla
*            hacia el primer elemento de esta, el que corresponde a "head" cuya
*            posición es 1.
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       No retorna.
*****/
void listaEnlazada::moveToStart(){
    curr = head;
    pos = 1;
}

/*****
*   void    moveToEnd
*****
*   Resumen: Función que cambia la posición actual de la lista con el fin de moverla
*            hacia el último elemento de esta, el que corresponde a "tail" cuya
*            posición es equivalente al largo de la lista "listSize".
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       No retorna.
*****/
void listaEnlazada::moveToEnd(){
    curr = head;
    while(curr -> getNext() != tail){
        curr = curr -> getNext();
    }
    pos = listSize;
}

/*****
*   void    moveToPos
*****
*   Resumen: Función que cambia la posición actual de la lista con el fin de moverla
*            hacia la posición ingresada en el parámetro.
*****
*   INPUT: 
*       unsigned int newPos : nueva posición actual ingresada.
*****
*   RETURN:
*       No retorna.
*****/
void listaEnlazada::moveToPos(unsigned int newPos){
    if((newPos > listSize) || (newPos == pos)){
        return;
    }
    unsigned int i;
    pos = 1;
    curr = head;
    for(i = 1; i < newPos; ++i){
        curr = curr -> getNext();
        ++pos;
    }
}

/*****
*   void    prev
*****
*   Resumen: Función que cambia la posición actual de la lista por la posición anterior.
*            Para ello, recorre los nodos desde la cabeza hasta encontrar el nodo
*            que apunta a la posición actual. Luego le resta 1 a la posición actual "pos".
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       No retorna.
*****/
void listaEnlazada::prev(){
    nodoLista *aux;
    if(curr == head){
        return;
    }
    aux = head;
    while(aux -> getNext() != curr){
        aux = aux -> getNext();
    }
    curr = aux;
    --pos;
}

/*****
*   void    next
*****
*   Resumen: Función que cambia la posición actual de la lista por la posición siguiente.
*            Para ello verifica que la posición actual sea distinta a la cola "tail"
*            y en caso de serlo, le suma uno a la posición actual.
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       No retorna.
*****/
void listaEnlazada::next(){
    if(curr != tail){
        curr = curr -> getNext();
        ++pos;
    }
}
