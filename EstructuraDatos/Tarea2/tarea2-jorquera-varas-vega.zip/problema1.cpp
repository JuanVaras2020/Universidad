#include <iostream> 
#include "LisEnlazada.h"
#include <string.h>
#include <stdio.h>

using namespace std;

/*****
*   int   mallowo
*****
*   Resumen: Función que revisa si en "lista1" hay un interválo de memoria de tamaño mayor o igual
*            a la cantidad de memoria ingresada para poder un nuevo intervalo que vaya desde (valor inicial)
*            hasta (valor inicial + memoria - 1) del intervalo inicial para así agregar este nuevo bloque
*            a "lista2".
*****
*   INPUT: 
*       listaEnlazada *lista1 : puntero hacia la lista de la cual se extraerán intervalos de memoria. 
*       listaEnlazada *lista2 : puntero hacia la lista a la cual se agregarán intervalos de memoria.
*       unsigned int memoria : cantidad de memoria que define el tamaño de los bloques de memoria.
*****
*   RETURN:
*       int start : corresponde al byte en donde comienza el bloque de memoria agregado a "lista2".
*       0 (posible retorno) : en caso de no haber encontrado un intervalo en "lista1" con la suficiente memoria.
*****/
int mallowo(listaEnlazada *lista1, listaEnlazada *lista2, unsigned int memoria){
    lista1 -> moveToStart();
    unsigned int *values;
    unsigned int start, finish;
    unsigned int i;
    for(i = 0 ; i < lista1 -> length(); ++i){
        values = lista1 -> getValue();
        start = values[0];
        finish = values[1];

        free(values); // getValue() utiliza malloc para retornar un puntero, de ahí que es necesario usar free().
        
        // verifica que el tamaño de los intervalos encontrados en lista1 sean igual o mayores a "memoria".
        if((start + memoria - 1) < (finish + 1)){
            // si cumple la condición, agrega el bloque de memoria a lista2
            lista2 -> append(start, start + memoria - 1);
            free(lista1 -> remove()); // remove() retorna un puntero con memoria asignada, de no hacer free se pierde memoria.
            
            // verifica si el intervalo encontrado se consume completamente.
            if((start + memoria - 1) != finish){
                // si aun queda memoria en el intervalo tras asignar memoria para lista2, 
                // se inserta el intervalo restante en lista1 manteniendo la misma posición del intervalo
                // que se removió.
                lista1 -> insert(start + memoria, finish);
            }
            
            return start; // retorna el byte inicial del bloque de memoria asignado.
        }
        lista1 -> next(); // iterador del for
    }   
    return 0;
}

/*****
*   int   frewe
*****
*   Resumen: Función que revisa si en "lista2" hay un intervalo que comienze con el "byte" ingresado.
*            En caso de haberlo, remueve completamente ese intervalo de "lista2" utilizando remove de
*            listaEnlazada y lo agrega (maneteniendo el orden) en "lista1" utilizando la función
*            insert de listaEnlazada, donde además revisa, en caso de tener mas de un elemento en "lista1"
*            si el valor "fin" del nodo anterior al ingresado en "lista1" es antecesor del valor "inicio"
*            del nodo ingresado para que, en caso de serlo, realizar un "merge" o unificación del intervalo.
*            *Lo mismo aplica en caso de que el valor "inicio" del nodo siguiente sea sucesor al valor "fin"
*            del nodo ingresado en "lista1".
*****
*   INPUT: 
*       listaEnlazada *lista1 : puntero hacia la lista de la cual se extraerán intervalos de memoria. 
*       listaEnlazada *lista2 : puntero hacia la lista a la cual se agregarán intervalos de memoria.
*       unsigned int byte : byte inicial del bloque de memoria a buscar.
*****
*   RETURN:
*       unsigned int memoria : cantidad de memoria que hay en el bloque liberado a partir de "byte".
*****/
unsigned int frewe(listaEnlazada *lista1, listaEnlazada *lista2, unsigned int byte){
    lista1 -> moveToStart();
    lista2 -> moveToStart();
    unsigned int *values1;
    unsigned int start, finish, start2, finish2;
    unsigned int i;
    unsigned int memoria;

    // Obtención del intervalo que comienza con "byte" en la lista2.
    for(i = 0 ; i < lista2 -> length(); ++i){
        values1 = lista2 -> getValue();
        start = values1[0];
        finish = values1[1];

        free(values1);
        
        if(start == byte){
            start2 = start;
            finish2 = finish;
            free(lista2 -> remove()); // remove() retorna un puntero a unsigned int con 2 valores asignados
            //                           de ahí la necesidad de hacerle free().
            i = lista2 -> length();
        }
        lista2 -> next();
    }


    memoria = finish2 - start2 + 1; // Asignación del tamaño del intervalo a liberar.

    // Si por alguna razón la lista 1 quedó vacía se inserta directamente el bloque liberado.
    if((lista1 -> length()) == 0){
        lista1 -> insert(start2, finish2);
        return memoria;
    }

    // Si la lista 1 no está vacía, se procede a buscar la posición en donde insertar el bloque.
    for(i = 0; i < lista1 -> length(); ++i){
        values1 = lista1 -> getValue();
        start = values1[0];
        finish = values1[1];

        free(values1);
        // itera hasta encontrar un nodo cuyo byte inicial sea mayor al byte final del bloque liberado.
        if(finish2 < start){
            // verifica si el byte final del bloque liberado es antecesor del byte inicial del nodo encontrado.
            if(finish2 + 1 == start){
                // en caso de serlo, extiende el intervalo del bloque liberado y remueve el nodo encontrado.
                finish2 = finish;
                free(lista1 -> remove());
            }
            // verifica si el for realizó por lo menos una interación, lo que significa que hay un nodo previo
            // al nodo actual.
            if(i > 0){
                // revisa los datos del nodo anterior.
                lista1 -> prev();
                values1 = lista1 -> getValue();
                start = values1[0];
                finish = values1[1];

                free(values1);
                // si el byte final del nodo anterior es antecesor del byte inicial del bloque de memoria
                // extiende el intervalo del bloque de memoria y remueve el nodo anterior.
                if(finish + 1 == start2){
                    start2 = start;
                    free(lista1 -> remove());
                }
                // en caso de que no sea antecesor, se devuelve a la posición en que estaba anteriormente
                // para no afectar el orden en donde se inserte finalmente el bloque de memoria.
                else{
                    lista1 -> next();
                }
            }
            lista1 -> insert(start2, finish2);
            return memoria; // retorna la memoria dado que ya no es necesario seguir iterando.
        }        
        lista1 -> next(); // iterador del for.
    }
    // en caso de que los valores del bloque de memoria sean mayores a los valores de todos los nodos
    // de la lista1, dicho bloque de memoria se agregará al final de la lista1.
    lista1 -> append(start2, finish2);
    return memoria; 
    // como el enunciado dice, esta función asume que siempre se liberará un bloque de memoria correcto.
}


int main(){ 
    listaEnlazada *L1; // Lista que almacena bloques de memoria libre.
    listaEnlazada *L2; // Lista que almacena bloques de memoria asignados.
    FILE *fileIn; // Archivo de lectura.
    int byte;

    char operacion[10]; // Operación indicada según el archivo.
    unsigned int M; // Cantidad de memoria inicial.
    int N; // Cantidad de operaciones en el archivo.
    unsigned int m; // Valor que indica la cantidad de memoria o el byte inicial según operación.
    

    L1 = new listaEnlazada;
    L2 = new listaEnlazada;

    fileIn = fopen("input1.dat","r");

    // Comprobación error al abrir archivos 
    if (fileIn == NULL){
        cout << "Hubo un error al abrir el archivo input1.dat" << endl;

        delete L1;
        delete L2;
        exit(1);
    }

    //Verificacion si el archivo input1.dat es vacio
    fseek(fileIn, 0 , SEEK_END);
    if (ftell(fileIn) == 0){
        cout << "El archivo input1.dat esta vacio y no es necesario analizarlo" << endl;
        fclose(fileIn);

        delete L1;
        delete L2;
        exit(3);
    }
    fseek(fileIn, 0 , SEEK_SET);

    //Creacion y comprobacion de error al crear el archivo output1.dat

    FILE *fileOut; // Archivo de escritura.
    
    fileOut = fopen("output1.dat", "w");
    if (fileOut == NULL){
        cout << "Hubo un error al crear el archivo output1.dat" << endl;

        fclose(fileIn);
        fclose(fileOut);

        delete L1;
        delete L2;
        exit(2);
    }


    int j = 0; // Verificador de elementos asignados por fscanf.
    j = fscanf(fileIn, "%u %d", &M, &N); // Obtención de M y N a partir del archivo.
    /* Comprobación error al leer las 2 primeras lineas del archivo. */
    if(j != 2){
        cout << "Error al leer al leer las líneas el archivo input1.dat" << endl;
        fclose(fileIn);
        fclose(fileOut);

        delete L1;
        delete L2;
        exit(4);
    }

    // Asignar el bloque de memoria según el valor de M.
    L1 -> insert(1, M);

    int i; // Iterador para leer las N operaciones en el archivo.
    for(i = 0; i < N; ++i){
        j = fscanf(fileIn, "%s %u", operacion, &m);
        if(j == 2){
            if(strcmp(operacion, "malloc") == 0){
                //prototipo
                byte = mallowo(L1, L2, m);
                if(byte != 0){
                    fprintf(fileOut, "Bloque de %u bytes asignado a partir del byte %d.\n", m, byte);
                }
                else{
                    fprintf(fileOut, "Bloque de %u bytes NO puede ser asignado.\n", m);
                }
            }
            if(strcmp(operacion, "free") == 0){
                fprintf(fileOut, "Bloque de %u bytes liberado.\n", frewe(L1, L2, m));
            }
        }
    }

    fclose(fileIn);
    fclose(fileOut);

    delete L1;
    delete L2;

    return 0;
}
