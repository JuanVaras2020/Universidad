#include <iostream>

using namespace std;

class nodoLista{
    public:
        nodoLista(unsigned int start = 0, unsigned int finish = 0); // Constructor del nodo de la lista. 
        ~nodoLista(); // Destructor del nodo de la lista.

        unsigned int getStart(); // Retorna el valor de inicio (donde empieza el bloque de memoria).
        unsigned int getFinish(); // Retorna el valor de fin (donde termina el bloque de memoria).

        void changeNext(nodoLista *newNext); // Cambia el puntero hacia el siguiente nodo.
        nodoLista *getNext(); // Retorna el puntero hacia el siguiente nodo.

    private:
        unsigned int inicio; // Variable que almacena el byte inicial del bloque de memoria.
        unsigned int fin; // Variable que almacena el byte final del bloque de memoria.
        nodoLista *next; // Puntero que almacena el siguiente nodo de la lista.

};

/*****
*   nodoLista   nodoLista
*****
*   Resumen: Constructor del nodo de la lista con valores entregados, si no se entregan valores, 
*            utilizará ceros por default. Inicializa el puntero next dandole valor NULL,
*            el que será (o no) cambiado por las funciones de la lista.
*****
*   INPUT: 
*       unsigned int start : valor a agregar, corresponde al byte de inicio del bloque de memoria.
*       unsigned int start : valor a agregar, corresponde al byte de término del bloque de memoria.
*****
*   RETURN:
*       No retorna.
*****/
nodoLista::nodoLista(unsigned int start, unsigned int finish){
    inicio = start;
    fin = finish;
    next = NULL;
}

/*****
*   nodoLista   ~nodoLista
*****
*   Resumen: Destructor del nodo.
*            Se utiliza para liberar la memoria que utiliza el nodo.
*            Este se puede activar de manera automática en ciertos casos
*            o de manera manual usando "delete 'nombreNodo'".
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       No retorna.
*****/
nodoLista::~nodoLista(){
    next = NULL;
}

/*****
*   unsigned int    getStart
*****
*   Resumen: Esta función retorna el valor de la variable inicio,
*            que corresponde al byte inicial en el bloque de memoria.
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       unsigned int inicio : variable contenida por el nodo.
*****/
unsigned int nodoLista::getStart(){
    return inicio;
}

/*****
*   unsigned int    getFinish
*****
*   Resumen: Esta función retorna el valor de la variable fin,
*            que corresponde al byte final en el bloque de memoria.
*****
*   INPUT: 
*       No utiliza parámetros.
*****
*   RETURN:
*       unsigned int fin : variable contenida por el nodo.
*****/
unsigned int nodoLista::getFinish(){
    return fin;
}

/*****
*   void    changeNext
*****
*   Resumen: Esta función cambia el puntero guardado en el nodo actual (hacia el siguiente nodo) "next"
*            por un puntero que apunta a otro nodo.
*****
*   INPUT: 
*       nodoLista *newNext : Nuevo puntero que apunta a un nuevo nodo.
*****
*   RETURN:
*       No retorna.
*****/
void nodoLista::changeNext(nodoLista *newNext){
    next = newNext;
}


/*****
*   nodoLista* getNext
*****
*Resumen: Esta funcion retorna el puntero hacia el siguiente nodo "next" por el nodo actual.
*****
* INPUT: 
*       No utiliza parámetros.
*****
* RETURN:
*       nodoLista next : puntero al siguiente nodo, almacenado en el nodo actual.
*****/
nodoLista *nodoLista::getNext(){
    return next;
}