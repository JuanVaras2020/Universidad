import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GL.shaders import compileProgram, compileShader
import numpy as np
from pygame.version import ver
from pygame import mixer

#Normalize x,y
def norm(x, y):
    temp_y = y*(-1)
    x_norm = x - 320
    y_norm = temp_y + 320
    return x_norm/320, y_norm/320

#check if (x, y) is around a vertex
def check_vertex(color, x, y):
    global vertices
    off = 0

    if (color == 'r'):
        off += 48
    if (color == 'o'):
        off += 24

    if (np.abs((np.abs(vertices[off]) - np.abs(x))) <= 0.02 and 
        np.abs((np.abs(vertices[off + 1]) - np.abs(y))) <= 0.02):
        v = 0

    elif (np.abs((np.abs(vertices[off + 6]) - np.abs(x))) <= 0.02 and 
        np.abs((np.abs(vertices[off + 7]) - np.abs(y))) <= 0.02):
        v = 1

    elif (np.abs((np.abs(vertices[off + 12]) - np.abs(x))) <= 0.02 and 
        np.abs((np.abs(vertices[off + 13]) - np.abs(y))) <= 0.02):
        v = 2

    elif (np.abs((np.abs(vertices[off + 18]) - np.abs(x))) <= 0.02 and 
        np.abs((np.abs(vertices[off + 19]) - np.abs(y))) <= 0.02):
        v = 3

    else:
        v = -1
    
    return v

#gets relative coordenades
def get_movement(color, x, y):
    global vertices
    off = 0

    if (color == 'r'):
        off += 48
    
    if (color == 'o'):
        off += 24
    
    x_1 = vertices[off] - x
    y_1 = vertices[off + 1] - y

    x_2 = vertices[off + 6] - x
    y_2 = vertices[off + 7] - y

    x_3 = vertices[off + 12] - x
    y_3 = vertices[off + 13] - y

    x_4 = vertices[off + 18] - x
    y_4 = vertices[off + 19] - y
    values = [(x_1, y_1) , (x_2, y_2) , (x_3, y_3) , (x_4, y_4)]
    return values

#move square coordenades
def move_square(color, values):
    global vertices
    off = 0

    if (color == 'r'):
        off += 48
    if (color == 'o'):
        off += 24

    while True:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONUP:
                update()
                return

            else:
                x, y  = pygame.mouse.get_pos()
                x_norm, y_norm = norm(x, y)

                vertices[off] = x_norm + values[0][0]
                vertices[off + 6] = x_norm + values[1][0]
                vertices[off + 12] = x_norm + values[2][0]
                vertices[off + 18] = x_norm + values[3][0]

                vertices[off + 1] = y_norm + values[0][1]
                vertices[off + 7] = y_norm + values[1][1]
                vertices[off + 13] = y_norm + values[2][1]
                vertices[off + 19] = y_norm + values[3][1]

#aux for picking
def get_movement_vertex(color, x, y, vertex):
    global vertices
    off = 0

    if (color == 'r'):
        off += 48
    
    elif (color == 'o'):
        off += 24
    
    if(vertex == 0):
        x_1 = vertices[off] - x
        y_1 = vertices[off + 1] - y
        values = (x_1, y_1)
    
    elif(vertex == 1):
        x_2 = vertices[off + 6] - x
        y_2 = vertices[off + 7] - y
        values = (x_2, y_2)

    elif(vertex == 2):
        x_3 = vertices[off + 12] - x
        y_3 = vertices[off + 13] - y
        values = (x_3, y_3)

    elif(vertex == 3):
        x_4 = vertices[off + 18] - x
        y_4 = vertices[off + 19] - y
        values = (x_4, y_4)

    return values

#picking movement
def move_square_vertex(color, values, vertex):
    global vertices
    off = 0

    if (color == 'r'):
        off += 48
    elif (color == 'o'):
        off += 24

    while True:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONUP:
                update()
                return

            else:
                x, y  = pygame.mouse.get_pos()
                x_norm, y_norm = norm(x, y)

                if(vertex == 0):
                    vertices[off] = x_norm + values[0]
                    vertices[off + 1] = y_norm + values[1]

                elif(vertex == 1):
                    vertices[off + 6] = x_norm + values[0]
                    vertices[off + 7] = y_norm + values[1]

                elif(vertex == 2):
                    vertices[off + 12] = x_norm + values[0]
                    vertices[off + 13] = y_norm + values[1]

                elif(vertex == 3):
                    vertices[off + 18] = x_norm + values[0]
                    vertices[off + 19] = y_norm + values[1]

#draws guide black cube
def set_cube():
    global vertices
    global indices

    v = vertices.tolist()
    i = indices.tolist()

    v2 = [0.0,  0.3, 0.0, 0.0 , 0.0 , 0.0,
          0.6, -0.3, 0.0, 0.0 , 0.0 , 0.0,
          0.2,  0.5, 0.0, 0.0 , 0.0 , 0.0,
          0.8, -0.1, 0.0, 0.0 , 0.0 , 0.0,
          0.8,  0.5, 0.0, 0.0 , 0.0 , 0.0,
          0.0, -0.3, 0.0, 0.0 , 0.0 , 0.0]

    i2 = [12, 13, 14,
          13, 14, 15,
          14, 15, 16,
          12, 13, 17]

    vertices = v + v2
    indices = i + i2
    update()

#load image
def set_texture():
    global vertex_src
    global fragment_src
    global size
    global vertices
    global img

    size = 5
    img = True

    vertex_src= """
    # version 330 core

    layout(location = 0) in vec3 a_position;
    layout(location = 1) in vec2 a_texture;
    out vec2 v_texture;
    void main()
    {
        gl_Position = vec4(a_position, 1.0);
        v_texture = a_texture;
    }
    """
    fragment_src = """
    # version 330 core
    in vec2 v_texture;
    out vec4 out_color;
    uniform sampler2D s_texture;
    void main()
    {
        out_color = texture(s_texture, v_texture);
    }
    """

    v = [vertices[0], vertices[1], vertices[2], 0.0, 0.0,    
         vertices[6], vertices[7], vertices[8], 0.5, 0.0,
         vertices[12], vertices[13], vertices[14], 0.0, 0.5,
         vertices[18], vertices[19], vertices[20], 0.5, 0.5,
        
         vertices[24], vertices[25], vertices[26], 0.5, 0.0, 
         vertices[30], vertices[31], vertices[32], 1.0, 0.0,
         vertices[36], vertices[37], vertices[38], 0.5, 0.5,
         vertices[42], vertices[43], vertices[44], 1.0, 0.5,
        
         vertices[48], vertices[49], vertices[50], 0.0, 0.5, 
         vertices[54], vertices[55], vertices[56], 0.5, 0.5,
         vertices[60], vertices[61], vertices[62], 0.0, 1.0,
         vertices[66], vertices[67], vertices[68], 0.5, 1.0]
    
    vertices = v
    mixer.init()
    mixer.music.load('music/PinkFloydDemo.mp3')
    mixer.music.play()
    update()

def update():
    global vertices
    global indices
    global size
    global img

    vertices=np.array(vertices, dtype=np.float32)
    indices = np.array(indices, dtype=np.uint32)
    shader = compileProgram(compileShader(vertex_src, GL_VERTEX_SHADER), compileShader(fragment_src, GL_FRAGMENT_SHADER))
    VBO = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, VBO)
    glBufferData(GL_ARRAY_BUFFER, vertices.nbytes, vertices, GL_STATIC_DRAW)

    EBO = glGenBuffers(1)
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO)
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.nbytes, indices, GL_STATIC_DRAW)

    glEnableVertexAttribArray(0) #en el layout location 0, position
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, vertices.itemsize*size, ctypes.c_void_p(0))

    glEnableVertexAttribArray(1)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, vertices.itemsize*size, ctypes.c_void_p(12))

    texture = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, texture)

    #Set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
    #Set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)

    if (img):
        image = pygame.image.load("textures/pinkfloyd.png")
        image = pygame.transform.flip(image, False, True)
        image_width, image_height = image.get_rect().size
        img_data = pygame.image.tostring(image, "RGBA")
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image_width, image_height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img_data)

    glUseProgram(shader)
    if (img):
        glClearColor(25/255, 31/255, 65/255, 1)         #dark blue
    else:
        glClearColor(144/255, 178/255, 146/255, 1)      #light green 

    glEnable(GL_DEPTH_TEST)
    #Para ver la transparencia:
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

def restart():
    global vertices
    global indices
    global size
    global img
    global vertex_src
    global fragment_src

    vertex_src = """
    # version 330
    layout(location = 0) in vec3 a_position;
    layout(location = 1) in vec3 a_color;
    out vec3 v_color;
    void main()
    {
        gl_Position = vec4(a_position, 1.0);
        v_color = a_color;
    }
    """

    fragment_src = """
    # version 330
    in vec3 v_color;
    out vec4 out_color;
    void main()
    {
        out_color = vec4(v_color, 1.0);
    }
    """


    size = 6
    img = False

    vertices = [-0.9, -0.9, 0.0, 230/255, 190/255, 93/255,      #yellow square
            -0.5, -0.9, 0.0, 230/255, 190/255, 93/255,
            -0.9, -0.5, 0.0, 230/255, 190/255, 93/255,
            -0.5, -0.5, 0.0, 230/255, 190/255, 93/255,
            
            -0.9, -0.2, 0.0, 230/255, 140/255, 93/255,          #orange square
            -0.5, -0.2, 0.0, 230/255, 140/255, 93/255,
            -0.9,  0.2, 0.0, 230/255, 140/255, 93/255,
            -0.5,  0.2, 0.0, 230/255, 140/255, 93/255,
            
            -0.9,  0.5, 0.0, 230/255, 90/255, 93/255,            #red square
            -0.5,  0.5, 0.0, 230/255, 90/255, 93/255,
            -0.9,  0.9, 0.0, 230/255, 90/255, 93/255,
            -0.5,  0.9, 0.0, 230/255, 90/255, 93/255]


    indices = [0, 1, 2,
               1, 2, 3,
               4, 5, 6,
               5, 6, 7,
               8, 9, 10,
               9, 10, 11]

    update()

def snipping():
    global vertices
    vertices[0], vertices[1] = 0.0, -0.3
    vertices[6], vertices[7] = 0.6, -0.3
    vertices[12], vertices[13] = 0.0, 0.3
    vertices[18], vertices[19] = 0.6, 0.3

    vertices[24], vertices[25] = 0.6, -0.3
    vertices[30], vertices[31] = 0.8, -0.1
    vertices[36], vertices[37] = 0.6, 0.3
    vertices[42], vertices[43] = 0.8, 0.5

    vertices[48], vertices[49] = 0.0, 0.3
    vertices[54], vertices[55] = 0.6, 0.3
    vertices[60], vertices[61] = 0.2, 0.5
    vertices[66], vertices[67] = 0.8, 0.5

    update()
        


vertex_src = """
# version 330
layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_color;
out vec3 v_color;
void main()
{
    gl_Position = vec4(a_position, 1.0);
    v_color = a_color;
}
"""

fragment_src = """
# version 330
in vec3 v_color;
out vec4 out_color;
void main()
{
    out_color = vec4(v_color, 1.0);
}
"""

pygame.init()
pygame.display.set_caption('Proyecto Computacion Grafica')
screen = pygame.display.set_mode((640, 640),pygame.OPENGL|pygame.DOUBLEBUF|pygame.RESIZABLE)
clock = pygame.time.Clock()

vertices = [-0.9, -0.9, 0.0, 230/255, 190/255, 93/255,      #yellow square
            -0.5, -0.9, 0.0, 230/255, 190/255, 93/255,
            -0.9, -0.5, 0.0, 230/255, 190/255, 93/255,
            -0.5, -0.5, 0.0, 230/255, 190/255, 93/255,
            
            -0.9, -0.2, 0.0, 230/255, 140/255, 93/255,      #orange square
            -0.5, -0.2, 0.0, 230/255, 140/255, 93/255,
            -0.9,  0.2, 0.0, 230/255, 140/255, 93/255,
            -0.5,  0.2, 0.0, 230/255, 140/255, 93/255,
            
            -0.9,  0.5, 0.0, 230/255, 90/255, 93/255,       #red square
            -0.5,  0.5, 0.0, 230/255, 90/255, 93/255,
            -0.9,  0.9, 0.0, 230/255, 90/255, 93/255,
            -0.5,  0.9, 0.0, 230/255, 90/255, 93/255]


indices = [0, 1, 2,
           1, 2, 3,
           4, 5, 6,
           5, 6, 7,
           8, 9, 10,
           9, 10, 11]

size = 6
img = False

update()

#the main application loop
running = True

while running:
    off = 0

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_q:
                running = False

            elif event.key == pygame.K_c:
                set_cube()

            elif event.key == pygame.K_t:
                set_texture()

            elif event.key == pygame.K_r:
                restart()

            elif event.key == pygame.K_s:
                snipping()

        
        elif pygame.mouse.get_pressed()[0]:
            x, y  = pygame.mouse.get_pos()
            x_norm, y_norm = norm(x, y)

            #yellow square
            if (x_norm >= min(vertices[off], vertices[off + 6], vertices[off + 12], vertices[off + 18]) 
                and x_norm <= max(vertices[off], vertices[off + 6], vertices[off + 12], vertices[off + 18]) 
                and y_norm >= min(vertices[off + 1], vertices[off + 7], vertices[off + 13], vertices[off + 19])
                and y_norm <= max(vertices[off + 1], vertices[off + 7], vertices[off + 13], vertices[off + 19])):

                vertex = check_vertex('y', x_norm, y_norm)

                if (vertex != -1):
                    x_move_vertex, y_move_vertex  = pygame.mouse.get_pos()
                    x_move_vertex_norm, y_move_vertex_norm = norm(x_move_vertex, y_move_vertex)
                    values = get_movement_vertex('y', x_move_vertex_norm, y_move_vertex_norm, vertex)
                    move_square_vertex('y', values, vertex)

                else:
                    x_move, y_move  = pygame.mouse.get_pos()
                    x_move_norm, y_move_norm = norm(x_move, y_move)
                    values = get_movement('y', x_move_norm, y_move_norm)
                    move_square('y', values)

            #orange square
            elif (x_norm >= min(vertices[off + 24], vertices[off + 30], vertices[off + 36], vertices[off + 42]) 
                and x_norm <= max(vertices[off + 24], vertices[off + 30], vertices[off + 36], vertices[off + 42]) 
                and y_norm >= min(vertices[off + 25], vertices[off + 31], vertices[off + 37], vertices[off + 43])
                and y_norm <= max(vertices[off + 25], vertices[off + 31], vertices[off + 37], vertices[off + 43])):

                vertex = check_vertex('o', x_norm, y_norm)
                
                if (vertex != -1):
                    x_move_vertex, y_move_vertex  = pygame.mouse.get_pos()
                    x_move_vertex_norm, y_move_vertex_norm = norm(x_move_vertex, y_move_vertex)
                    values = get_movement_vertex('o', x_move_vertex_norm, y_move_vertex_norm, vertex)
                    move_square_vertex('o', values, vertex)

                else:
                    x_move, y_move  = pygame.mouse.get_pos()
                    x_move_norm, y_move_norm = norm(x_move, y_move)
                    values = get_movement('o', x_move_norm, y_move_norm)
                    move_square('o', values)

            #red square
            elif (  x_norm >= min(vertices[off + 48], vertices[off + 54], vertices[off + 60], vertices[off + 66]) 
                and x_norm <= max(vertices[off + 48], vertices[off + 54], vertices[off + 60], vertices[off + 66]) 
                and y_norm >= min(vertices[off + 49], vertices[off + 55], vertices[off + 61], vertices[off + 67])
                and y_norm <= max(vertices[off + 49], vertices[off + 55], vertices[off + 61], vertices[off + 67])):

                vertex = check_vertex('r', x_norm, y_norm)

                if (vertex != -1):
                    x_move_vertex, y_move_vertex  = pygame.mouse.get_pos()
                    x_move_vertex_norm, y_move_vertex_norm = norm(x_move_vertex, y_move_vertex)
                    values = get_movement_vertex('r', x_move_vertex_norm, y_move_vertex_norm, vertex)
                    move_square_vertex('r', values, vertex)

                else:
                    x_move, y_move  = pygame.mouse.get_pos()
                    x_move_norm, y_move_norm = norm(x_move, y_move)
                    values = get_movement('r', x_move_norm, y_move_norm)
                    move_square('r', values)


    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
    glDrawElements(GL_TRIANGLES, len(indices),GL_UNSIGNED_INT, None)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()