package main

import (
	"fmt"
	"math/rand"
	"net"
	"strconv"
	"strings"
	"time"
)

//Funcion de bienvenida
func welcome(PUERTO string) {
	fmt.Println("[*] Bienvenidos al servidor cachipun")
	fmt.Printf("[*] El servidor está abierto en el puerto localhost%s\n", PUERTO)
}

//Funcion de que entrega un puerto aleatorio
func RandomPort() string {
	rand.Seed(time.Now().UnixNano())
	min := 50003
	max := 50020
	random := rand.Intn(max-min+1) + min
	PORT := strconv.Itoa(random)

	return (":" + PORT)
}

//Función para retornar una jugada aleatoria del bot (seran convertidas en el servidor intermedio)
func Jugada() string {
	rand.Seed(time.Now().UnixNano())
	random := rand.Intn(3) + 1
	choice := strconv.Itoa(random)

	return (choice)
}

//Funcion para indicar que los servidores no estarán disponibles un 10% de las veces
func Operational() string {
	rand.Seed(time.Now().UnixNano())
	random := rand.Intn(10)

	//random == 1 solo ocurre un 10% de las veces
	if random == 1 {
		return "not_operational"
	} else {
		return "operational"
	}
}

//Funcion para crear la partida
func CreateMatch(R_PORT string) {

	//Conexión para una partida
	BUFFER := 1024
	s, err := net.ResolveUDPAddr("udp4", R_PORT)

	if err != nil {
		fmt.Println(err)
		return
	}

	connection, err := net.ListenUDP("udp4", s)

	if err != nil {
		fmt.Println(err)
		return
	}

	defer connection.Close()
	buffer := make([]byte, BUFFER)
	//-------------------------------

	//Bucle de la partida, termina cuando el mensaje enviado por el servidor es 'game'
	for {
		//Lectura
		n, addr, err := connection.ReadFromUDP(buffer)
		//------

		//La partida continua
		if strings.TrimSpace(string(buffer[0:n])) == "partida" {

			//Jugada aleatoria
			jugada := []byte(Jugada())
			//----------------

			//Envio de jugada aleatoria
			_, err = connection.WriteToUDP(jugada, addr)
			fmt.Printf("El bot ha enviado %s\n", jugada)
			if err != nil {
				fmt.Println(err)
				return
			}
			//-------------------------
			//Vuelve al inicio del bucle

			//La partida finaliza
		} else if strings.TrimSpace(string(buffer[0:n])) == "game" {
			fmt.Println("La partida ha terminado")
			return
		}
	}
}

func main() {
	//Conexión principal con servidor intermediario
	PUERTO := ":50001"
	go welcome(PUERTO)

	BUFFER := 1024
	s, err := net.ResolveUDPAddr("udp4", PUERTO)

	if err != nil {
		fmt.Println(err)
		return
	}
	connection, err := net.ListenUDP("udp4", s)

	if err != nil {
		fmt.Println(err)
		return
	}

	defer connection.Close()
	buffer := make([]byte, BUFFER)
	//-----------------------------------------------

	//Bucle hasta que el cliente elija salir del juego
	for {
		//Primera lectura. Puede ser play o exit
		n, addr, err := connection.ReadFromUDP(buffer)
		fmt.Println("-> ", string(buffer[0:n]))
		//----------------------------------------

		//Condición de termino del juego
		if strings.TrimSpace(string(buffer[0:n])) == "exit" {
			fmt.Println("Cerrando el servidor Cachipun")
			mensaje := []byte("exit")
			_, err = connection.WriteToUDP(mensaje, addr)
			if err != nil {
				fmt.Println(err)
			}
			return
			//-------------------------------

			//Comienza la partida
		} else if strings.TrimSpace(string(buffer[0:n])) == "play" {
			fmt.Println("El jugador ha requerido una PARTIDA")

			//Chequeo de servidores
			operational := []byte(Operational())
			//---------------------

			//Servidores caidos
			if string(operational) == "not_operational" {
				fmt.Println("Servidores no operativos")
				_, err = connection.WriteToUDP(operational, addr)
				if err != nil {
					fmt.Println(err)
					return
				}
				//Vuelve al inicio del bucle princiapal
				//---------------------

				//Servidores operativos
			} else {
				//Elección de puerto aleatorio
				R_PORT := []byte(RandomPort())
				//----------------------------

				//Envio de puerto aleatorio al servidor intermedio
				_, err = connection.WriteToUDP(R_PORT, addr)
				if err != nil {
					fmt.Println(err)
					return
				}
				//-------------------------------------------------

				//Crear partida
				go CreateMatch(string(R_PORT))
				//-------------

				//Vuelve al inicio del bucle principal
			}
		}
	}
}
