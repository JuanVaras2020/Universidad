import socket as skt

#Convierte la jugada del bot a piedra, papel o tijera
def convert(jugada):
    if (jugada == '1'):
        return 'papel'

    elif (jugada == '2'):
        return 'piedra'
    
    elif (jugada == '3'):
        return 'tijera'

#Funcion que determina el ganador. Retorna un string tipo: 'jugadabot,ganador,puntaje_jugador,puntaje_bot'
#Por ejemplo, si el jugador envió 'tijera' y el bot 'papel' y ambos tienen 0 puntos, el retorno seria:
#'papel,j,1,0'
def DetGanador(j1, j2, points1, points2):
    if (j1 == 'tijera' and j2 == 'papel'):
        points1_string = str(points1 + 1)
        points2_string = str(points2)
        return j2 + ',j' + ',' + points1_string + ',' + points2_string
    
    elif (j1 == 'tijera' and j2 == 'piedra'):
        points1_string = str(points1)
        points2_string = str(points2 + 1)
        return j2 + ',b' + ',' + points1_string + ',' + points2_string

    elif (j1 == 'piedra' and j2 == 'tijera'):
        points1_string = str(points1 + 1)
        points2_string = str(points2)
        return j2 + ',j' + ',' + points1_string + ',' + points2_string

    elif (j1 == 'piedra' and j2 == 'papel'):
        points1_string = str(points1)
        points2_string = str(points2 + 1)
        return j2 + ',b' + ',' + points1_string + ',' + points2_string

    elif (j1 == 'papel' and j2 == 'piedra'):
        points1_string = str(points1 + 1)
        points2_string = str(points2)
        return j2 + ',j' + ',' + points1_string + ',' + points2_string

    elif (j1 == 'papel' and j2 == 'tijera'):
        points1_string = str(points1)
        points2_string = str(points2 + 1)
        return j2 + ',b' + ',' + points1_string + ',' + points2_string
    
    else:
        points1_string = str(points1)
        points2_string = str(points2)
        return j2 + ',e' + ',' + points1_string + ',' + points2_string



serverAddr = 'localhost'    

#CACHIPUN
PortCachipun = 50001
SocketCachipun = skt.socket(skt.AF_INET, skt.SOCK_DGRAM)
#--------

#Cliente
PortCliente = 50002
SocketCliente = skt.socket(skt.AF_INET, skt.SOCK_STREAM)
SocketCliente.bind(('', PortCliente))
SocketCliente.listen(1)
print("Conexion abierta. Escuchando solicitudes en el puerto ", PortCliente)
clientSocketCliente, clientAddr = SocketCliente.accept()
print("Conexion exitosa con el cliente")
#---------

#Bucle principal. Su condicion de salida es que cuando la respuesta sea 'exit'
while (True):
    
    #Primera recepcion con el cliente
    msg_cliente = clientSocketCliente.recv(2048).decode()
    toSend = msg_cliente

    #Envio del mensaje del cliente a cachipun
    SocketCachipun.sendto(toSend.encode(), (serverAddr,PortCachipun))

    #Respuesta del servidor cachipun
    msg, addr = SocketCachipun.recvfrom(2048)
    respuesta = msg.decode()

    #Termino del juego
    if (respuesta == 'exit'):
        clientSocketCliente.send(respuesta.encode())                                    
        print("Apagando servidor intermedio")
        break

    #Servidores no disponibles
    elif (respuesta == 'not_operational'):
        print("Consultando disponibilidad de servidores")
        clientSocketCliente.send(respuesta.encode())
        print("Servidor cachipun fuera de servicio")

    #Inicio de partida (respuesta = Puerto donde será la partida)
    else:
        #Envio de respueseta al cliente de que la partida va a comenzar
        print("Consultando disponibilidad de servidores")
        play = 'play'
        clientSocketCliente.send(play.encode())

        #respuesta de cachipun tiene el formato :500XX, por lo que hay que hacer un slicing
        GamePort = int(respuesta[1:])
        print("Creando partida en el puerto ", GamePort)

        GameSocket = skt.socket(skt.AF_INET, skt.SOCK_DGRAM)

        #puntajes
        j = 0
        b = 0

        #Bucle de la partida
        while(True):

            #Recepcion de jugadas, la del bot debe convertirse con la funcion convert()
            jugada_jugador = clientSocketCliente.recv(2048).decode()

            #Indicar al servidor cachipun que la partida continua
            continuar = 'partida'
            GameSocket.sendto(continuar.encode(),  (serverAddr,GamePort))
            bot, addr = GameSocket.recvfrom(2048)

            jugada_bot = bot.decode()
            jugada_bot_c = convert(jugada_bot)
            print("El bot jugó ", jugada_bot_c)

            #Se determina el ganador
            winner = DetGanador(jugada_jugador, jugada_bot_c, j, b)

            #Asignacion de puntajes descomp[2] y descomp[3] son los puntajes actuales
            descomp = winner.split(',')
            j = int(descomp[2])
            b = int(descomp[3])

            #Si uno de los puntajes es 3, se termina la partida
            if (j == 3 or b == 3):
                #Se agrega la palabra ',game' al mensaje para el cliente para indicarle que se acabo la partida
                game = winner + ',game'
                clientSocketCliente.send(game.encode())
                GameSocket.sendto(game.encode(), (serverAddr,GamePort))
                print("Partida finalizada")
                GameSocket.close()
                break
            
            #Si no entró al if, se envia la informacion del asalto al cliente
            clientSocketCliente.send(winner.encode())

#Cierre de sockets
clientSocketCliente.close()
SocketCachipun.close()