import socket as skt

#Función de bienvenida
def Welcome():
    print("-------------------------------------------")
    print("Bienvenido al juego Cachipun 2021 - 1")
    print("-------------------------------------------")
    print("\n")

#Función de Menu para indicar si queremos jugar o salir
def Menu_to_Play():
    print("- Ingrese 1 para jugar")
    print("- Ingrese 2 para salir")

    while(True):
        option = input()

        if (option == '1'):
            #jugar
            return 'play'

        elif(option == '2'):
            #salir
            return 'exit'
        
        else:
            print("Opción invalida, intente nuevamente.")

#Funcion de menu para indicar que jugada hacemos
def Jugada():
    print("------------------------------")
    print("- Ingrese 1 para jugar PAPEL")
    print("- Ingrese 2 para jugar PIEDRA")
    print("- Ingrese 3 para jugar TIJERA")

    while(True):
        option = input()

        if (option == '1'):
            #papel
            return 'papel'

        elif(option == '2'):
            #piedra
            return 'piedra'

        elif(option == '3'):
            #tijera
            return 'tijera'
        
        else:
            print("Opción invalida, intente nuevamente.")

#Funcion que imprime el desenlace de la partida. Result se calcula en el servidor intermediario
def Desenlace(jugada_j, jugada_b, result):
    print("Usted ha jugado ", jugada_j)
    print("El Bot ha jugado ", jugada_b)

    if (result == 'j'):
        print("Usted gana esta ronda")
    elif(result == 'b'):
        print("El Bot gana esta ronda")
    elif(result == 'e'):
        print("Esta ronda fué un empate")

#Funcion que imprime el marcador actual
def Marcador(p1, p2):
    print("El marcador actual es")
    print("Jugador: ", p1)
    print("Bot    : ", p2)
    print("\n")

#Funcion que se ejecuta solo cuando hay un ganador e imprime el mensaje final de la partida
def ganador(p1):
    if (p1 == 3):
        print("Felicitaciones, usted ha ganado la partida.")
    else:
        print("Usted ha perdido. Mejor suerte para la próxima.")

#Conexión
serverAddr = 'localhost'
puertoServidor = 50002
socketCliente = skt.socket(skt.AF_INET, skt.SOCK_STREAM)

socketCliente.connect((serverAddr, puertoServidor))
#---------

#Bienvenida
Welcome()

while (True):
    #Elección para jugar o salir
    toSend = Menu_to_Play()

    #Envio de la eleción al initermediario
    socketCliente.send(toSend.encode())

    #Respuesta del intermediario. Puede ser 'play', 'not_operational' o 'exit'
    response = socketCliente.recv(2048).decode()

    #Se llega aqui cuando el cliente decide jugar
    if (response == 'play'):

        #Bucle de la partida
        while (True):

            #Elección y envio de la jugada
            jugada = Jugada()
            socketCliente.send(jugada.encode())
            
            #resultado = 'jugadaBot,resultadoPartida,puntaje_jugador,puntaje_bot'
            resultado = socketCliente.recv(2048).decode()

            #Si la palabra 'game' está en el resultado quiere decir que la partida llegó a su fin
            if 'game' in resultado:
                result = resultado.split(',')
                #Se muestra el marcador y el mensaje final. Se sale del bucle de la partida
                Marcador(int(result[2]), int(result[3]))
                ganador(int(result[2]))
                break

            result = resultado.split(',')

            #jugada = jugada del jugador, result[0] = jugada del bot, result[1] = quien ganó el encuentro
            Desenlace(jugada, result[0], result[1])

            #result[2] = puntaje del jugador, result[3] = puntaje del bot. Se muestra el marcador
            Marcador(int(result[2]), int(result[3]))

    #Se llega aqui cuando los servidores no están operativos. No depende del cliente
    elif (response == 'not_operational'):
        #servidores no operativos
        print("Lo sentimos, los servidores no se encuentran disponibles en este momento.")
        print("Vuelva en otro momento.")

    #Se llega aqui cuando el cliente decide dejar de jugar. Se cierra el juego
    elif (response == 'exit'):
        #saliendo
        print("Apagando servidor cliente")
        print("El juego ha terminado. Muchas gracias por jugar.")
        break

socketCliente.close()