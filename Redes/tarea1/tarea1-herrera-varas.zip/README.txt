Juan Pablo Varas - 201873600-7
Sebastian Herrera Corrales - 201551551-4

Instrucciones de uso:

Previamente, se deben tener en un mismo directorio los archivos cachipun.go, cliente.py y servidor.py.
Para ejecutar el programa, se deben ejecutar los archivos en el siguiente orden

cachipun.go con el comando go run cachipun.go
servidor.py con el comando py servidor.py
cliente.py con el comando py cliente.py

Luego, la terminal donde se haya ejecutado el archivo cliente.py presentará el juego Cachipún, el cual
funciona tal como se solicitó en el enunciado.